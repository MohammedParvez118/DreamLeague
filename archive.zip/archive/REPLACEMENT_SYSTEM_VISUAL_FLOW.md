# Replacement System - Visual Flow Diagram

## 🔄 Complete Workflow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        REPLACEMENT SYSTEM WORKFLOW                       │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────────┐
│  USER VIEW   │
│ (Team Owner) │
└──────┬───────┘
       │
       │ 1. Goes to League → "🔄 Replacements" tab
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│              REQUEST REPLACEMENT FORM                          │
│                                                                │
│  Out Player:  [Dropdown - Squad Players]                      │
│               ├─ Player A (Batsman)                           │
│               ├─ Player B (Bowler)                            │
│               └─ Player C (All-Rounder)                       │
│                                                                │
│  In Player:   [Dropdown - Available Players]                  │
│               ├─ Player X (Batsman)                           │
│               ├─ Player Y (Bowler)                            │
│               └─ Player Z (All-Rounder)                       │
│                                                                │
│  Reason:      [Text Area]                                     │
│               "Player A injured, out for 2 weeks"             │
│                                                                │
│               [Request Replacement Button]                     │
└────────────────────────────────────────────────────────────────┘
       │
       │ 2. Submit Request
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│              BACKEND: replacementController.js                 │
│                                                                │
│  ✓ Validate leagueId, teamId                                  │
│  ✓ Check outPlayer exists in squad                            │
│  ✓ Check outPlayer not already injured                        │
│  ✓ Check inPlayer available (not in any squad)                │
│  ✓ Calculate: outPlayer points earned, matches played         │
│  ✓ Get: next match ID (replacement_start_match_id)            │
│  ✓ INSERT INTO squad_replacements (status: 'pending')         │
└────────────────────────────────────────────────────────────────┘
       │
       │ 3. Request Created
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│                   DATABASE: squad_replacements                 │
│                                                                │
│  replacement_id: 1                                             │
│  league_id: 83                                                 │
│  team_id: 104                                                  │
│  out_player_id: 12345  →  "Player A"                          │
│  in_player_id: 67890   →  "Player X"                          │
│  reason: "Player injured, out for 2 weeks"                    │
│  status: 'pending' ◄────────── WAITING FOR ADMIN              │
│  requested_at: 2025-01-27 10:00:00                            │
│  replacement_start_match_id: 842                              │
│  out_player_points_earned: 125                                │
│  out_player_matches_played: 5                                 │
│  admin_email: NULL                                             │
│  admin_notes: NULL                                             │
│  reviewed_at: NULL                                             │
└────────────────────────────────────────────────────────────────┘
       │
       │ 4. User sees in History Table
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│              REPLACEMENT HISTORY (User View)                   │
│ ┌──────────┬──────────┬─────────────┬──────────┬────────────┐ │
│ │ Out      │ In       │ Reason      │ Status   │ Actions    │ │
│ ├──────────┼──────────┼─────────────┼──────────┼────────────┤ │
│ │ Player A │ Player X │ Injured,    │ [PENDING]│ [Cancel]   │ │
│ │          │          │ 2 weeks     │          │            │ │
│ └──────────┴──────────┴─────────────┴──────────┴────────────┘ │
└────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

┌──────────────┐
│  ADMIN VIEW  │
│ (League      │
│  Creator)    │
└──────┬───────┘
       │
       │ 5. Clicks "View Pending Approvals"
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│           ADMIN PENDING REPLACEMENTS (League-wide)             │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │ REPLACEMENT REQUEST #1                                   │ │
│  │                                                          │ │
│  │ Team: Team Alpha                                         │ │
│  │ Owner: user@example.com                                  │ │
│  │ Requested: 2025-01-27 10:00:00                          │ │
│  │                                                          │ │
│  │ ┌──────────────────┐      ┌──────────────────┐         │ │
│  │ │ OUT              │  →   │ IN               │         │ │
│  │ │                  │      │                  │         │ │
│  │ │ Player A         │      │ Player X         │         │ │
│  │ │ Batsman          │      │ Batsman          │         │ │
│  │ │                  │      │                  │         │ │
│  │ │ 125 points       │      │ (New Player)     │         │ │
│  │ │ 5 matches        │      │                  │         │ │
│  │ └──────────────────┘      └──────────────────┘         │ │
│  │                                                          │ │
│  │ Reason: "Player A injured, out for 2 weeks"             │ │
│  │                                                          │ │
│  │ Replacement starts from: Match #6 (Next match)          │ │
│  │                                                          │ │
│  │  [✓ Approve]                          [✗ Reject]        │ │
│  └──────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────┘
       │
       │ 6. Admin clicks "Approve"
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│                   APPROVE CONFIRMATION MODAL                   │
│                                                                │
│  This will:                                                    │
│  ✓ Mark Player A as injured                                   │
│  ✓ Add Player X to the squad                                  │
│  ✓ Automatically replace in all future Playing XIs            │
│  ✓ Preserve all points earned by Player A                     │
│                                                                │
│  Admin Notes (Optional):                                       │
│  [Text Area] "Approved - valid injury documentation"          │
│                                                                │
│  [Cancel]                          [Confirm Approval]          │
└────────────────────────────────────────────────────────────────┘
       │
       │ 7. Admin confirms
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│         BACKEND: replacementController.reviewReplacement()     │
│                                                                │
│  BEGIN TRANSACTION;                                            │
│                                                                │
│  ► Step 1: Mark injured                                       │
│    UPDATE fantasy_squads                                       │
│    SET is_injured = TRUE,                                      │
│        injury_replacement_id = 67890                           │
│    WHERE player_id = 12345 AND team_id = 104;                 │
│                                                                │
│  ► Step 2: Add replacement to squad                           │
│    INSERT INTO fantasy_squads                                  │
│    (team_id, player_id, tournament_id)                        │
│    VALUES (104, 67890, 123);                                  │
│                                                                │
│  ► Step 3: Auto-replace in Playing XIs                        │
│    SELECT apply_replacement_to_future_matches(                │
│      104,    -- team_id                                        │
│      12345,  -- out_player_id                                  │
│      67890,  -- in_player_id                                   │
│      842     -- replacement_start_match_id                     │
│    );                                                          │
│    └─► Returns: 3 (matches updated)                           │
│                                                                │
│  ► Step 4: Update replacement request                         │
│    UPDATE squad_replacements                                   │
│    SET status = 'approved',                                    │
│        admin_email = 'admin@example.com',                      │
│        admin_notes = 'Approved - valid injury',               │
│        reviewed_at = NOW()                                     │
│    WHERE replacement_id = 1;                                   │
│                                                                │
│  COMMIT;                                                       │
└────────────────────────────────────────────────────────────────┘
       │
       │ 8. Database updated
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│               DATABASE AFTER APPROVAL                          │
│                                                                │
│  ┌──────────────────────────────────────┐                     │
│  │ fantasy_squads                       │                     │
│  ├──────────────────────────────────────┤                     │
│  │ player_id: 12345 (Player A)          │                     │
│  │ is_injured: TRUE     ◄───────────── MARKED                │
│  │ injury_replacement_id: 67890         │                     │
│  ├──────────────────────────────────────┤                     │
│  │ player_id: 67890 (Player X)          │                     │
│  │ is_injured: FALSE    ◄───────────── ADDED                 │
│  └──────────────────────────────────────┘                     │
│                                                                │
│  ┌──────────────────────────────────────┐                     │
│  │ squad_replacements                   │                     │
│  ├──────────────────────────────────────┤                     │
│  │ replacement_id: 1                    │                     │
│  │ status: 'approved'   ◄───────────── UPDATED               │
│  │ admin_email: admin@example.com       │                     │
│  │ admin_notes: 'Approved - valid...'   │                     │
│  │ reviewed_at: 2025-01-27 11:30:00     │                     │
│  └──────────────────────────────────────┘                     │
│                                                                │
│  ┌──────────────────────────────────────┐                     │
│  │ team_playing_xi (Match 6)            │                     │
│  ├──────────────────────────────────────┤                     │
│  │ player_id: 67890 ◄────────────────── REPLACED             │
│  │ (was 12345)                          │                     │
│  │ is_captain: false                    │                     │
│  └──────────────────────────────────────┘                     │
│  ┌──────────────────────────────────────┐                     │
│  │ team_playing_xi (Match 7)            │                     │
│  ├──────────────────────────────────────┤                     │
│  │ player_id: 67890 ◄────────────────── REPLACED             │
│  │ (was 12345)                          │                     │
│  └──────────────────────────────────────┘                     │
│  ┌──────────────────────────────────────┐                     │
│  │ team_playing_xi (Match 8)            │                     │
│  ├──────────────────────────────────────┤                     │
│  │ player_id: 67890 ◄────────────────── REPLACED             │
│  │ (was 12345)                          │                     │
│  └──────────────────────────────────────┘                     │
│                                                                │
│  🎯 Result: 3 future Playing XIs updated!                     │
└────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

┌──────────────┐
│ USER VIEW    │
│ (After       │
│  Approval)   │
└──────┬───────┘
       │
       │ 9. Views "My Team" tab
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│                  CURRENT SQUAD (Updated)                       │
│                                                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐│
│  │ Player B     │  │ Player C     │  │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ││
│  │ Bowler       │  │ All-Rounder  │  │ ▓  Player A      ▓ ││
│  │              │  │              │  │ ▓  Batsman       ▓ ││
│  ├──────────────┤  ├──────────────┤  │ ▓                ▓ ││
│  │              │  │              │  │ ▓ [ INJURED ]    ▓ ││
│  │              │  │              │  │ ▓ → Player X     ▓ ││
│  └──────────────┘  └──────────────┘  └──────────────────────┘│
│                                       ▲                       │
│                                       │                       │
│                                  RED BORDER +                 │
│                                  "INJURED" BADGE              │
└────────────────────────────────────────────────────────────────┘
       │
       │ 10. New player added
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐│
│  │ Player B     │  │ Player C     │  │ Player X  (NEW!)     ││
│  │ Bowler       │  │ All-Rounder  │  │ Batsman              ││
│  │              │  │              │  │                      ││
│  │              │  │              │  │ ✓ Available          ││
│  └──────────────┘  └──────────────┘  └──────────────────────┘│
└────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

       │
       │ 11. Checks Playing XI for future match
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│              PLAYING XI (Match 6 - Future)                     │
│                                                                │
│  BEFORE APPROVAL:                  AFTER APPROVAL:            │
│  ┌────────────────┐                ┌────────────────┐         │
│  │ Player A       │   ────────►    │ Player X       │         │
│  │ (Injured)      │   REPLACED     │ (Active)       │         │
│  └────────────────┘                └────────────────┘         │
│  ┌────────────────┐                ┌────────────────┐         │
│  │ Player B       │   ────────►    │ Player B       │         │
│  │ (Same)         │   UNCHANGED    │ (Same)         │         │
│  └────────────────┘                └────────────────┘         │
│  ┌────────────────┐                ┌────────────────┐         │
│  │ Player C (C)   │   ────────►    │ Player C (C)   │         │
│  │ (Captain)      │   PRESERVED    │ (Captain)      │         │
│  └────────────────┘                └────────────────┘         │
│                                                                │
│  🎯 Automatically updated for ALL future matches!             │
└────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

       │
       │ 12. Match is played
       │
       ▼
┌────────────────────────────────────────────────────────────────┐
│               POINTS ATTRIBUTION (After Match)                 │
│                                                                │
│  Player A (Injured):                                           │
│  ├─ Points earned before injury: 125                          │
│  ├─ Matches played before injury: 5                           │
│  └─ Status: is_injured = TRUE                                 │
│     ▲                                                          │
│     │ POINTS STAY HERE                                        │
│     └─ Points are NOT transferred to Player X                 │
│                                                                │
│  Player X (Replacement):                                       │
│  ├─ Points earned from Match 6 onwards: (new points)          │
│  └─ Counted as separate player                                │
│                                                                │
│  Team Total Points:                                            │
│  = Player A points (0-5) + Player X points (6+) + others      │
└────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

                              SUMMARY FLOW

     USER                    SYSTEM                     ADMIN
       │                        │                         │
       ├── Request ──────────►  │                         │
       │                        │                         │
       │              ┌─── Validate                       │
       │              └─► Store (pending)                 │
       │                        │                         │
       │                        │  ◄────── View ─────────┤
       │                        │                         │
       │                        │  ◄────── Approve ──────┤
       │                        │                         │
       │              ┌─── Mark injured                   │
       │              ├─► Add replacement                 │
       │              ├─► Update Playing XIs              │
       │              └─► Set status approved             │
       │                        │                         │
       │  ◄─── Notification ────┤                         │
       │                        │                         │
       ├── View squad ────────► │                         │
       │  (sees injured mark)   │                         │
       │                        │                         │
       ├── View Playing XI ───► │                         │
       │  (sees replacement)    │                         │
       │                        │                         │
       └── Play match ────────► │                         │
              (points preserved)│                         │

═══════════════════════════════════════════════════════════════════════════

                        KEY SYSTEM COMPONENTS

┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  Frontend (React)                Backend (Node.js)                  │
│  ┌──────────────────┐           ┌──────────────────┐              │
│  │ ReplacementPanel │──────────►│ Replacement      │              │
│  │ - Request form   │    API    │   Controller     │              │
│  │ - History table  │◄──────────│ - 6 functions    │              │
│  │ - Squad display  │           │ - Validation     │              │
│  └──────────────────┘           └────────┬─────────┘              │
│  ┌──────────────────┐                    │                         │
│  │ AdminReplacement │                    │                         │
│  │   View           │                    │                         │
│  │ - Pending list   │                    │                         │
│  │ - Review modal   │                    │                         │
│  └──────────────────┘                    ▼                         │
│                               ┌──────────────────────┐             │
│                               │  Database            │             │
│                               │  ┌────────────────┐  │             │
│                               │  │ squad_         │  │             │
│                               │  │  replacements  │  │             │
│                               │  └────────────────┘  │             │
│                               │  ┌────────────────┐  │             │
│                               │  │ fantasy_squads │  │             │
│                               │  │ + is_injured   │  │             │
│                               │  └────────────────┘  │             │
│                               │  ┌────────────────┐  │             │
│                               │  │ fantasy_teams  │  │             │
│                               │  │ + is_admin     │  │             │
│                               │  └────────────────┘  │             │
│                               │  ┌────────────────┐  │             │
│                               │  │ team_playing_xi│  │             │
│                               │  │ (auto-updated) │  │             │
│                               │  └────────────────┘  │             │
│                               └──────────────────────┘             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

                           STATUS INDICATORS

┌──────────┬────────────┬─────────────────────────────────────────┐
│ Status   │ Color      │ Meaning                                 │
├──────────┼────────────┼─────────────────────────────────────────┤
│ PENDING  │ 🟡 Yellow  │ Waiting for admin review                │
│ APPROVED │ 🟢 Green   │ Accepted, replacement active            │
│ REJECTED │ 🔴 Red     │ Denied, player remains unchanged        │
│ INJURED  │ 🔴 Red     │ Player marked as injured (visual badge) │
└──────────┴────────────┴─────────────────────────────────────────┘

```

