# League ID Missing in SavePlayingXI - FIXED ✅

## Problem
When saving Playing XI for any match, the system returned an error:
```
{
    "success": false,
    "error": "Failed to save Playing XI",
    "details": "null value in column \"league_id\" of relation \"team_playing_xi\" violates not-null constraint"
}
```

## Root Cause
The `savePlayingXI()` function in `playingXiControllerSimplified.js` was missing `league_id` in the INSERT statement.

**Database Schema:**
```sql
CREATE TABLE team_playing_xi (
  team_id INTEGER NOT NULL,
  league_id INTEGER NOT NULL,  -- Required field!
  match_id INTEGER NOT NULL,
  player_id VARCHAR(50) NOT NULL,
  ...
)
```

**Old INSERT (BROKEN):**
```javascript
INSERT INTO team_playing_xi 
  (team_id, match_id, player_id, player_name, player_role, squad_name, is_captain, is_vice_captain)
  VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
```

## Solution Applied
Added `league_id` to the INSERT statement in **lines 530-547** of `playingXiControllerSimplified.js`:

**New INSERT (FIXED):**
```javascript
INSERT INTO team_playing_xi 
  (team_id, league_id, match_id, player_id, player_name, player_role, squad_name, is_captain, is_vice_captain)
  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
```

**Parameters array:**
```javascript
[
  teamId,
  leagueId,    // ✅ Now included!
  matchId,
  player.player_id,
  player.player_name,
  player.player_role,
  player.squad_name,
  player.is_captain,
  player.is_vice_captain
]
```

## Verification
✅ Auto-save mechanism already had `league_id` (getPlayingXI function - line 225)
✅ Adapter's copyPlayingXI already had `league_id` (fixed earlier)
✅ Now savePlayingXI also has `league_id`

## Status
**FIXED** - Server will auto-reload with nodemon. Try saving Playing XI again.

## Related Files
- `src/controllers/api/playingXiControllerSimplified.js` - Lines 530-547 (INSERT statement)
- `migrations/2025_10_20_fantasy_extensions.sql` - Lines 58-73 (table definition)
