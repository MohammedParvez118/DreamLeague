/**
 * Debug why match 888 (13th Match) isn't generating scores
 */

import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Fantasy',
  password: 'P@rvezn00r',
  port: 5432,
});

async function debugMatch() {
  const client = await pool.connect();
  
  try {
    const matchId = 888; // 13th Match
    
    console.log(`\n🔍 Debugging Match ${matchId} (13th Match)\n`);
    console.log('='.repeat(80));
    
    // Get match info
    const match = await client.query(`
      SELECT id, match_id, match_description, league_id
      FROM league_matches
      WHERE id = $1
    `, [matchId]);
    
    if (match.rows.length === 0) {
      console.log('Match not found!');
      return;
    }
    
    const matchInfo = match.rows[0];
    console.log(`\nMatch Info:`);
    console.log(`  League Match ID: ${matchInfo.id}`);
    console.log(`  Cricket API Match ID: ${matchInfo.match_id}`);
    console.log(`  Description: ${matchInfo.match_description}`);
    console.log(`  League ID: ${matchInfo.league_id}`);
    
    // Check Playing XI
    console.log(`\n📋 Playing XI Status:`);
    const teams = [105, 106, 107];
    
    for (const teamId of teams) {
      const xi = await client.query(`
        SELECT COUNT(*) as count, 
               array_agg(player_id) as players
        FROM team_playing_xi
        WHERE team_id = $1 AND match_id = $2
      `, [teamId, matchId]);
      
      console.log(`  Team ${teamId}: ${xi.rows[0].count} players`);
      console.log(`    Players: ${xi.rows[0].players?.slice(0, 5).join(', ')}...`);
    }
    
    // Check player stats
    console.log(`\n📊 Player Stats for Cricket Match ${matchInfo.match_id}:`);
    
    const batting = await client.query(`
      SELECT COUNT(DISTINCT player_id) as count
      FROM player_batting_stats
      WHERE match_id = $1
    `, [matchInfo.match_id]);
    
    const bowling = await client.query(`
      SELECT COUNT(DISTINCT player_id) as count
      FROM player_bowling_stats
      WHERE match_id = $1
    `, [matchInfo.match_id]);
    
    const fielding = await client.query(`
      SELECT COUNT(DISTINCT player_id) as count
      FROM player_fielding_stats
      WHERE match_id = $1
    `, [matchInfo.match_id]);
    
    console.log(`  Batting stats: ${batting.rows[0].count} players`);
    console.log(`  Bowling stats: ${bowling.rows[0].count} players`);
    console.log(`  Fielding stats: ${fielding.rows[0].count} players`);
    
    // Check score records
    console.log(`\n💰 Score Records:`);
    const scores = await client.query(`
      SELECT team_id, total_points, captain_points, vice_captain_points
      FROM team_match_scores
      WHERE match_id = $1
    `, [matchId]);
    
    if (scores.rows.length > 0) {
      scores.rows.forEach(s => {
        console.log(`  Team ${s.team_id}: ${s.total_points} points (C: ${s.captain_points}, VC: ${s.vice_captain_points})`);
      });
    } else {
      console.log(`  ❌ NO SCORE RECORDS FOUND`);
    }
    
    // Try to calculate manually for one team
    console.log(`\n🧮 Manual Calculation Test (Team 106):`);
    
    const teamXI = await client.query(`
      SELECT player_id, is_captain, is_vice_captain
      FROM team_playing_xi
      WHERE team_id = 106 AND match_id = $1
    `, [matchId]);
    
    let totalPoints = 0;
    let playersWithStats = 0;
    
    for (const player of teamXI.rows) {
      const stats = await client.query(`
        SELECT 
          (SELECT runs FROM player_batting_stats WHERE player_id = $1 AND match_id = $2) as runs,
          (SELECT wickets FROM player_bowling_stats WHERE player_id = $1 AND match_id = $2) as wickets
      `, [player.player_id, matchInfo.match_id]);
      
      const runs = stats.rows[0]?.runs || 0;
      const wickets = stats.rows[0]?.wickets || 0;
      
      if (runs > 0 || wickets > 0) {
        playersWithStats++;
        const playerPts = runs + (wickets * 25);
        const multiplier = player.is_captain ? 2 : (player.is_vice_captain ? 1.5 : 1);
        totalPoints += playerPts * multiplier;
      }
    }
    
    console.log(`  Players with stats: ${playersWithStats}/${teamXI.rows.length}`);
    console.log(`  Calculated total: ${Math.round(totalPoints)} points`);
    
    if (playersWithStats === 0) {
      console.log(`  ⚠️  NO PLAYERS HAVE STATS - This is why no score record was created!`);
    }
    
  } catch (err) {
    console.error('\n❌ Error:', err.message);
    console.error(err.stack);
  } finally {
    client.release();
    await pool.end();
  }
}

debugMatch();
