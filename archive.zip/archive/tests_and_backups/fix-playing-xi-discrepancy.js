/**
 * Fix: Copy Playing XI from match 10 to matches 11 & 12 for Teams 106 & 107
 * This ensures all teams have XI saved for the same number of matches
 */

import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Fantasy',
  password: 'P@rvezn00r',
  port: 5432,
});

async function fixPlayingXIDiscrepancy() {
  const client = await pool.connect();
  
  try {
    console.log('\n🔧 Fixing Playing XI Discrepancy\n');
    console.log('='.repeat(80));
    
    await client.query('BEGIN');
    
    const teamsToFix = [106, 107];
    const sourceMatch = 885; // Match 10
    const targetMatches = [886, 887]; // Matches 11 & 12
    
    for (const teamId of teamsToFix) {
      const team = await client.query('SELECT team_name FROM fantasy_teams WHERE id = $1', [teamId]);
      const teamName = team.rows[0].team_name;
      
      console.log(`\n📋 Team ${teamId} (${teamName}):`);
      
      // Get Playing XI from source match
      const sourceXI = await client.query(`
        SELECT player_id, is_captain, is_vice_captain
        FROM team_playing_xi
        WHERE team_id = $1 AND match_id = $2
      `, [teamId, sourceMatch]);
      
      console.log(`   Source (Match ${sourceMatch}): ${sourceXI.rows.length} players`);
      
      if (sourceXI.rows.length === 0) {
        console.log(`   ⚠️  No Playing XI found for source match!`);
        continue;
      }
      
      for (const targetMatch of targetMatches) {
        // Check if already exists
        const existing = await client.query(`
          SELECT COUNT(*) as count
          FROM team_playing_xi
          WHERE team_id = $1 AND match_id = $2
        `, [teamId, targetMatch]);
        
        if (parseInt(existing.rows[0].count) > 0) {
          console.log(`   ✓ Match ${targetMatch}: Already has Playing XI (${existing.rows[0].count} players)`);
          continue;
        }
        
        // Copy Playing XI
        for (const player of sourceXI.rows) {
          await client.query(`
            INSERT INTO team_playing_xi (team_id, match_id, player_id, is_captain, is_vice_captain, league_id)
            VALUES ($1, $2, $3, $4, $5, 84)
            ON CONFLICT (team_id, match_id, player_id) DO NOTHING
          `, [teamId, targetMatch, player.player_id, player.is_captain, player.is_vice_captain]);
        }
        
        console.log(`   ✅ Match ${targetMatch}: Copied ${sourceXI.rows.length} players from Match ${sourceMatch}`);
      }
    }
    
    await client.query('COMMIT');
    
    console.log('\n' + '='.repeat(80));
    console.log('\n✅ Playing XI synchronization complete!\n');
    console.log('Next steps:');
    console.log('1. Run the recalculation endpoint: POST /api/league/84/recalculate-all-points');
    console.log('2. Or click the "Refresh & Update" button in the leaderboard UI\n');
    
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('\n❌ Error:', err.message);
    console.error(err.stack);
  } finally {
    client.release();
    await pool.end();
  }
}

fixPlayingXIDiscrepancy();
