import axios from 'axios';

const matchId = '114960';

const options = {
  method: 'GET',
  url: `https://cricbuzz-cricket.p.rapidapi.com/mcenter/v1/${matchId}/hscard`,
  headers: {
    'x-rapidapi-key': 'f8caabb8b1msh37ba48711d0db0ap100b7ajsnb96b28f37ac9',
    'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com'
  }
};

try {
  const response = await axios.request(options);
  if (response.data.scorecard && response.data.scorecard[0]) {
    const firstInnings = response.data.scorecard[0];
    console.log('FOW structure:');
    if (firstInnings.fow) {
      console.log(JSON.stringify(firstInnings.fow, null, 2).substring(0, 800));
    }
    console.log('\nPartnership structure:');
    if (firstInnings.partnership) {
      console.log(JSON.stringify(firstInnings.partnership, null, 2).substring(0, 1000));
    }
  }
} catch (error) {
  console.error('Error:', error.message);
}
