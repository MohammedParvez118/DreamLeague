import { refreshTournamentData } from './src/services/apiService.js';

console.log('Starting test...');

refreshTournamentData(10884)
  .then(() => {
    console.log('\n✅ Test completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Test failed:', error);
    process.exit(1);
  });
