import { fetchFromApi } from './src/services/apiService.js';

// Test fetching individual squad details
const seriesId = 10884;
const squadId = 88606; // Dubai Capitals

// Try different endpoint patterns
const urls = [
  `https://cricbuzz-cricket.p.rapidapi.com/stats/v1/series/${seriesId}/squads/${squadId}`,
  `https://cricbuzz-cricket.p.rapidapi.com/series/v1/${seriesId}/squads/${squadId}`,
  `https://cricbuzz-cricket.p.rapidapi.com/stats/v1/series/${seriesId}`,
];

async function testUrls() {
  for (const url of urls) {
    console.log('\n=== Testing:', url);
    try {
      const data = await fetchFromApi(url);
      console.log('✅ SUCCESS! Keys:', Object.keys(data));
      console.log('Sample data:', JSON.stringify(data, null, 2).substring(0, 500));
      return data;
    } catch (error) {
      console.log('❌ Failed:', error.message);
    }
  }
  console.log('\n⚠️  All endpoints failed');
}

testUrls().then(() => process.exit(0));


