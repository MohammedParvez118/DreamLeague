import pool from './src/config/database.js';

async function debugReplacementLogic() {
  try {
    console.log('=== Debugging Replacement Logic ===\n');
    
    // Check current time
    const now = await pool.query('SELECT NOW() as current_time');
    console.log('Current Database Time:');
    console.table(now.rows);
    
    // Check match times for league 84
    const matches = await pool.query(`
      SELECT id, match_description, match_start,
             match_start > NOW() as is_future,
             EXTRACT(EPOCH FROM (match_start - NOW())) as seconds_until_start
      FROM league_matches
      WHERE league_id = 84
        AND id >= 901
      ORDER BY id
      LIMIT 10
    `);
    
    console.log('\nMatches from ID 901 onwards:');
    console.table(matches.rows);
    
    // Check what the function would select
    const futureMatches = await pool.query(`
      SELECT lm.id as match_id, lm.match_description, lm.match_start,
             lm.match_start > NOW() as is_future
      FROM league_matches lm
      WHERE lm.id >= 901
        AND lm.match_start > NOW()
      ORDER BY lm.id
      LIMIT 10
    `);
    
    console.log('\nMatches that meet the criteria (match_start > NOW()):');
    if (futureMatches.rows.length > 0) {
      console.table(futureMatches.rows);
    } else {
      console.log('❌ No matches found! All matches have already started.');
    }
    
    // Check Playing XI for matches >= 901
    const playingXI = await pool.query(`
      SELECT tpxi.match_id, tpxi.player_id, tpxi.player_name, tpxi.is_captain,
             lm.match_description, lm.match_start
      FROM team_playing_xi tpxi
      JOIN league_matches lm ON tpxi.match_id = lm.id
      WHERE tpxi.team_id = 105
        AND tpxi.match_id >= 901
        AND tpxi.player_id = '10276'
      ORDER BY tpxi.match_id
      LIMIT 5
    `);
    
    console.log('\nIshan Kishan in Playing XI (matches >= 901):');
    if (playingXI.rows.length > 0) {
      console.table(playingXI.rows);
    } else {
      console.log('✅ Not found in any matches >= 901');
    }
    
    await pool.end();
  } catch (error) {
    console.error('Error:', error);
    await pool.end();
    process.exit(1);
  }
}

debugReplacementLogic();
