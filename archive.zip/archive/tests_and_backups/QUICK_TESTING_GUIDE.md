# Quick Testing Guide

## 🎯 Frontend Testing (What You Should Test Now)

### Test 1: Match List Loading
1. Open your app in browser
2. Navigate to Playing XI page
3. **Expected:** Dropdown shows all matches with:
   - Match descriptions
   - Dates
   - 🔒 for locked matches
   - ✅ for saved lineups

### Test 2: View Existing Playing XI
1. Select a match that has ✅ (saved)
2. **Expected:** 
   - 11 players load automatically
   - Captain has (C) badge
   - Vice-Captain has (VC) badge
   - Transfer stats display

### Test 3: Create New Playing XI
1. Select a match without ✅
2. Pick 11 players from squad (min: 1 WK, 1 Bat, 1 AR, 1 Bowl)
3. Select Captain
4. Select Vice-Captain
5. Click Save
6. **Expected:**
   - Success message appears
   - Transfer count shown
   - Match now has ✅ in dropdown

### Test 4: Sequential Validation (NEW FEATURE)
1. Try to save Match 3 when Match 2 is not saved
2. **Expected:** Error message - "Cannot save Match 3 before Match 2"

### Test 5: Auto-Prefill (NEW FEATURE)
1. Save Playing XI for Match 1
2. Select Match 2 (not saved yet)
3. **Expected:** Match 2 automatically loads Match 1's lineup
4. Make changes and save
5. **Expected:** Only shows transfers from Match 1 → Match 2

### Test 6: Transfer Counting (NEW LOGIC)
1. Save Match 1 with 11 specific players
2. Select Match 2, change 3 players
3. Save Match 2
4. **Expected:** Shows "3 transfers used"
5. Select Match 3, change 2 more players
6. Save Match 3
7. **Expected:** Shows "5 transfers used total" (3 + 2)

### Test 7: Captain Changes (NEW LOGIC)
1. **First captain change:** Change captain in any match
   - **Expected:** Message "Free captain change used"
   - No transfer cost
2. **Second captain change:** Change captain again in another match
   - **Expected:** Message "Captain change costs 1 transfer"
   - Transfer count increases by 1
3. Same applies to Vice-Captain (one free change)

### Test 8: Match Lock
1. Wait for a match deadline to pass (or test with old match)
2. Try to edit locked match
3. **Expected:** 
   - 🔒 icon in dropdown
   - "Match is locked" message
   - Save button disabled

---

## 🐛 What Errors Are Now Fixed

### ✅ FIXED: "Failed to load match and squad data"
- **Was:** Database column mismatch
- **Now:** Loads correctly

### ✅ FIXED: "Cannot read properties of undefined (reading 'length')"
- **Was:** Response format mismatch (lineup vs players)
- **Now:** Adapter transforms response

### ✅ FIXED: "column m.match_number does not exist"
- **Was:** SQL query using wrong column names
- **Now:** Uses correct `league_matches` columns

### ✅ FIXED: "null value in column league_id violates not-null constraint"
- **Was:** copyPlayingXI missing league_id
- **Now:** Includes league_id in INSERT

---

## 🚦 Expected Behavior vs Bugs

| Action | Expected Behavior | If You See This → Bug |
|--------|-------------------|----------------------|
| Load page | Match dropdown fills | "Failed to load" error |
| Select match with ✅ | 11 players load | Empty or undefined error |
| Save lineup | Success + transfer count | 500 error or validation error |
| Skip match (save M3 before M2) | Error message | Saves successfully (wrong!) |
| Select unsaved match | Auto-loads previous lineup | Empty or shows different lineup |
| Change captain first time | "Free change used" | Costs 1 transfer (wrong!) |
| Match deadline passed | 🔒 + disabled | Can still edit (wrong!) |

---

## 📊 Console Debugging

### Browser Console (F12 → Console)
Look for these messages:
```javascript
✅ GOOD: "Fetched playing XI: [...]"
✅ GOOD: "Playing XI saved successfully"
❌ BAD: "Error fetching playing XI: TypeError..."
❌ BAD: "Failed to load match and squad data"
```

### Backend Console (Terminal)
Look for these messages:
```
✅ GOOD: Server running at http://localhost:3000
✅ GOOD: Connected to PostgreSQL database
❌ BAD: Error fetching matches status: error: column...
❌ BAD: Error saving Playing XI: error: null value...
```

---

## 🔥 Quick Fixes If Errors Still Occur

### Error: "Match dropdown empty"
**Check:**
1. Is server running? → `nodemon app.js`
2. Any errors in server console?
3. Try manually: `GET http://localhost:3000/api/league/83/team/104/matches-status`

### Error: "Cannot load playing XI"
**Check:**
1. Does match have saved lineup? (Should have ✅)
2. Try manually: `GET http://localhost:3000/api/league/83/team/104/match/[matchId]/playing-xi`
3. Check browser console for actual error

### Error: "Cannot save playing XI"
**Check:**
1. Did you select exactly 11 players?
2. Did you select both captain and vice-captain?
3. Is match locked (🔒)?
4. Check server console for validation error

---

## 🎯 Priority Test Order

1. **First:** Load match list (most basic)
2. **Second:** View saved lineup (read operation)
3. **Third:** Save new lineup (write operation)
4. **Fourth:** Test sequential validation (new logic)
5. **Fifth:** Test auto-prefill (new logic)
6. **Sixth:** Test transfer counting (new logic)

---

## 🆘 If Everything Still Breaks

1. **Check server logs** - Look for stack traces
2. **Check browser console** - Look for network errors
3. **Test with Postman** - Isolate frontend vs backend issues
4. **Share error message** - Copy full error from console

---

## ✅ Success Indicators

You'll know it's working when:
- ✅ Match dropdown loads instantly
- ✅ Squad players display (20 players with roles)
- ✅ Can save lineup and see success message
- ✅ Transfer count updates correctly
- ✅ Previous lineup auto-fills in next match
- ✅ Can't skip matches (sequential validation works)
- ✅ No errors in browser or server console

---

**Ready to test! Start with Test 1 (Match List Loading) and work your way down.** 🚀

**If you encounter any errors, share:**
1. Which test number failed
2. Exact error message from browser console
3. Any errors from server console
