import axios from 'axios';

const matchId = '114960';

const options = {
  method: 'GET',
  url: `https://cricbuzz-cricket.p.rapidapi.com/mcenter/v1/${matchId}/scard`,
  headers: {
    'x-rapidapi-key': 'f8caabb8b1msh37ba48711d0db0ap100b7ajsnb96b28f37ac9',
    'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com'
  }
};

try {
  const response = await axios.request(options);
  console.log('Full API Response (first 3000 chars):');
  console.log(JSON.stringify(response.data, null, 2).substring(0, 3000));
} catch (error) {
  console.error('Error:', error.response?.status, error.response?.statusText || error.message);
}
