import { fetchFromApi } from './src/services/apiService.js';

const tournamentId = 10884;
const squadsUrl = `https://cricbuzz-cricket.p.rapidapi.com/series/v1/${tournamentId}/squads`;

console.log('Fetching squads from:', squadsUrl);

fetchFromApi(squadsUrl)
  .then((data) => {
    console.log('\n=== API Response Structure ===');
    console.log('Keys:', Object.keys(data));
    console.log('\nFull Response:');
    console.log(JSON.stringify(data, null, 2));
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error:', error.message);
    process.exit(1);
  });
