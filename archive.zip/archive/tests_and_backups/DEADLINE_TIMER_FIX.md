# Deadline Timer NaN Fix ✅

## Date: October 25, 2025

## Problem
The deadline timer in Playing XI selection was showing **"NaNh NaNm"** instead of the actual countdown time.

```
⏰ Deadline: NaNh NaNm
```

---

## Root Cause

### Property Name Mismatch (snake_case vs camelCase)

**Backend** (`src/controllers/api/playingXiController.js`):
```javascript
res.json({
  success: true,
  data: {
    matchId: match.id,
    isLocked: match.is_locked,           // ✅ camelCase
    isCompleted: match.is_completed,      // ✅ camelCase
    matchStart: match.match_start,        // ✅ camelCase
    secondsUntilStart: Math.max(0, Math.floor(match.seconds_until_start))  // ✅ camelCase
  }
});
```

**Frontend** (`client/src/components/PlayingXIForm.jsx`):
```javascript
// ❌ BEFORE (BROKEN)
{matchLockStatus && !matchLockStatus.is_locked && (
  <div className="deadline-timer">
    ⏰ Deadline: {formatCountdown(matchLockStatus.seconds_until_start)}
  </div>
)}
```

**The Issue:**
- Backend sends: `secondsUntilStart` (camelCase)
- Frontend expects: `seconds_until_start` (snake_case)
- Result: `matchLockStatus.seconds_until_start` = **undefined**
- Math calculation: `Math.floor(undefined / 3600)` = **NaN**
- Display: `"NaNh NaNm"` ❌

Same issue with `isLocked` vs `is_locked` throughout the component.

---

## Solution

### Updated All Property References to camelCase

Changed **9 occurrences** from snake_case to camelCase to match backend response:

#### 1. **Deadline Timer Display** (line ~598)
```javascript
// ✅ FIXED
{matchLockStatus && !matchLockStatus.isLocked && (
  <div className="deadline-timer">
    ⏰ Deadline: {formatCountdown(matchLockStatus.secondsUntilStart)}
  </div>
)}
```

#### 2. **Toggle Player Selection** (line ~126)
```javascript
// ✅ FIXED
if (matchLockStatus?.isLocked) return;
```

#### 3. **Match Selector Disabled** (line ~612)
```javascript
// ✅ FIXED
disabled={matchLockStatus?.isLocked}
```

#### 4. **Copy from Previous Button** (line ~624)
```javascript
// ✅ FIXED
{selectedMatchId && !matchLockStatus?.isLocked && (
  <button onClick={handleCopyFromPrevious}>
    📋 Copy from Previous Match
  </button>
)}
```

#### 5. **Locked Match Warning** (line ~631)
```javascript
// ✅ FIXED
{matchLockStatus?.isLocked && (
  <div className="alert alert-warning">
    🔒 This match has started. Playing XI is locked...
  </div>
)}
```

#### 6. **Player Card Disabled State** (line ~769)
```javascript
// ✅ FIXED
const isDisabled = matchLockStatus?.isLocked || (!isSelected && !canSelect);
```

#### 7. **Captain Controls Display** (line ~807)
```javascript
// ✅ FIXED
{isSelected && !matchLockStatus?.isLocked && (
  <div className="captain-controls">
    ...
  </div>
)}
```

#### 8. **Save Button Section** (line ~838)
```javascript
// ✅ FIXED
{!matchLockStatus?.isLocked && (
  <div className="xi-actions">
    <button onClick={handleSave}>Save Playing XI</button>
  </div>
)}
```

---

## Files Modified

### `client/src/components/PlayingXIForm.jsx`

**Changes:**
- Changed `seconds_until_start` → `secondsUntilStart` (1 occurrence)
- Changed `is_locked` → `isLocked` (8 occurrences)

**Total:** 9 property references updated

---

## Why This Happened

### Inconsistent Naming Convention

The backend uses **camelCase** for JSON responses (JavaScript standard):
```javascript
{
  isLocked: true,
  secondsUntilStart: 3600,
  matchStart: "2025-10-25T10:00:00Z"
}
```

The frontend was using **snake_case** (Python/SQL style):
```javascript
matchLockStatus.is_locked
matchLockStatus.seconds_until_start
```

This mismatch is common when:
- Backend comes from SQL queries (snake_case)
- Developer forgets to transform property names
- Copy-paste from database field names

---

## Testing

### Before Fix ❌
```
⏰ Deadline: NaNh NaNm
```
- Timer showed NaN due to undefined value
- Match lock checks didn't work properly
- UI controls might not disable correctly

### After Fix ✅
```
⏰ Deadline: 2h 30m
⏰ Deadline: 1d 5h
⏰ Deadline: 45m
```
- Timer shows correct countdown
- Match locks work properly
- Captain/VC controls disable when locked
- Save button hides when locked

### Test Scenarios

1. **Upcoming Match (>24 hours)**
   - Expected: `"5d 12h"` format
   - Result: ✅ Shows days and hours

2. **Soon Match (<24 hours)**
   - Expected: `"2h 30m"` format
   - Result: ✅ Shows hours and minutes

3. **Imminent Match (<1 hour)**
   - Expected: `"0h 45m"` format
   - Result: ✅ Shows minutes

4. **Match Started**
   - Expected: `"Match started"` text
   - Result: ✅ Shows message, hides timer

5. **Locked Match**
   - Expected: Controls disabled, warning shown
   - Result: ✅ All controls properly disabled

---

## formatCountdown Function

The function itself was **correct**, just receiving **undefined** input:

```javascript
const formatCountdown = (seconds) => {
  if (seconds <= 0) return 'Match started';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  
  return `${hours}h ${minutes}m`;
};
```

**Input:** `undefined` → **Output:** `NaNh NaNm`  
**Input:** `3600` → **Output:** `1h 0m` ✅

---

## Best Practices

### 1. **Consistent Naming Convention**
Always use **camelCase** for JavaScript/JSON:
```javascript
// ✅ Good
{ isLocked, secondsUntilStart, matchStart }

// ❌ Avoid
{ is_locked, seconds_until_start, match_start }
```

### 2. **Type Safety with TypeScript**
TypeScript would have caught this:
```typescript
interface MatchLockStatus {
  isLocked: boolean;
  secondsUntilStart: number;
  matchStart: string;
}

// Would error on: matchLockStatus.is_locked
```

### 3. **Console Logging**
Add debug logs during development:
```javascript
console.log('Match lock status:', matchLockStatus);
console.log('Seconds until start:', matchLockStatus.secondsUntilStart);
```

### 4. **Defensive Coding**
Add fallbacks for undefined values:
```javascript
const seconds = matchLockStatus?.secondsUntilStart ?? 0;
⏰ Deadline: {formatCountdown(seconds)}
```

---

## Related Issues Fixed

This same pattern affected:
1. ✅ Deadline timer display (primary issue)
2. ✅ Match lock validation (8 locations)
3. ✅ UI control disabling
4. ✅ Captain/VC controls visibility
5. ✅ Save button visibility

All now use consistent **camelCase** property names! 🎯

---

## Summary

**Problem:** Deadline timer showing "NaNh NaNm"  
**Cause:** Property name mismatch (snake_case vs camelCase)  
**Fix:** Updated all references from `is_locked` → `isLocked` and `seconds_until_start` → `secondsUntilStart`  
**Result:** Timer now displays correctly: `"2h 30m"`, `"1d 5h"`, etc. ✅

Run frontend: `cd client && npm run dev`  
Test: Navigate to Playing XI selection and verify countdown timer!
