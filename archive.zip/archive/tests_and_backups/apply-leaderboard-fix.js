import pkg from 'pg';
import fs from 'fs';
const { Pool } = pkg;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Fantasy',
  password: 'P@rvezn00r',
  port: 5432,
});

async function applyLeaderboardFix() {
  try {
    console.log('\n=== Applying Leaderboard View Fix ===\n');

    // Read the SQL file
    const sql = fs.readFileSync('./migrations/fix_leaderboard_view.sql', 'utf8');
    
    // Execute the SQL
    await pool.query(sql);
    
    console.log('✅ Leaderboard view updated successfully!\n');
    
    // Test the view
    const result = await pool.query(`
      SELECT 
        rank,
        team_name,
        team_owner,
        total_points,
        matches_played,
        avg_points_per_match
      FROM league_leaderboard 
      WHERE league_id = 84
      ORDER BY rank
    `);
    
    console.log('League 84 Leaderboard after view update:');
    console.table(result.rows);
    
    pool.end();
  } catch (err) {
    console.error('❌ Error:', err.message);
    pool.end();
  }
}

applyLeaderboardFix();
