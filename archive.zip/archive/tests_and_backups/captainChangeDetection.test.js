// tests/unit/captainChangeDetection.test.js
import { describe, test, expect, beforeEach, afterEach } from '@jest/globals';
import { setupTestDatabase, cleanupTestDatabase, seedBaselineData } from '../helpers/dbSetup.js';
import { detectCaptainChange, calculateCaptainChanges } from '../../src/utils/captainChangeLogic.js';
import { sampleTeams, baselineSquad } from '../fixtures/sampleData.js';

describe('Captain Change Detection', () => {
  
  beforeEach(async () => {
    await setupTestDatabase();
    await seedBaselineData();
  });

  afterEach(async () => {
    await cleanupTestDatabase();
  });

  // TC-C-003: First captain change
  test('should count first captain change', async () => {
    const teamId = 1;
    const matchId = 846;
    const baselineCaptain = 'P1';
    const newCaptain = 'P3';

    const result = await detectCaptainChange({
      teamId,
      matchId,
      currentCaptain: newCaptain,
      baselineCaptain,
      previousCaptains: [],
      currentChangesUsed: 0
    });

    expect(result.captainChangesUsed).toBe(1);
    expect(result.captainChangesRemaining).toBe(0);
    expect(result.shouldBlock).toBe(false);
    expect(result.changeType).toBe('NEW_CHANGE');
  });

  // TC-C-004: Keep baseline captain (no change)
  test('should not count keeping baseline captain', async () => {
    const teamId = 1;
    const matchId = 846;
    const baselineCaptain = 'P1';

    const result = await detectCaptainChange({
      teamId,
      matchId,
      currentCaptain: 'P1',
      baselineCaptain,
      previousCaptains: [],
      currentChangesUsed: 0
    });

    expect(result.captainChangesUsed).toBe(0);
    expect(result.captainChangesRemaining).toBe(1);
    expect(result.shouldBlock).toBe(false);
    expect(result.changeType).toBe('NO_CHANGE');
  });

  // TC-C-005: Reuse previously changed captain (no penalty)
  test('should allow reusing previously changed captain without penalty', async () => {
    const teamId = 1;
    const matchId = 848;
    const baselineCaptain = 'P1';
    const previousCaptains = ['P3']; // P3 was used in Match 846
    const currentChangesUsed = 1;

    const result = await detectCaptainChange({
      teamId,
      matchId,
      currentCaptain: 'P3', // Reusing P3
      baselineCaptain,
      previousCaptains,
      currentChangesUsed
    });

    expect(result.captainChangesUsed).toBe(1); // Unchanged
    expect(result.captainChangesRemaining).toBe(0);
    expect(result.shouldBlock).toBe(false);
    expect(result.changeType).toBe('REUSE');
  });

  // TC-C-006: Change to new captain when limit reached (block)
  test('should block changing to new captain when limit reached', async () => {
    const teamId = 1;
    const matchId = 848;
    const baselineCaptain = 'P1';
    const previousCaptains = ['P3'];
    const currentChangesUsed = 1;

    const result = await detectCaptainChange({
      teamId,
      matchId,
      currentCaptain: 'P5', // New captain (not P1, not P3)
      baselineCaptain,
      previousCaptains,
      currentChangesUsed
    });

    expect(result.shouldBlock).toBe(true);
    expect(result.changeType).toBe('BLOCKED');
    expect(result.error).toContain('captain/vice-captain change');
  });

  // TC-C-007: Revert to baseline captain (decrement counter)
  test('should decrement counter when reverting to baseline', async () => {
    const teamId = 1;
    const matchId = 848;
    const baselineCaptain = 'P1';
    const previousCaptains = ['P3'];
    const currentChangesUsed = 1;

    const result = await detectCaptainChange({
      teamId,
      matchId,
      currentCaptain: 'P1', // Back to baseline
      baselineCaptain,
      previousCaptains,
      currentChangesUsed
    });

    expect(result.captainChangesUsed).toBe(0); // Decremented
    expect(result.captainChangesRemaining).toBe(1);
    expect(result.shouldBlock).toBe(false);
    expect(result.changeType).toBe('REVERT');
  });

  // TC-C-008: Re-save same match with same captain (no change)
  test('should not change counter when re-saving same captain', async () => {
    // Simulates: Match 846 already has P3 as captain
    const teamId = 1;
    const matchId = 846;
    const baselineCaptain = 'P1';
    const previousCaptainInSameMatch = 'P3';
    const currentChangesUsed = 1;

    const result = await calculateCaptainChanges({
      teamId,
      matchId,
      currentCaptain: 'P3',
      previousCaptain: previousCaptainInSameMatch, // Same as current
      baselineCaptain,
      previousCaptains: [],
      currentChangesUsed
    });

    expect(result.captainChangesUsed).toBe(1); // Unchanged
    expect(result.changeType).toBe('NO_CHANGE');
  });

  // TC-C-009: Re-save same match with different captain
  test('should update counter when changing captain in existing match', async () => {
    const teamId = 1;
    const matchId = 846;
    const baselineCaptain = 'P1';
    const previousCaptainInSameMatch = 'P3';
    const currentChangesUsed = 1;

    const result = await calculateCaptainChanges({
      teamId,
      matchId,
      currentCaptain: 'P1', // Reverting from P3 to P1
      previousCaptain: previousCaptainInSameMatch,
      baselineCaptain,
      previousCaptains: [],
      currentChangesUsed
    });

    expect(result.captainChangesUsed).toBe(0); // Decremented
    expect(result.changeType).toBe('REVERT');
  });
});

describe('Vice-Captain Change Detection', () => {
  
  beforeEach(async () => {
    await setupTestDatabase();
    await seedBaselineData();
  });

  afterEach(async () => {
    await cleanupTestDatabase();
  });

  // TC-VC-001: First vice-captain change
  test('should count first VC change toward limit', async () => {
    const result = await detectCaptainChange({
      teamId: 1,
      matchId: 846,
      currentCaptain: 'P1', // Same as baseline
      currentViceCaptain: 'P4', // Changed from P2
      baselineCaptain: 'P1',
      baselineViceCaptain: 'P2',
      previousCaptains: [],
      previousVCs: [],
      currentChangesUsed: 0
    });

    expect(result.captainChangesUsed).toBe(1);
    expect(result.changeType).toContain('VC');
  });

  // TC-VC-002: Change both captain and VC (counts as 1)
  test('should count captain + VC change as 1 total change', async () => {
    const result = await detectCaptainChange({
      teamId: 1,
      matchId: 846,
      currentCaptain: 'P3', // Changed
      currentViceCaptain: 'P4', // Changed
      baselineCaptain: 'P1',
      baselineViceCaptain: 'P2',
      previousCaptains: [],
      previousVCs: [],
      currentChangesUsed: 0
    });

    expect(result.captainChangesUsed).toBe(1);
    expect(result.changeType).toBe('BOTH_CHANGED');
  });

  // TC-VC-003: Reuse previously changed VC (no penalty)
  test('should allow reusing previously changed VC', async () => {
    const result = await detectCaptainChange({
      teamId: 1,
      matchId: 848,
      currentCaptain: 'P1',
      currentViceCaptain: 'P4', // Reusing
      baselineCaptain: 'P1',
      baselineViceCaptain: 'P2',
      previousCaptains: [],
      previousVCs: ['P4'],
      currentChangesUsed: 1
    });

    expect(result.captainChangesUsed).toBe(1); // Unchanged
    expect(result.changeType).toBe('REUSE');
  });

  // TC-VC-004: Revert VC to baseline (decrement)
  test('should decrement when reverting VC to baseline', async () => {
    const result = await detectCaptainChange({
      teamId: 1,
      matchId: 848,
      currentCaptain: 'P1',
      currentViceCaptain: 'P2', // Back to baseline
      baselineCaptain: 'P1',
      baselineViceCaptain: 'P2',
      previousCaptains: [],
      previousVCs: ['P4'],
      currentChangesUsed: 1
    });

    expect(result.captainChangesUsed).toBe(0); // Decremented
    expect(result.changeType).toBe('REVERT');
  });
});

describe('Edge Cases', () => {
  
  // TC-E-004: Captain and VC swap
  test('should handle captain and VC swap', async () => {
    const result = await detectCaptainChange({
      teamId: 1,
      matchId: 846,
      currentCaptain: 'P2', // Was VC
      currentViceCaptain: 'P1', // Was Captain
      baselineCaptain: 'P1',
      baselineViceCaptain: 'P2',
      previousCaptains: [],
      previousVCs: [],
      currentChangesUsed: 0
    });

    expect(result.captainChangesUsed).toBe(1);
    expect(result.changeType).toBe('SWAP');
  });

  // TC-E-005: Query excludes baseline captain
  test('should not include baseline captain in "previous captains" list', async () => {
    // This tests the SQL query logic
    const previousCaptains = await getPreviousCaptains({
      teamId: 1,
      currentMatchId: 848,
      baselineCaptainId: 'P1'
    });

    // If user kept P1 in Match 846, it should NOT appear in this list
    expect(previousCaptains).not.toContain('P1');
  });

  // TC-D-003: Player ID type consistency
  test('should handle VARCHAR vs NUMBER player ID comparison', async () => {
    const result = await detectCaptainChange({
      teamId: 1,
      matchId: 846,
      currentCaptain: 123, // NUMBER from frontend
      baselineCaptain: '123', // VARCHAR from DB
      previousCaptains: [],
      currentChangesUsed: 0
    });

    // Should convert both to String and compare correctly
    expect(result.changeType).toBe('NO_CHANGE'); // Not a change
    expect(result.captainChangesUsed).toBe(0);
  });
});
