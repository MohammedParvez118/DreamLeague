# Playing XI Selection - Type Consistency Fix

## Date: October 25, 2025

## Critical Issue Discovered

### Problem: All Players Selecting at Once
**Symptom**: Clicking one player selects/deselects all players. Player count shows "1 / 11" but all visual cards show as selected.

**Root Cause**: Type inconsistency between player IDs
- API returns player_id as STRING: "12345"
- Code was comparing STRING vs NUMBER
- JavaScript array.includes() uses strict equality (===)
- "12345" !== 12345, so comparisons always failed

## Solution: Type Normalization

### 1. Normalize Squad Data on Fetch
```jsx
const transformedSquad = squad.map(player => ({
  player_id: parseInt(player.player_id), // Convert to number
  // ... other fields
}));
```

### 2. Normalize in Toggle Function
```jsx
const togglePlayerSelection = (playerId) => {
  const id = parseInt(playerId); // Ensure number
  if (playingXI.includes(id)) {
    // Remove logic
  } else {
    // Add logic
  }
};
```

### 3. Normalize Fetched Playing XI
```jsx
const playerIds = players.map(p => parseInt(p.player_id));
setPlayingXI(playerIds);
```

### 4. Normalize Captain/VC Handlers
```jsx
const handleCaptainSelection = (playerId) => {
  const id = parseInt(playerId);
  // ... rest of logic
};
```

## Debugging Added

### Console Logs for Troubleshooting
```jsx
// In fetchMatchesAndSquad
console.log('Raw squad data from API:', squad);
console.log('Player IDs:', transformedSquad.map(p => `${p.player_id} (${typeof p.player_id})`));

// In togglePlayerSelection
console.log('Toggle player clicked:', id, 'Type:', typeof id);
console.log('Current playingXI:', playingXI);
console.log('Adding/Removing player, new array:', newPlayingXI);

// In player card render
console.log('Player card clicked:', player.player_name, player.player_id);
```

## Type Safety Rules

### All player IDs should be:
1. ✅ Stored as **numbers** in state arrays
2. ✅ Converted with `parseInt()` when received from API
3. ✅ Converted with `parseInt()` in event handlers
4. ✅ Compared using `===` (strict equality)

### State Variables
```javascript
playingXI: number[]        // [1234, 5678, 9012]
captain: number | null     // 1234
viceCaptain: number | null // 5678
squadPlayers: Array<{
  player_id: number,       // 1234
  player_name: string,
  role: string,
  // ...
}>
```

## Testing Checklist

### Before Fix (Bug)
- ❌ Click player → All players appear selected
- ❌ Count shows "1 / 11" but all cards highlighted
- ❌ Captain/VC buttons appear on all cards
- ❌ Console shows type mismatches

### After Fix (Expected)
- ✅ Click player → Only that player toggles selection
- ✅ Count accurately shows "X / 11"
- ✅ Only selected players show checkmark
- ✅ Captain/VC buttons only on selected players
- ✅ Console logs show consistent number types

## Files Modified

### client/src/components/PlayingXIForm.jsx
**Lines Changed:**
1. `fetchMatchesAndSquad()` - Added `parseInt()` to player_id (Line ~50)
2. `fetchPlayingXI()` - Parse player IDs and captain/VC (Line ~86)
3. `togglePlayerSelection()` - Parse incoming playerId (Line ~103)
4. `handleCaptainSelection()` - Parse playerId (Line ~126)
5. `handleViceCaptainSelection()` - Parse playerId (Line ~138)
6. Player card render - Added debug logging (Line ~540)

## Common JavaScript Pitfalls

### The Problem
```javascript
const playingXI = [1234, 5678]; // numbers
const playerIdFromAPI = "1234";  // string

playingXI.includes(playerIdFromAPI); // FALSE! (strict equality)
playingXI.includes(1234);             // TRUE
```

### The Solution
```javascript
const playingXI = [1234, 5678];
const playerIdFromAPI = "1234";

playingXI.includes(parseInt(playerIdFromAPI)); // TRUE
```

## Additional Safeguards

### Null/Undefined Checks
```jsx
{rolePlayers.map((player, index) => {
  if (!player || !player.player_id) {
    console.warn('Invalid player data:', player, 'at index', index);
    return null;
  }
  // ... render player
})}
```

### Event Propagation (from previous fix)
```jsx
<div className="player-select-area" onClick={(e) => {
  e.stopPropagation(); // Prevent bubbling
  togglePlayerSelection(player.player_id);
}}>
```

## Verification Steps

1. **Open Browser Console** (F12)
2. **Navigate to Playing XI tab**
3. **Check console logs**:
   ```
   Raw squad data from API: [...]
   Player IDs: ["1234 (number)", "5678 (number)", ...]
   ```
4. **Click a player**:
   ```
   Toggle player clicked: 1234 Type: number
   Current playingXI: []
   Adding player, new array: [1234]
   ```
5. **Click another player**:
   ```
   Toggle player clicked: 5678 Type: number
   Current playingXI: [1234]
   Adding player, new array: [1234, 5678]
   ```

## Summary

### Root Cause
String vs Number type mismatch in player ID comparisons

### Solution  
Normalize all player IDs to numbers using `parseInt()`

### Impact
- ✅ Player selection now works correctly
- ✅ Count displays accurately
- ✅ Captain/VC buttons only show on selected players
- ✅ State management consistent

### Prevention
Always use `parseInt()` when receiving IDs from external sources (API, URL params, etc.)

---

**Test URL**: http://localhost:5173/league/83 → Playing XI tab

**Check Console**: Look for type logs to verify all IDs are numbers
