// tests/unit/transferCalculation.test.js
import { describe, test, expect, beforeEach, afterEach } from '@jest/globals';
import { setupTestDatabase, cleanupTestDatabase, seedBaselineData } from '../helpers/dbSetup.js';
import { calculateTransfers } from '../../src/utils/transferLogic.js';
import { baselineSquad, changedSquad } from '../fixtures/sampleData.js';

describe('Transfer Counting', () => {
  
  beforeEach(async () => {
    await setupTestDatabase();
    await seedBaselineData();
  });

  afterEach(async () => {
    await cleanupTestDatabase();
  });

  // TC-T-004: Count transfers from baseline (player replacements)
  test('should count player replacements as transfers', async () => {
    const baseline = [
      { player_id: 'P1' },
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const current = [
      { player_id: 'P12' }, // Replaced P1
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P13' }, // Replaced P5
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const result = calculateTransfers(baseline, current);

    expect(result.transfersUsed).toBe(2);
    expect(result.transfersRemaining).toBe(8);
    expect(result.changedPlayers).toEqual(['P12', 'P13']);
  });

  // TC-T-005: Re-save same match (no new transfers)
  test('should not count transfers when re-saving same squad', async () => {
    const baseline = [
      { player_id: 'P1' },
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const previous = [
      { player_id: 'P12' }, // 2 transfers already made
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P13' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const current = [...previous]; // Exact same squad

    const result = calculateTransfers(baseline, current, previous);

    expect(result.transfersUsed).toBe(2); // Unchanged from baseline
    expect(result.newTransfersInThisSave).toBe(0);
  });

  // TC-T-006: Re-save with additional transfers
  test('should count additional transfers when modifying existing lineup', async () => {
    const baseline = [
      { player_id: 'P1' },
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const previous = [
      { player_id: 'P12' }, // 2 transfers
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P13' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const current = [
      { player_id: 'P12' },
      { player_id: 'P14' }, // New: replaced P2
      { player_id: 'P15' }, // New: replaced P3
      { player_id: 'P4' },
      { player_id: 'P13' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const result = calculateTransfers(baseline, current, previous);

    expect(result.transfersUsed).toBe(4); // 2 + 2 new
    expect(result.transfersRemaining).toBe(6);
    expect(result.newTransfersInThisSave).toBe(2);
  });

  // TC-T-007: Block when exceeding transfer limit
  test('should block save when transfer limit exceeded', async () => {
    const baseline = [
      { player_id: 'P1' },
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const current = [
      { player_id: 'P12' },
      { player_id: 'P13' },
      { player_id: 'P14' },
      { player_id: 'P15' },
      { player_id: 'P16' },
      { player_id: 'P17' },
      { player_id: 'P18' },
      { player_id: 'P19' },
      { player_id: 'P20' },
      { player_id: 'P21' },
      { player_id: 'P22' }, // 11 transfers (exceeds limit of 10)
    ];

    const result = calculateTransfers(baseline, current);

    expect(result.shouldBlock).toBe(true);
    expect(result.error).toContain('transfer limit');
    expect(result.transfersUsed).toBe(11);
  });

  // TC-T-008: Revert transfer (bring back baseline player)
  test('should decrement counter when reverting to baseline player', async () => {
    const baseline = [
      { player_id: 'P1' },
      { player_id: 'P2' },
      { player_id: 'P3' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const previous = [
      { player_id: 'P12' }, // 3 transfers
      { player_id: 'P13' },
      { player_id: 'P14' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const current = [
      { player_id: 'P1' }, // Reverted from P12
      { player_id: 'P13' },
      { player_id: 'P14' },
      { player_id: 'P4' },
      { player_id: 'P5' },
      { player_id: 'P6' },
      { player_id: 'P7' },
      { player_id: 'P8' },
      { player_id: 'P9' },
      { player_id: 'P10' },
      { player_id: 'P11' },
    ];

    const result = calculateTransfers(baseline, current, previous);

    expect(result.transfersUsed).toBe(2); // Decremented from 3
    expect(result.transfersRemaining).toBe(8);
    expect(result.changeType).toBe('REVERT');
  });
});

describe('Transfer Baseline Calculation', () => {
  
  // TC-T-001: Calculate baseline from most recent locked match
  test('should identify correct baseline match', async () => {
    const matches = [
      { id: 842, match_start: new Date('2025-10-20T10:00:00Z') }, // Locked
      { id: 844, match_start: new Date('2025-10-22T10:00:00Z') }, // Locked
      { id: 846, match_start: new Date('2025-10-28T10:00:00Z') }, // Not started
    ];

    const currentMatchId = 848;
    const now = new Date('2025-10-26T12:00:00Z'); // After 844, before 846

    const baseline = await calculateBaselineMatch(1, currentMatchId, now);

    expect(baseline.matchId).toBe(844);
  });

  // TC-T-002: First Playing XI (no baseline)
  test('should handle first Playing XI with no baseline', async () => {
    const teamId = 1;
    const matchId = 842;

    const result = await calculateTransfers(null, squadData);

    expect(result.baselineMatchId).toBeNull();
    expect(result.transfersUsed).toBe(0);
    expect(result.transfersRemaining).toBe(10);
  });

  // TC-T-003: Block retroactive edits
  test('should prevent editing lineup when future lineup exists', async () => {
    // Team has lineups for: 842, 844, 846
    // Match 844 has started
    // User tries to edit 842

    const result = await validatePlayingXISave({
      teamId: 1,
      matchId: 842,
      leagueId: 100
    });

    expect(result.isAllowed).toBe(false);
    expect(result.error).toContain('Cannot edit retroactive');
  });
});

describe('Edge Cases', () => {
  
  // TC-E-001: Multiple transfers + captain change in one save
  test('should handle transfers and captain change together', async () => {
    const baseline = {
      squad: [
        { player_id: 'P1', is_captain: true, is_vice_captain: false },
        { player_id: 'P2', is_captain: false, is_vice_captain: true },
        { player_id: 'P3' },
        { player_id: 'P4' },
        { player_id: 'P5' },
        { player_id: 'P6' },
        { player_id: 'P7' },
        { player_id: 'P8' },
        { player_id: 'P9' },
        { player_id: 'P10' },
        { player_id: 'P11' },
      ]
    };

    const current = {
      squad: [
        { player_id: 'P12', is_captain: true, is_vice_captain: false },
        { player_id: 'P13', is_captain: false, is_vice_captain: true },
        { player_id: 'P14' },
        { player_id: 'P4' },
        { player_id: 'P5' },
        { player_id: 'P6' },
        { player_id: 'P7' },
        { player_id: 'P8' },
        { player_id: 'P9' },
        { player_id: 'P10' },
        { player_id: 'P11' },
      ]
    };

    const transferResult = calculateTransfers(baseline.squad, current.squad);
    const captainResult = await detectCaptainChange({
      currentCaptain: 'P12',
      currentViceCaptain: 'P13',
      baselineCaptain: 'P1',
      baselineViceCaptain: 'P2',
      previousCaptains: [],
      previousVCs: [],
      currentChangesUsed: 0
    });

    expect(transferResult.transfersUsed).toBe(3);
    expect(captainResult.captainChangesUsed).toBe(1);
  });

  // TC-D-003: Type consistency
  test('should handle VARCHAR vs NUMBER player ID in comparisons', () => {
    const baseline = [{ player_id: '123' }]; // VARCHAR from DB
    const current = [{ player_id: 123 }]; // NUMBER from frontend

    const result = calculateTransfers(baseline, current);

    expect(result.transfersUsed).toBe(0); // Should recognize as same player
  });
});
