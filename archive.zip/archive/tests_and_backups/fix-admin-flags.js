import pool from './src/config/database.js';

async function fixAdminFlags() {
  const client = await pool.connect();
  
  try {
    console.log('=== Fixing is_admin Flags ===\n');
    
    await client.query('BEGIN');
    
    // Update is_admin flag for all league creators
    const result = await client.query(`
      UPDATE fantasy_teams ft
      SET is_admin = TRUE
      FROM fantasy_leagues fl
      WHERE ft.league_id = fl.id
        AND ft.team_owner = fl.created_by
        AND ft.is_admin = FALSE
      RETURNING ft.id, ft.team_name, ft.team_owner, ft.league_id
    `);
    
    console.log(`Updated ${result.rows.length} teams to have is_admin = TRUE`);
    
    if (result.rows.length > 0) {
      console.log('\nUpdated Teams:');
      console.table(result.rows);
    }
    
    await client.query('COMMIT');
    
    // Verify League 84
    console.log('\n=== Verification for League 84 ===');
    const verifyResult = await client.query(`
      SELECT ft.id, ft.team_name, ft.team_owner, ft.is_admin, fl.league_name, fl.created_by
      FROM fantasy_teams ft
      JOIN fantasy_leagues fl ON ft.league_id = fl.id
      WHERE ft.league_id = 84
      ORDER BY ft.id
    `);
    
    console.table(verifyResult.rows);
    
    console.log('\n✅ Admin flags fixed successfully!');
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

fixAdminFlags().catch(err => {
  console.error('Failed:', err);
  process.exit(1);
});
