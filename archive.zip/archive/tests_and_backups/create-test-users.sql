-- Create Test Users for Development
-- These users are auto-verified for testing purposes
-- Password for all test users: test123

-- Test User 1
INSERT INTO users (username, email, password, verification_token, token_expiry, is_verified, created_at)
VALUES (
  'testuser1',
  'test1@example.com',
  '$2b$10$didxd0tZAmehCs8C8ntWE.GucB9wlh4rRyaq8GC0Hkld9bRR5PFby',
  NULL,
  NULL,
  true,
  NOW()
) ON CONFLICT (email) DO NOTHING;

-- Test User 2
INSERT INTO users (username, email, password, verification_token, token_expiry, is_verified, created_at)
VALUES (
  'testuser2',
  'test2@example.com',
  '$2b$10$didxd0tZAmehCs8C8ntWE.GucB9wlh4rRyaq8GC0Hkld9bRR5PFby',
  NULL,
  NULL,
  true,
  NOW()
) ON CONFLICT (email) DO NOTHING;

-- Display created users
SELECT id, username, email, is_verified, created_at 
FROM users 
WHERE email IN ('test1@example.com', 'test2@example.com');
