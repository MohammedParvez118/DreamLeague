// tests/integration/playingXI.api.test.js
import { describe, test, expect, beforeAll, afterAll, beforeEach } from '@jest/globals';
import request from 'supertest';
import app from '../../app.js';
import { setupTestDatabase, cleanupTestDatabase, seedTestData } from '../helpers/dbSetup.js';

describe('POST /api/playing-xi', () => {
  
  beforeAll(async () => {
    await setupTestDatabase();
  });

  afterAll(async () => {
    await cleanupTestDatabase();
  });

  beforeEach(async () => {
    await seedTestData();
  });

  // TC-A-002: Successful save
  test('should save Playing XI successfully', async () => {
    const response = await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 846,
        leagueId: 100,
        squad: [
          { playerId: 'P1', isCaptain: true, isViceCaptain: false },
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          { playerId: 'P3', isCaptain: false, isViceCaptain: false },
          { playerId: 'P4', isCaptain: false, isViceCaptain: false },
          { playerId: 'P5', isCaptain: false, isViceCaptain: false },
          { playerId: 'P6', isCaptain: false, isViceCaptain: false },
          { playerId: 'P7', isCaptain: false, isViceCaptain: false },
          { playerId: 'P8', isCaptain: false, isViceCaptain: false },
          { playerId: 'P9', isCaptain: false, isViceCaptain: false },
          { playerId: 'P10', isCaptain: false, isViceCaptain: false },
          { playerId: 'P11', isCaptain: false, isViceCaptain: false },
        ]
      });

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.message).toContain('saved successfully');
    expect(response.body.data).toHaveProperty('transfersUsed');
    expect(response.body.data).toHaveProperty('captainChangesUsed');
  });

  // TC-A-003: Transfer limit error
  test('should return error when transfer limit exceeded', async () => {
    // First, set up baseline with 10 transfers already used
    await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 846,
        leagueId: 100,
        squad: [
          { playerId: 'P12' }, { playerId: 'P13' }, { playerId: 'P14' },
          { playerId: 'P15' }, { playerId: 'P16' }, { playerId: 'P17' },
          { playerId: 'P18' }, { playerId: 'P19' }, { playerId: 'P20' },
          { playerId: 'P21' }, { playerId: 'P22' }, // 11 transfers
        ]
      });

    // Try to save another lineup with additional transfer
    const response = await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 848,
        leagueId: 100,
        squad: [
          { playerId: 'P23' }, // One more transfer (would be 12 total)
          { playerId: 'P13' }, { playerId: 'P14' },
          { playerId: 'P15' }, { playerId: 'P16' }, { playerId: 'P17' },
          { playerId: 'P18' }, { playerId: 'P19' }, { playerId: 'P20' },
          { playerId: 'P21' }, { playerId: 'P22' },
        ]
      });

    expect(response.status).toBe(400);
    expect(response.body.success).toBe(false);
    expect(response.body.error).toContain('transfer limit');
  });

  // TC-A-004: Captain change limit error
  test('should return error when captain change limit exceeded', async () => {
    // First save: change captain
    await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 846,
        leagueId: 100,
        squad: [
          { playerId: 'P3', isCaptain: true, isViceCaptain: false }, // Changed from P1
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          // ... rest of squad
        ]
      });

    // Second save: try to change to different captain
    const response = await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 848,
        leagueId: 100,
        squad: [
          { playerId: 'P5', isCaptain: true, isViceCaptain: false }, // Different captain
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          // ... rest of squad
        ]
      });

    expect(response.status).toBe(400);
    expect(response.body.success).toBe(false);
    expect(response.body.error).toContain('captain/vice-captain change');
  });

  // TC-C-005: Reuse captain (should succeed)
  test('should allow reusing previously changed captain', async () => {
    // First save: change captain to P3
    await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 846,
        leagueId: 100,
        squad: [
          { playerId: 'P3', isCaptain: true, isViceCaptain: false },
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          // ... rest
        ]
      });

    // Second save: reuse P3 as captain
    const response = await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 848,
        leagueId: 100,
        squad: [
          { playerId: 'P3', isCaptain: true, isViceCaptain: false }, // Same P3
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          // ... rest
        ]
      });

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.data.captainChangesUsed).toBe(1); // Still 1, not 2
  });

  // TC-C-007: Revert to baseline captain
  test('should decrement counter when reverting to baseline captain', async () => {
    // First save: change captain to P3
    await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 846,
        leagueId: 100,
        squad: [
          { playerId: 'P3', isCaptain: true, isViceCaptain: false },
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          // ... rest
        ]
      });

    // Second save: revert to P1 (baseline)
    const response = await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 848,
        leagueId: 100,
        squad: [
          { playerId: 'P1', isCaptain: true, isViceCaptain: false }, // Back to baseline
          { playerId: 'P2', isCaptain: false, isViceCaptain: true },
          // ... rest
        ]
      });

    expect(response.status).toBe(200);
    expect(response.body.data.captainChangesUsed).toBe(0); // Decremented
    expect(response.body.data.captainChangesRemaining).toBe(1);
  });
});

describe('GET /api/playing-xi/:teamId/:matchId', () => {
  
  beforeAll(async () => {
    await setupTestDatabase();
  });

  afterAll(async () => {
    await cleanupTestDatabase();
  });

  // TC-A-001: Get Playing XI with stats
  test('should return Playing XI with transfer and captain stats', async () => {
    const response = await request(app)
      .get('/api/playing-xi/1/846');

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.data).toHaveProperty('squad');
    expect(response.body.data).toHaveProperty('transfersUsed');
    expect(response.body.data).toHaveProperty('transfersRemaining');
    expect(response.body.data).toHaveProperty('captainChangesUsed');
    expect(response.body.data).toHaveProperty('captainChangesRemaining');
    expect(response.body.data).toHaveProperty('baselineMatchId');
  });
});

describe('DELETE /api/playing-xi/:teamId/:matchId', () => {
  
  beforeAll(async () => {
    await setupTestDatabase();
  });

  afterAll(async () => {
    await cleanupTestDatabase();
  });

  // TC-A-005: Delete Playing XI
  test('should delete Playing XI successfully', async () => {
    // First create a Playing XI
    await request(app)
      .post('/api/playing-xi')
      .send({
        teamId: 1,
        matchId: 846,
        leagueId: 100,
        squad: [/* ... */]
      });

    // Then delete it
    const response = await request(app)
      .delete('/api/playing-xi/1/846');

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.message).toContain('deleted successfully');
  });

  // TC-E-002: Recalculate counters after delete
  test('should recalculate counters after deleting intermediate match', async () => {
    // Create lineups for 846 and 848
    await request(app).post('/api/playing-xi').send({
      teamId: 1,
      matchId: 846,
      squad: [/* 3 transfers, 1 captain change */]
    });

    await request(app).post('/api/playing-xi').send({
      teamId: 1,
      matchId: 848,
      squad: [/* based on 846 */]
    });

    // Delete 846
    await request(app).delete('/api/playing-xi/1/846');

    // Check stats for 848 - should recalculate from new baseline
    const response = await request(app).get('/api/transfer-stats/1');

    expect(response.body.data.transfersUsed).toBeLessThanOrEqual(10);
    expect(response.body.data.captainChangesUsed).toBeLessThanOrEqual(1);
  });
});

describe('GET /api/transfer-stats/:teamId', () => {
  
  // TC-A-006: Get transfer stats
  test('should return current transfer and captain stats', async () => {
    const response = await request(app)
      .get('/api/transfer-stats/1');

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.data).toHaveProperty('transfersUsed');
    expect(response.body.data).toHaveProperty('transfersRemaining');
    expect(response.body.data).toHaveProperty('transfersLocked');
    expect(response.body.data).toHaveProperty('captainChangesUsed');
    expect(response.body.data).toHaveProperty('captainChangesRemaining');
    expect(response.body.data).toHaveProperty('captainChangesLocked');
    expect(response.body.data).toHaveProperty('baselineMatchId');
  });
});
