/**
 * Fix missing player_id values in fantasy_squads table
 * by matching player names with squad_players table
 */

import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Fantasy',
  password: 'P@rvezn00r',
  port: 5432,
});

async function fixPlayerIds() {
  const client = await pool.connect();

  try {
    console.log('🔧 Fixing player_id values in fantasy_squads...\n');

    await client.query('BEGIN');

    // Find all fantasy_squads records with NULL player_id
    const nullRecords = await client.query(`
      SELECT id, league_id, team_id, player_name, squad_name, role
      FROM fantasy_squads
      WHERE player_id IS NULL
      ORDER BY league_id, team_id
    `);

    console.log(`📊 Found ${nullRecords.rows.length} records with NULL player_id\n`);

    if (nullRecords.rows.length === 0) {
      console.log('✅ No records to fix!');
      await client.query('COMMIT');
      return;
    }

    let updatedCount = 0;
    let notFoundCount = 0;

    for (const record of nullRecords.rows) {
      // Try to find matching player in squad_players by name
      const playerMatch = await client.query(`
        SELECT player_id, name, role
        FROM squad_players
        WHERE LOWER(name) = LOWER($1)
        LIMIT 1
      `, [record.player_name]);

      if (playerMatch.rows.length > 0) {
        const matchedPlayer = playerMatch.rows[0];
        
        // Update the fantasy_squads record with the found player_id
        await client.query(`
          UPDATE fantasy_squads
          SET player_id = $1
          WHERE id = $2
        `, [matchedPlayer.player_id, record.id]);

        console.log(`✅ Updated: "${record.player_name}" -> player_id: ${matchedPlayer.player_id}`);
        updatedCount++;
      } else {
        console.log(`⚠️  Not found in squad_players: "${record.player_name}" (league: ${record.league_id}, team: ${record.team_id})`);
        notFoundCount++;
      }
    }

    await client.query('COMMIT');

    console.log('\n' + '='.repeat(60));
    console.log(`✅ Updated: ${updatedCount} records`);
    console.log(`⚠️  Not found: ${notFoundCount} records`);
    console.log('='.repeat(60));

    // Show final state
    const finalCheck = await client.query(`
      SELECT 
        league_id,
        team_id,
        COUNT(*) as total_players,
        COUNT(player_id) as with_player_id,
        COUNT(*) - COUNT(player_id) as missing_player_id
      FROM fantasy_squads
      GROUP BY league_id, team_id
      ORDER BY league_id, team_id
    `);

    console.log('\n📊 Final State by Team:');
    console.table(finalCheck.rows);

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Error fixing player IDs:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

fixPlayerIds()
  .then(() => {
    console.log('\n✅ Fix complete!');
    process.exit(0);
  })
  .catch(err => {
    console.error('❌ Script failed:', err);
    process.exit(1);
  });
