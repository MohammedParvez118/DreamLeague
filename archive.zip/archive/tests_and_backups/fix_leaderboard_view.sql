-- Fix league_leaderboard view to show teams even without match scores
-- This allows the leaderboard to display teams before any matches are completed

DROP VIEW IF EXISTS league_leaderboard;

CREATE OR REPLACE VIEW league_leaderboard AS
SELECT 
  ft.league_id,
  ft.id AS team_id,
  ft.team_name,
  ft.team_owner,
  COALESCE(SUM(tms.total_points), 0) AS total_points,
  COALESCE(COUNT(tms.id), 0) AS matches_played,
  COALESCE(AVG(tms.total_points)::INTEGER, 0) AS avg_points_per_match,
  COALESCE(MAX(tms.total_points), 0) AS highest_match_score,
  COALESCE(MIN(tms.total_points), 0) AS lowest_match_score,
  RANK() OVER (PARTITION BY ft.league_id ORDER BY COALESCE(SUM(tms.total_points), 0) DESC) AS rank
FROM fantasy_teams ft
LEFT JOIN team_match_scores tms ON ft.id = tms.team_id AND ft.league_id = tms.league_id
GROUP BY ft.league_id, ft.id, ft.team_name, ft.team_owner
ORDER BY rank;

COMMENT ON VIEW league_leaderboard IS 'Aggregated leaderboard showing team rankings by total points - shows all teams even without match scores';

-- Test query
SELECT 
  rank,
  team_name,
  team_owner,
  total_points,
  matches_played,
  avg_points_per_match
FROM league_leaderboard 
WHERE league_id = 84
ORDER BY rank;
