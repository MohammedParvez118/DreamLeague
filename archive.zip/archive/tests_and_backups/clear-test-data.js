import db from './src/config/database.js';

console.log('Clearing tournament 10884 squads...');

db.query('DELETE FROM squad_players WHERE squad_id IN (SELECT squad_id FROM squads WHERE series_id = 10884)')
  .then(() => db.query('DELETE FROM squads WHERE series_id = 10884'))
  .then(() => {
    console.log('✅ Cleared successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error:', error.message);
    process.exit(1);
  });
