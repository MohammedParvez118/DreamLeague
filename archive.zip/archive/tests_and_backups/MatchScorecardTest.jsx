import React from 'react';
import { useParams, useSearchParams } from 'react-router-dom';

const MatchScorecardTest = () => {
    const { tournamentId, matchId } = useParams();
    const [searchParams] = useSearchParams();
    const rapidApiMatchId = searchParams.get('rapidApiMatchId');

    return (
        <div style={{ padding: '20px', background: 'white', margin: '20px' }}>
            <h1>Match Scorecard Test Page</h1>
            <p><strong>Tournament ID:</strong> {tournamentId}</p>
            <p><strong>Match ID:</strong> {matchId}</p>
            <p><strong>RapidAPI Match ID:</strong> {rapidApiMatchId}</p>
            <p>If you can see this, the route is working!</p>
        </div>
    );
};

export default MatchScorecardTest;
