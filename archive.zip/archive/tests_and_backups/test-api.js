import axios from 'axios';

const matchId = '114960';

const options = {
  method: 'GET',
  url: `https://cricbuzz-cricket.p.rapidapi.com/mcenter/v1/${matchId}/scard`,
  headers: {
    'x-rapidapi-key': 'f8caabb8b1msh37ba48711d0db0ap100b7ajsnb96b28f37ac9',
    'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com'
  }
};

try {
  const response = await axios.request(options);
  console.log('API Response Keys:', Object.keys(response.data));
  console.log('scoreCard exists:', response.data.scoreCard !== undefined);
  
  if (response.data.scoreCard && response.data.scoreCard[0]) {
    const firstInnings = response.data.scoreCard[0];
    console.log('\nFirst innings keys:', Object.keys(firstInnings));
    console.log('batTeamDetails exists:', firstInnings.batTeamDetails !== undefined);
    if (firstInnings.batTeamDetails) {
      console.log('batsmenData exists:', firstInnings.batTeamDetails.batsmenData !== undefined);
      if (firstInnings.batTeamDetails.batsmenData) {
        const batKeys = Object.keys(firstInnings.batTeamDetails.batsmenData);
        console.log('Number of batsmen:', batKeys.length);
        if (batKeys.length > 0) {
          const firstBat = firstInnings.batTeamDetails.batsmenData[batKeys[0]];
          console.log('\nFirst batsman sample:');
          console.log(JSON.stringify(firstBat, null, 2));
        }
      }
    }
    
    console.log('\nbowlTeamDetails exists:', firstInnings.bowlTeamDetails !== undefined);
    if (firstInnings.bowlTeamDetails) {
      console.log('bowlersData exists:', firstInnings.bowlTeamDetails.bowlersData !== undefined);
      if (firstInnings.bowlTeamDetails.bowlersData) {
        const bowlKeys = Object.keys(firstInnings.bowlTeamDetails.bowlersData);
        console.log('Number of bowlers:', bowlKeys.length);
        if (bowlKeys.length > 0) {
          const firstBowl = firstInnings.bowlTeamDetails.bowlersData[bowlKeys[0]];
          console.log('\nFirst bowler sample:');
          console.log(JSON.stringify(firstBowl, null, 2));
        }
      }
    }
  }
} catch (error) {
  console.error('Error:', error.response?.status, error.response?.statusText || error.message);
}
