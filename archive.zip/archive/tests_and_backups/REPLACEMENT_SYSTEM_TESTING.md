# Replacement System - Testing & Verification

## ✅ Migration Completed

**Date**: January 27, 2025  
**Status**: SUCCESS  

### Migration Results
- ✅ `squad_replacements` table created
- ✅ `fantasy_squads.is_injured` column added
- ✅ `fantasy_teams.is_admin` column added
- ✅ `admin_pending_replacements` view created
- ✅ `apply_replacement_to_future_matches()` function created
- ✅ **37 league creators** set as admins

---

## 🚀 System Status

### Backend
- ✅ Database migration: **COMPLETE**
- ✅ Replacement controller: **INTEGRATED** (600+ lines)
- ✅ API routes: **INTEGRATED** (6 endpoints)
- ✅ Server running: **YES** (http://localhost:3000)

### Frontend  
- ✅ API service: **UPDATED** (`replacementAPI` added)
- ✅ ReplacementPanel: **CREATED** (360+ lines)
- ✅ AdminReplacementView: **CREATED** (240+ lines)
- ✅ CSS styling: **CREATED** (830+ lines combined)
- ✅ ViewLeague integration: **COMPLETE** (using ReplacementPanel)
- ✅ Tab label: **UPDATED** ("Transfers" → "Replacements")

---

## 🧪 Testing Guide

### 1. Prerequisites
- Backend server running on http://localhost:3000
- Frontend running (typically http://localhost:3001)
- At least one league created with teams
- Some players in squad

### 2. User Flow Testing

#### A. Request Replacement (User)
1. Navigate to a league you've joined
2. Click **"🔄 Replacements"** tab (formerly "Transfers")
3. Select a player from your squad (Out Player)
4. Select a replacement from available players (In Player)
5. Enter reason: "Player injured, out for 2 weeks"
6. Click **"Request Replacement"**
7. ✅ **Expected**: 
   - Success message appears
   - Request shows in history table with status "PENDING"

#### B. Cancel Pending Request (User)
1. In Replacements tab, find pending request in history
2. Click **"Cancel"** button
3. Confirm cancellation
4. ✅ **Expected**: Request removed from history

#### C. Admin Approval (League Creator)
1. As league creator, go to Replacements tab
2. Click **"View Pending Approvals"** button
3. See all pending requests league-wide
4. Click **"✓ Approve"** on a request
5. Review modal shows what will happen:
   - Mark injured player
   - Add replacement
   - Auto-update Playing XIs
   - Preserve points
6. Optionally add admin notes
7. Click **"Confirm Approval"**
8. ✅ **Expected**:
   - Success message: "Replacement approved! Updated X future Playing XI(s)"
   - Request disappears from pending list
   - User sees approved status in their history

#### D. Admin Rejection (League Creator)
1. In Admin view, click **"✗ Reject"** on a request
2. Enter rejection reason (required)
3. Click **"Confirm Rejection"**
4. ✅ **Expected**:
   - Request status changes to "REJECTED"
   - User can view admin notes
   - Player not marked as injured

### 3. Verification Checks

#### Check 1: Injured Player Status
After approval:
1. Go to **"👥 My Team"** tab
2. ✅ **Expected**: Injured player shows **RED border** with "INJURED" badge
3. Hover/click: Should show replacement player name

#### Check 2: Replacement in Squad
After approval:
1. Go to **"👥 My Team"** tab
2. ✅ **Expected**: New player added to squad (total should increase by 1, unless at max)

#### Check 3: Auto-Replacement in Playing XI
After approval:
1. Go to **"🏏 Playing XI"** tab
2. View upcoming matches
3. ✅ **Expected**: 
   - Injured player **REPLACED** in all future Playing XIs
   - Replacement player now in Playing XI
   - Captain/Vice-captain preserved if applicable

#### Check 4: Points Attribution
After a match completes:
1. Go to **"⚡ Matches"** tab
2. View match breakdown
3. ✅ **Expected**: 
   - Points earned STAY with injured player (not transferred)
   - Injured player marked with injury indicator
   - Replacement earns points normally going forward

#### Check 5: Selection Block
Try to create new Playing XI:
1. Go to **"🏏 Playing XI"** tab
2. Try to add injured player to new XI
3. ✅ **Expected**: 
   - Injured player NOT available in selection
   - Or disabled with injury indicator

---

## 🔍 API Testing (Postman/cURL)

### 1. Request Replacement
```bash
curl -X POST http://localhost:3000/api/league/83/team/104/replacements/request \
-H "Content-Type: application/json" \
-d '{
  "outPlayerId": 12345,
  "inPlayerId": 67890,
  "reason": "Player injured, out for 2 weeks"
}'
```

**Expected Response** (201):
```json
{
  "message": "Replacement request submitted successfully",
  "replacement": {
    "replacement_id": 1,
    "status": "pending",
    "out_player_name": "Player A",
    "in_player_name": "Player B",
    "replacement_start_match": "Match 5"
  }
}
```

### 2. Get Team Replacements
```bash
curl http://localhost:3000/api/league/83/team/104/replacements
```

**Expected Response** (200):
```json
{
  "replacements": [...],
  "summary": {
    "total": 5,
    "pending": 1,
    "approved": 3,
    "rejected": 1
  }
}
```

### 3. Get Squad with Injury Status
```bash
curl http://localhost:3000/api/league/83/team/104/squad-with-status
```

**Expected Response** (200):
```json
{
  "squad": [
    {
      "player_id": 12345,
      "player_name": "Player A",
      "isInjured": true,
      "replacementName": "Player B"
    },
    ...
  ],
  "availablePlayers": [...]
}
```

### 4. Get Pending Replacements (Admin)
```bash
curl "http://localhost:3000/api/league/83/admin/replacements/pending?userEmail=admin@example.com"
```

**Expected Response** (200):
```json
{
  "pending": [
    {
      "replacement_id": 1,
      "team_name": "Team A",
      "team_owner_email": "user@example.com",
      "out_player_name": "Player A",
      "in_player_name": "Player B",
      "reason": "Injured",
      "out_player_points_earned": 125,
      "out_player_matches_played": 5
    }
  ]
}
```

### 5. Approve Replacement (Admin)
```bash
curl -X POST http://localhost:3000/api/league/83/admin/replacements/1/review \
-H "Content-Type: application/json" \
-d '{
  "action": "approve",
  "adminEmail": "admin@example.com",
  "adminNotes": "Approved - valid injury"
}'
```

**Expected Response** (200):
```json
{
  "message": "Replacement approved successfully",
  "affectedMatches": 3
}
```

### 6. Reject Replacement (Admin)
```bash
curl -X POST http://localhost:3000/api/league/83/admin/replacements/1/review \
-H "Content-Type: application/json" \
-d '{
  "action": "reject",
  "adminEmail": "admin@example.com",
  "adminNotes": "Invalid reason provided"
}'
```

**Expected Response** (200):
```json
{
  "message": "Replacement request rejected successfully"
}
```

---

## 🐛 Common Issues & Solutions

### Issue 1: "Not an admin" error
**Problem**: User trying to access admin endpoints  
**Solution**: Only league creator (`league.created_by`) can access admin features

### Issue 2: Player already injured
**Problem**: Cannot request replacement for already injured player  
**Solution**: Cancel previous replacement or wait for it to be processed

### Issue 3: Replacement player not available
**Problem**: Selected player already in another squad  
**Solution**: Choose different replacement player from available list

### Issue 4: No future matches
**Problem**: All matches already played  
**Solution**: Cannot replace if no future matches (replacement_start_match_id is NULL)

### Issue 5: Frontend not showing Replacements tab
**Problem**: Still seeing "Transfers" tab  
**Solution**: 
1. Clear browser cache
2. Restart frontend server
3. Check console for errors

---

## 📊 Database Queries for Verification

### Check Admins
```sql
SELECT ft.id, ft.team_name, ft.team_owner, ft.is_admin, fl.name as league_name
FROM fantasy_teams ft
JOIN fantasy_leagues fl ON ft.league_id = fl.id
WHERE ft.is_admin = TRUE;
```

### Check Replacement Requests
```sql
SELECT * FROM squad_replacements 
WHERE league_id = 83 
ORDER BY requested_at DESC;
```

### Check Injured Players
```sql
SELECT fs.*, p.name as player_name
FROM fantasy_squads fs
JOIN players p ON fs.player_id = p.id
WHERE fs.is_injured = TRUE;
```

### Check Auto-Replacement Applied
```sql
SELECT tpx.*, p.name as player_name
FROM team_playing_xi tpx
JOIN players p ON tpx.player_id = p.id
WHERE tpx.team_id = 104 
AND tpx.match_id > 842
ORDER BY tpx.match_id;
```

### View Admin Pending
```sql
SELECT * FROM admin_pending_replacements 
WHERE league_id = 83;
```

---

## ✅ Final Checklist

### Backend Testing
- [ ] Migration ran successfully (all 5 structures created)
- [ ] Server starts without errors
- [ ] All 6 API endpoints respond
- [ ] Request validation works (invalid player IDs rejected)
- [ ] Admin verification works (non-admin blocked)
- [ ] Auto-replacement function executes correctly

### Frontend Testing
- [ ] Replacements tab visible in league view
- [ ] Request form works (all fields)
- [ ] Squad displays with injury indicators
- [ ] History table shows all statuses
- [ ] Admin button visible for league creator only
- [ ] Admin view shows pending requests
- [ ] Approve/reject modals work
- [ ] Success/error messages display

### Integration Testing
- [ ] Request → Admin approval → Squad updated
- [ ] Request → Admin approval → Playing XIs updated
- [ ] Request → Admin rejection → Status updated
- [ ] Cancel pending request → Request deleted
- [ ] Points stay with injured player after match
- [ ] Injured player blocked from selection
- [ ] Replacement player available for selection

### Edge Cases
- [ ] Request replacement when no future matches
- [ ] Request replacement for already injured player
- [ ] Non-admin tries to access admin endpoints
- [ ] Cancel already approved/rejected request (should fail)
- [ ] Replacement player already in squad (should fail)

---

## 🎉 Success Criteria

The Replacement System is fully functional if:

1. ✅ Users can request replacements with reason
2. ✅ League creators see pending requests
3. ✅ Admins can approve with auto-Playing XI updates
4. ✅ Admins can reject with notes
5. ✅ Injured players show red indicator
6. ✅ Points stay with injured player
7. ✅ Injured players blocked from new selections
8. ✅ No errors in console or server logs

---

## 📝 Notes

- **Backward Compatibility**: Old `TransferPanel` component still exists but unused
- **No Data Loss**: All existing squads and Playing XIs remain intact
- **Performance**: Database view optimizes admin queries
- **Scalability**: No limits on replacement requests

---

**Testing Date**: _____________  
**Tester**: _____________  
**Status**: _____________  

