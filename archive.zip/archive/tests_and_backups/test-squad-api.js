import axios from 'axios';

async function testSquadAPI() {
  try {
    console.log('Testing squad API for league 83, team 103...\n');
    
    const response = await axios.get('http://localhost:3000/api/league/83/team/103/squad');
    const data = response.data;
    
    console.log('Response status:', response.status);
    console.log('Response data:', JSON.stringify(data, null, 2));
    
    if (data.data && data.data.squad) {
      console.log(`\nSquad length: ${data.data.squad.length}`);
      if (data.data.squad.length > 0) {
        console.log('\nFirst 3 players:');
        console.table(data.data.squad.slice(0, 3));
      }
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

testSquadAPI();
