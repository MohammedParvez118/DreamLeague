import pool from './src/config/database.js';

async function fixTriggerAndApplyReplacement() {
  const client = await pool.connect();
  
  try {
    console.log('=== Fixing Trigger Logic ===\n');
    
    await client.query('BEGIN');
    
    // Fix the validate_playing_xi trigger to handle UPDATEs correctly
    console.log('1. Updating validate_playing_xi trigger to allow replacements...\n');
    
    await client.query(`
      CREATE OR REPLACE FUNCTION validate_playing_xi()
      RETURNS TRIGGER AS $$
      DECLARE
        player_count INTEGER;
        captain_count INTEGER;
        vice_captain_count INTEGER;
      BEGIN
        -- Skip validation for UPDATEs that are just changing player details
        -- (i.e., replacements that don't add/remove players from the count)
        IF TG_OP = 'UPDATE' THEN
          -- For updates, we're just swapping one player for another
          -- No need to check player count since we're not adding a new row
          -- Just check if the NEW player is in the squad
          IF NOT EXISTS (
            SELECT 1 FROM fantasy_squads fs
            WHERE fs.team_id = NEW.team_id 
            AND fs.player_id = NEW.player_id
          ) THEN
            RAISE EXCEPTION 'Player % not in team squad', NEW.player_id;
          END IF;
          
          RETURN NEW;
        END IF;
        
        -- For INSERTs, do full validation
        -- Check if player is in team's squad
        IF NOT EXISTS (
          SELECT 1 FROM fantasy_squads fs
          WHERE fs.team_id = NEW.team_id 
          AND fs.player_id = NEW.player_id
        ) THEN
          RAISE EXCEPTION 'Player % not in team squad', NEW.player_id;
        END IF;

        -- Count players for this team-match combination
        SELECT COUNT(*) INTO player_count
        FROM team_playing_xi
        WHERE team_id = NEW.team_id AND match_id = NEW.match_id;

        IF player_count >= 11 THEN
          RAISE EXCEPTION 'Playing XI already has 11 players for this match';
        END IF;

        -- Validate only one captain
        IF NEW.is_captain THEN
          SELECT COUNT(*) INTO captain_count
          FROM team_playing_xi
          WHERE team_id = NEW.team_id 
          AND match_id = NEW.match_id 
          AND is_captain = TRUE
          AND id != COALESCE(NEW.id, 0);
          
          IF captain_count > 0 THEN
            RAISE EXCEPTION 'Team already has a captain for this match';
          END IF;
        END IF;

        -- Validate only one vice-captain
        IF NEW.is_vice_captain THEN
          SELECT COUNT(*) INTO vice_captain_count
          FROM team_playing_xi
          WHERE team_id = NEW.team_id 
          AND match_id = NEW.match_id 
          AND is_vice_captain = TRUE
          AND id != COALESCE(NEW.id, 0);
          
          IF vice_captain_count > 0 THEN
            RAISE EXCEPTION 'Team already has a vice-captain for this match';
          END IF;
        END IF;

        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;
    `);
    
    console.log('✅ Trigger function updated\n');
    
    // Revert the apply_replacement function to original (simpler) version
    console.log('2. Simplifying apply_replacement_to_future_matches function...\n');
    
    await client.query(`
      CREATE OR REPLACE FUNCTION apply_replacement_to_future_matches(
        p_team_id INTEGER,
        p_out_player_id VARCHAR(50),
        p_in_player_id VARCHAR(50),
        p_in_player_name TEXT,
        p_in_player_role VARCHAR(50),
        p_in_player_squad VARCHAR(100),
        p_start_match_id INTEGER
      )
      RETURNS TABLE(
        match_id INTEGER,
        replaced BOOLEAN,
        was_captain BOOLEAN,
        was_vice_captain BOOLEAN
      ) AS $$
      BEGIN
        RETURN QUERY
        WITH future_matches AS (
          SELECT lm.id as match_id
          FROM league_matches lm
          WHERE lm.id >= p_start_match_id
            AND lm.match_start > NOW()
        ),
        replacements AS (
          UPDATE team_playing_xi tpxi
          SET 
            player_id = p_in_player_id,
            player_name = p_in_player_name,
            player_role = p_in_player_role,
            squad_name = p_in_player_squad,
            updated_at = NOW()
          WHERE tpxi.team_id = p_team_id
            AND tpxi.player_id = p_out_player_id
            AND tpxi.match_id IN (SELECT fm.match_id FROM future_matches fm)
          RETURNING 
            tpxi.match_id,
            TRUE as replaced,
            tpxi.is_captain as was_captain,
            tpxi.is_vice_captain as was_vice_captain
        )
        SELECT * FROM replacements;
      END;
      $$ LANGUAGE plpgsql;
    `);
    
    console.log('✅ Function updated\n');
    
    await client.query('COMMIT');
    
    // Now test the replacement
    console.log('3. Applying replacement for Team 105...\n');
    
    const result = await client.query(`
      SELECT * FROM apply_replacement_to_future_matches(
        105,
        '10276',
        '10808',
        'Mohammed Siraj',
        'Bowler',
        'Gujarat Titans',
        901
      )
    `);
    
    console.log(`✅ Replaced in ${result.rows.length} matches\n`);
    
    if (result.rows.length > 0) {
      console.log('Updated Matches (Captain/VC status preserved):');
      console.table(result.rows);
    } else {
      console.log('⚠️ No matches were updated (they may have already been processed)');
    }
    
    // Verify
    console.log('\n=== Verification ===\n');
    
    const verify = await client.query(`
      SELECT 
        tpxi.match_id,
        lm.match_description,
        lm.match_start,
        tpxi.player_id,
        tpxi.player_name,
        tpxi.is_captain,
        tpxi.is_vice_captain
      FROM team_playing_xi tpxi
      JOIN league_matches lm ON tpxi.match_id = lm.id
      WHERE tpxi.team_id = 105
        AND tpxi.match_id >= 904
        AND lm.match_start > NOW()
      ORDER BY tpxi.match_id
      LIMIT 5
    `);
    
    console.log('Playing XI for future matches:');
    console.table(verify.rows);
    
    console.log('\n✅ Done!');
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

fixTriggerAndApplyReplacement().catch(err => {
  console.error('Failed:', err);
  process.exit(1);
});
