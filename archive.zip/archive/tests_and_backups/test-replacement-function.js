import pool from './src/config/database.js';

async function testReplacementFunction() {
  try {
    console.log('=== Testing Replacement Function for Team 105 ===\n');
    
    // Manually run the function to see what happens
    const result = await pool.query(`
      SELECT * FROM apply_replacement_to_future_matches(
        105,           -- team_id
        '10276',       -- out_player_id (Ishan Kishan)
        '10808',       -- in_player_id (Mohammed Siraj)
        'Mohammed Siraj',
        'Bowler',
        'Gujarat Titans',
        901            -- start_match_id
      )
    `);
    
    console.log(`Function returned ${result.rows.length} rows\n`);
    
    if (result.rows.length > 0) {
      console.log('Matches that were updated:');
      console.table(result.rows);
    } else {
      console.log('❌ No matches were updated!');
      console.log('\nPossible reasons:');
      console.log('1. No Playing XI exists for future matches (>= 901 AND match_start > NOW())');
      console.log('2. Ishan Kishan is not in the Playing XI for those matches');
      console.log('3. The replacement was already applied');
    }
    
    // Check what's actually in the Playing XI for future matches
    console.log('\n=== Checking Playing XI for Future Matches ===\n');
    
    const futureXI = await pool.query(`
      SELECT 
        tpxi.match_id,
        lm.match_description,
        lm.match_start,
        tpxi.player_id,
        tpxi.player_name,
        tpxi.is_captain,
        tpxi.is_vice_captain
      FROM team_playing_xi tpxi
      JOIN league_matches lm ON tpxi.match_id = lm.id
      WHERE tpxi.team_id = 105
        AND tpxi.match_id >= 901
        AND lm.match_start > NOW()
        AND tpxi.player_id IN ('10276', '10808')
      ORDER BY tpxi.match_id, tpxi.player_id
      LIMIT 10
    `);
    
    if (futureXI.rows.length > 0) {
      console.log('Players in future Playing XI:');
      console.table(futureXI.rows);
    } else {
      console.log('No Playing XI found for future matches');
    }
    
    await pool.end();
  } catch (error) {
    console.error('Error:', error);
    await pool.end();
    process.exit(1);
  }
}

testReplacementFunction();
