# Testing Documentation - Ready to Use ✅

## 📚 Documentation Files Updated

### 1. **POSTMAN_TESTING_GUIDE.md** ✅ FULLY UPDATED
**Location:** `tests/POSTMAN_TESTING_GUIDE.md`

**What's New:**
- ✅ All endpoints updated with correct `/league/:leagueId` paths
- ✅ DELETE section removed (incompatible with sequential system)
- ✅ Sequential blocking UI tests added (canEdit field)
- ✅ Deadline timer verification (secondsUntilStart)
- ✅ League ID fix documented
- ✅ Recent fixes troubleshooting section
- ✅ Updated expected responses with new fields

**Use This For:** Step-by-step manual testing with clear expected responses

---

### 2. **POSTMAN_COLLECTION_UPDATE_GUIDE.md** ✅ NEW
**Location:** `tests/POSTMAN_COLLECTION_UPDATE_GUIDE.md`

**What It Contains:**
- URL migration guide (old → new routes)
- Find & replace instructions
- New tests to add
- Tests to remove (DELETE section)
- Response field changes
- Common issues after update

**Use This For:** Updating your existing Postman collection JSON file

---

### 3. **Fantasy-Playing-XI-Sequential.postman_collection.json** ⚠️ NEEDS MANUAL UPDATE
**Location:** `tests/Fantasy-Playing-XI-Sequential.postman_collection.json`

**Status:** 
- Header updated with latest description
- **URLs need manual update** (old paths still present)

**Quick Fix:**
Follow the **POSTMAN_COLLECTION_UPDATE_GUIDE.md** to update URLs, or create requests manually using **POSTMAN_TESTING_GUIDE.md**

---

## 🚀 Recommended Testing Approach

### Option 1: Manual Testing (Easiest) ⭐
Use **POSTMAN_TESTING_GUIDE.md** as your reference:
1. Create new Postman requests manually
2. Copy URLs and request bodies from the guide
3. Verify responses match expected outputs
4. All endpoints are correct and up-to-date

### Option 2: Update Existing Collection
Use **POSTMAN_COLLECTION_UPDATE_GUIDE.md**:
1. Open your Postman collection
2. Update each request URL using find & replace
3. Remove DELETE tests
4. Add new tests for sequential blocking and match lock status

### Option 3: Hybrid Approach (Recommended) 🎯
1. Use **POSTMAN_TESTING_GUIDE.md** for step-by-step testing
2. Create new Postman requests as you go
3. Save successful requests to a new collection
4. Build your own updated collection

---

## 🧪 Key Test Scenarios (All Documented)

### ✅ Covered in POSTMAN_TESTING_GUIDE.md:

1. **Setup & Verification**
   - Check league transfer limit
   - Check team free changes status
   - Get transfer stats
   - **NEW:** Check match lock status (deadline timer)

2. **Match 842 - First Match**
   - Get empty Playing XI
   - Save first lineup (0 transfers)
   - **NEW:** Get matches with status

3. **Match 844 - Sequential Blocking & Auto-Save**
   - **NEW:** Test sequential blocking (canEdit: false before Match 842 locks)
   - Get auto-prefilled lineup after Match 842 locks
   - Save with 2 player transfers
   - Verify transfer stats

4. **Match 846 - Free Captain Change**
   - Get auto-prefilled lineup
   - Change captain (0 transfers - free)
   - Verify free change used

5. **Match 848 - Paid Captain Change**
   - Change captain (1 transfer - costs)
   - Verify transfer count increased

6. **Edge Cases**
   - Sequential access blocked (UI disabled)
   - Locked match editing
   - Transfer limit exceeded
   - Invalid lineup (< 11 players, no captain)

7. **Rolling Baseline**
   - Re-add player from old match (still costs transfer)

---

## 📋 Testing Checklist

Before you start:
- [ ] Backend server running (`nodemon app.js`)
- [ ] Database migration applied
- [ ] Routes using `playingXiControllerAdapter.js`
- [ ] Latest fixes applied:
  - [ ] League ID in INSERT statements
  - [ ] DELETE removed from routes
  - [ ] secondsUntilStart calculation
  - [ ] canEdit/sequentialError in frontend

Testing steps:
- [ ] Open `tests/POSTMAN_TESTING_GUIDE.md`
- [ ] Follow test sequence in order (1 → 2 → 3...)
- [ ] Create Postman requests using exact URLs from guide
- [ ] Verify each response matches expected output
- [ ] Test sequential blocking behavior
- [ ] Test deadline timer display
- [ ] Verify auto-save mechanism
- [ ] Check transfer counting accuracy

---

## 🆕 What's Different (Latest Updates)

### 1. API Endpoints
**Old:** `/api/playing-xi/:teamId/:matchId`  
**New:** `/api/league/:leagueId/team/:teamId/match/:matchId/playing-xi`

### 2. DELETE Removed
**Old:** `DELETE /api/playing-xi/:teamId/:matchId`  
**New:** ❌ **REMOVED** (incompatible with sequential locking)

### 3. New Response Fields
- `canEdit` (boolean) - Whether form should be enabled
- `errorMessage` (string|null) - Sequential blocking message
- `secondsUntilStart` (number) - For countdown timer

### 4. Sequential Blocking
**Old:** API error on save attempt  
**New:** Frontend disables form based on `canEdit` flag

### 5. League ID Fix
**Old:** Missing in INSERT, causing constraint violation  
**New:** Included in all database operations

---

## 🎯 Quick Start

1. **Open:** `tests/POSTMAN_TESTING_GUIDE.md`
2. **Read:** Section 1 (Setup & Verification)
3. **Create:** First Postman request from the guide
4. **Test:** Send request and verify response
5. **Continue:** Follow the guide sequentially
6. **Document:** Save working requests to your collection

---

## 📊 Expected Test Results

After completing all tests:

| Match | Transfers | Total Used | Remaining | Notes |
|-------|-----------|------------|-----------|-------|
| 842 | 0 | 0 | 10 | First match, no baseline |
| 844 | 2 | 2 | 8 | 2 player changes |
| 846 | 0 | 2 | 8 | Free captain change |
| 848 | 1 | 3 | 7 | Paid captain change |

**Database Verification:**
```sql
-- Should have 11 players per match
SELECT match_id, COUNT(*) 
FROM team_playing_xi 
WHERE team_id = 1 
GROUP BY match_id;
```

---

## 🐛 Common Issues & Solutions

All documented in **POSTMAN_TESTING_GUIDE.md** section "🐛 Troubleshooting":

- ✅ "null value in column league_id" → FIXED
- ✅ "Deadline showing NaNh NaNm" → FIXED
- ✅ "DELETE endpoint not found" → EXPECTED (removed)
- ✅ "Form shows API error" → FIXED (uses canEdit now)
- ✅ Sequential blocking not working → Check canEdit field
- ✅ Previous match not saved → Auto-save handles this

---

## 📞 Need Help?

1. **Start with:** `POSTMAN_TESTING_GUIDE.md` - Complete walkthrough
2. **For collection updates:** `POSTMAN_COLLECTION_UPDATE_GUIDE.md`
3. **For fixes:** See "Recent Updates" section in testing guide
4. **For architecture:** See `COMPLETE_IMPLEMENTATION_ALIGNED.md`

---

## ✅ Summary

**Ready to test:**
- ✅ POSTMAN_TESTING_GUIDE.md - Fully updated with all latest changes
- ✅ POSTMAN_COLLECTION_UPDATE_GUIDE.md - New file with migration instructions
- ⚠️ Fantasy-Playing-XI-Sequential.postman_collection.json - Needs URL updates

**Recommendation:** Use POSTMAN_TESTING_GUIDE.md as your primary testing reference. All endpoints, request bodies, and expected responses are current and accurate.

**Start testing now!** 🚀
