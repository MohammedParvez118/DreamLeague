# 🧪 Match Scorecard Feature - Testing Guide

## ✅ Current Status

**Backend**: 🟢 Running on http://localhost:3000  
**Frontend**: 🟢 Running on http://localhost:5173  
**Database**: 🟢 Tables created and ready

---

## 🐛 Issue Fixed

### Problem
When clicking on a match, the URL was correct:
```
http://localhost:5173/tournament/tournament-fixtures/9596/116912?rapidApiMatchId=116912
```

But the frontend was showing a blank page.

### Root Cause
Import path case mismatch in `App.jsx`:
```jsx
// ❌ Wrong (uppercase Tournament)
import MatchScorecard from './pages/Tournament/MatchScorecard';

// ✅ Correct (lowercase tournament)
import MatchScorecard from './pages/tournament/MatchScorecard';
```

### Solution Applied
1. Fixed import path in `App.jsx` to use lowercase `tournament`
2. Cleared Vite cache: `rm -rf node_modules/.vite`
3. Restarted both backend and frontend servers

---

## 🧪 Testing Steps

### 1. Verify Servers are Running

**Backend**:
```bash
curl http://localhost:3000/health
# Should return: {"status":"ok",...}
```

**Frontend**:
```
Open browser: http://localhost:5173
```

### 2. Navigate to Match Scorecard

**Step-by-step**:
1. Login to the application
2. Click **"Tournaments"** in navigation
3. Click on any tournament from the list
4. Click **"Fixtures"** tab
5. Click on any **match row**
6. You should see the Match Scorecard page

### 3. Test Scorecard Loading

**Scenario A: First Time (No Data in DB)**
- Page loads
- Shows message: "No scorecard data available"
- See **"Fetch Scorecard"** button
- Click the button
- API call made (costs 1 request)
- Data fetched and stored in DB
- Scorecard displays

**Scenario B: Second Time (Data in DB)**
- Page loads instantly
- Shows scorecard from database
- Badge shows: "Data source: Database (Cached)"
- **"Refresh"** button visible in header
- Click Refresh to update from API

### 4. Verify Scorecard Display

**Check these elements**:
- ✅ Innings tabs (if multiple innings)
- ✅ Batting table with player stats
- ✅ Bowling table with bowler stats
- ✅ Player badges (Captain, Wicket-Keeper, Overseas)
- ✅ Fall of wickets section
- ✅ Partnership breakdown
- ✅ Match summary with final score
- ✅ Data source badge
- ✅ Refresh button

---

## 🔍 Verify Database

### Check if data was stored:

```sql
-- Check match summary
SELECT * FROM match_summaries WHERE match_id = 116912;

-- Check batting stats
SELECT player_name, runs, balls_faced, fours, sixes, strike_rate 
FROM player_batting_stats 
WHERE match_id = 116912
ORDER BY batting_position;

-- Check bowling stats
SELECT player_name, overs, maidens, runs_conceded, wickets, economy 
FROM player_bowling_stats 
WHERE match_id = 116912
ORDER BY wickets DESC;

-- Combined stats (for fantasy points)
SELECT 
    COALESCE(b.player_name, bw.player_name) as player_name,
    b.runs, b.balls_faced, b.fours, b.sixes,
    bw.overs, bw.wickets, bw.economy,
    COALESCE(b.is_captain, bw.is_captain) as is_captain
FROM player_batting_stats b
FULL OUTER JOIN player_bowling_stats bw 
    ON b.match_id = bw.match_id 
    AND b.player_id = bw.player_id
WHERE COALESCE(b.match_id, bw.match_id) = 116912;
```

---

## 📊 Test API Endpoints Directly

### 1. Get Scorecard (Database Only)
```bash
curl -s http://localhost:3000/api/matches/116912/scorecard | jq .
```

**Expected**: 
- If data exists: Returns scorecard with `"source": "database"`
- If no data: Returns 400 error with message

### 2. Fetch from RapidAPI
```bash
curl -s "http://localhost:3000/api/matches/116912/scorecard?rapidApiMatchId=116912" | jq .
```

**Expected**: 
- Fetches from RapidAPI
- Stores in database
- Returns `"source": "rapidapi"`

### 3. Get Combined Player Stats
```bash
curl -s http://localhost:3000/api/matches/116912/player-stats | jq .
```

**Expected**: 
- Returns array of players with combined batting+bowling stats

---

## 🎯 Expected Behavior

### URL Pattern
```
/tournament/tournament-fixtures/:tournamentId/:matchId?rapidApiMatchId=XXXXX

Example:
/tournament/tournament-fixtures/9596/116912?rapidApiMatchId=116912
```

### Component Flow
```
MatchScorecard.jsx loads
        ↓
useEffect runs on mount
        ↓
fetchScorecardFromDatabase()
        ↓
    Data found?
    ↙        ↘
  YES         NO
   ↓           ↓
Display    Show error
cached     + Fetch button
           ↓
    User clicks Fetch
           ↓
    fetchScorecardFromAPI()
           ↓
    Costs 1 API request
           ↓
    Display scorecard
```

---

## ⚠️ Rate Limit Tracking

### Monitor API Usage

To track how many API calls have been made:

```sql
-- Count total scorecards fetched
SELECT COUNT(*) as total_scorecards_fetched 
FROM match_summaries;

-- See recent fetches
SELECT match_id, rapidapi_match_id, fetched_at 
FROM match_summaries 
ORDER BY fetched_at DESC 
LIMIT 10;
```

### API Limits
- **Daily**: 100 requests
- **Per Minute**: 6 requests

**Strategy**: Only fetch when user explicitly clicks "Fetch Scorecard" or "Refresh"

---

## 🐛 Troubleshooting

### Issue: Blank page when clicking match
**Fix**: Import path fixed in App.jsx ✅

### Issue: "Cannot find module" error
**Solution**: 
```bash
cd client
rm -rf node_modules/.vite
npm run dev
```

### Issue: Data not loading
**Check**:
1. Backend running? `curl http://localhost:3000/health`
2. Frontend running? Open http://localhost:5173
3. Browser console for errors (F12)
4. Network tab to see API calls

### Issue: API rate limit exceeded
**Solution**:
- Use cached database data
- Wait for daily reset
- Prioritize important matches

---

## ✅ Success Criteria

The feature is working correctly when:

1. ✅ Can click match row in fixtures
2. ✅ Scorecard page loads (even if showing "No data")
3. ✅ Can fetch scorecard from API
4. ✅ Data persists in database
5. ✅ Second visit loads instantly from cache
6. ✅ Refresh button updates data
7. ✅ All stats display correctly
8. ✅ Mobile responsive

---

## 📸 Screenshots to Verify

**Take screenshots of**:
1. Tournament Fixtures with clickable rows
2. Match Scorecard page with "Fetch" button (first visit)
3. Match Scorecard with data loaded
4. Batting stats table
5. Bowling stats table
6. Data source badge showing "Database (Cached)"
7. Refresh button in action

---

## 🚀 Ready to Test!

**Current Status**: ✅ All fixes applied, servers running

**Next Steps**:
1. Open browser: http://localhost:5173
2. Login to the app
3. Navigate to Tournaments → Fixtures
4. Click any match row
5. Verify scorecard loads correctly

**Report any issues you find!**

---

**Last Updated**: October 19, 2025  
**Backend**: Port 3000 🟢  
**Frontend**: Port 5173 🟢  
**Import Fix**: Applied ✅
