# Fantasy App - Test Cases Specification

## Overview
This document defines comprehensive test cases for the Playing XI transfer and captain change system using Test-Driven Development (TDD) approach.

---

## 1. TRANSFER TRACKING TEST CASES

### Test Suite: Transfer Baseline Calculation

#### TC-T-001: Calculate baseline from most recent locked match
**Given:** 
- Team has Playing XI saved for matches: 842, 844, 846
- Match 842: started (locked)
- Match 844: started (locked)
- Match 846: not started (unlocked)
- Current match: 848

**When:** User opens Playing XI form for Match 848

**Then:**
- Baseline match ID = 844 (most recent locked match before 848)
- Baseline squad = squad saved in Match 844

#### TC-T-002: First Playing XI (no baseline)
**Given:**
- Team has NO previous Playing XI saved
- Current match: 842

**When:** User opens Playing XI form for Match 842

**Then:**
- Baseline match ID = null
- Transfers used = 0
- Transfers remaining = 10

#### TC-T-003: Match already has locked future lineup
**Given:**
- Team has Playing XI for Match 842, 844, 846
- Match 844 has started (locked)
- Current match: 842

**When:** User tries to edit Playing XI for Match 842

**Then:**
- API returns error: "Cannot edit retroactive lineup"
- Form shows error message
- Submit button disabled

---

### Test Suite: Transfer Counting

#### TC-T-004: Count transfers from baseline (player replacements)
**Given:**
- Baseline (Match 844) squad: [P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11]
- Current match: 846
- User changes: Replace P1 with P12, Replace P5 with P13

**When:** User saves Playing XI for Match 846

**Then:**
- Transfers used = 2
- Transfers remaining = 8
- Database: fantasy_teams.transfers_made_from_baseline = 2

#### TC-T-005: Re-save same match (no new transfers)
**Given:**
- Baseline (Match 844): [P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11]
- Match 846 already saved with: [P12, P2, P3, P4, P13, P6, P7, P8, P9, P10, P11] (2 transfers)
- fantasy_teams.transfers_made_from_baseline = 2

**When:** User opens Match 846, changes only captain (no player changes), saves

**Then:**
- Transfers used = 2 (unchanged)
- Transfers remaining = 8
- Database: fantasy_teams.transfers_made_from_baseline = 2 (unchanged)

#### TC-T-006: Re-save with additional transfers
**Given:**
- Baseline (Match 844): [P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11]
- Match 846 already saved with: [P12, P2, P3, P4, P13, P6, P7, P8, P9, P10, P11] (2 transfers)
- fantasy_teams.transfers_made_from_baseline = 2

**When:** User opens Match 846, replaces P2 with P14, P3 with P15, saves

**Then:**
- Transfers used = 4 (2 previous + 2 new)
- Transfers remaining = 6
- Database: fantasy_teams.transfers_made_from_baseline = 4

#### TC-T-007: Block when exceeding transfer limit
**Given:**
- Baseline (Match 844): [P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11]
- fantasy_teams.transfers_made_from_baseline = 10 (limit reached)
- Current match: 848

**When:** User tries to replace P1 with P12 in Match 848

**Then:**
- API returns error: "Transfer limit exceeded"
- Form shows error message
- Submit disabled

#### TC-T-008: Revert transfer (bring back baseline player)
**Given:**
- Baseline (Match 844): [P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11]
- Match 846 saved with: [P12, P13, P14, P4, P5, P6, P7, P8, P9, P10, P11] (3 transfers)
- fantasy_teams.transfers_made_from_baseline = 3

**When:** User opens Match 848, uses: [P1, P13, P14, P4, P5, P6, P7, P8, P9, P10, P11] (brings back P1)

**Then:**
- Transfers used = 2 (reverted P12→P1)
- Transfers remaining = 8
- Database: fantasy_teams.transfers_made_from_baseline = 2

---

## 2. CAPTAIN CHANGE TEST CASES

### Test Suite: Captain Change Baseline

#### TC-C-001: Identify baseline captain
**Given:**
- Baseline match (844): Captain = P1, Vice-Captain = P2
- Current match: 846

**When:** User opens Playing XI form for Match 846

**Then:**
- Baseline captain = P1
- Baseline vice-captain = P2
- Captain changes used = 0 (from DB)
- Captain changes remaining = 1

#### TC-C-002: No baseline (first Playing XI)
**Given:**
- No previous Playing XI saved
- Current match: 842

**When:** User selects Captain = P5, Vice-Captain = P7

**Then:**
- This becomes the baseline
- Captain changes used = 0
- No validation errors

---

### Test Suite: Captain Change Tracking

#### TC-C-003: First captain change
**Given:**
- Baseline (Match 844): Captain = P1, VC = P2
- fantasy_teams.captain_changes_made = 0
- Current match: 846

**When:** User changes Captain to P3 (P3 ≠ P1)

**Then:**
- Captain changes used = 1
- Captain changes remaining = 0
- Database: fantasy_teams.captain_changes_made = 1
- Save succeeds

#### TC-C-004: Keep baseline captain (no change)
**Given:**
- Baseline (Match 844): Captain = P1, VC = P2
- fantasy_teams.captain_changes_made = 0
- Current match: 846

**When:** User keeps Captain = P1

**Then:**
- Captain changes used = 0
- Captain changes remaining = 1
- Database: fantasy_teams.captain_changes_made = 0
- Save succeeds

#### TC-C-005: Reuse previously changed captain (no penalty)
**Given:**
- Baseline (Match 844): Captain = P1
- Match 846: Captain = P3 (changed from P1, captain_changes_made = 1)
- Current match: 848

**When:** User sets Captain = P3 again in Match 848

**Then:**
- Captain changes used = 1 (unchanged)
- Captain changes remaining = 0
- Database: fantasy_teams.captain_changes_made = 1 (unchanged)
- Save succeeds (no "already used" error)

#### TC-C-006: Change to new captain when limit reached (block)
**Given:**
- Baseline (Match 844): Captain = P1
- Match 846: Captain = P3 (captain_changes_made = 1)
- Current match: 848

**When:** User tries to change Captain to P5 (P5 ≠ P1 and P5 ≠ P3)

**Then:**
- API returns error: "Captain change limit exceeded"
- Form shows error message
- Submit disabled

#### TC-C-007: Revert to baseline captain (decrement counter)
**Given:**
- Baseline (Match 844): Captain = P1
- Match 846: Captain = P3 (captain_changes_made = 1)
- Current match: 848

**When:** User changes Captain back to P1 (baseline)

**Then:**
- Captain changes used = 0 (decremented)
- Captain changes remaining = 1
- Database: fantasy_teams.captain_changes_made = 0
- Save succeeds

#### TC-C-008: Re-save same match with same captain (no change)
**Given:**
- Baseline (Match 844): Captain = P1
- Match 846 already saved with Captain = P3 (captain_changes_made = 1)

**When:** User opens Match 846, keeps Captain = P3, saves

**Then:**
- Captain changes used = 1 (unchanged)
- Captain changes remaining = 0
- Database: fantasy_teams.captain_changes_made = 1 (unchanged)

#### TC-C-009: Re-save same match with different captain
**Given:**
- Baseline (Match 844): Captain = P1
- Match 846 already saved with Captain = P3 (captain_changes_made = 1)

**When:** User opens Match 846, changes Captain to P1 (revert to baseline)

**Then:**
- Captain changes used = 0 (decremented)
- Captain changes remaining = 1
- Database: fantasy_teams.captain_changes_made = 0

---

### Test Suite: Vice-Captain Change Tracking

#### TC-VC-001: First vice-captain change
**Given:**
- Baseline (Match 844): Captain = P1, VC = P2
- fantasy_teams.captain_changes_made = 0
- Current match: 846

**When:** User changes VC to P4 (P4 ≠ P2, captain stays P1)

**Then:**
- Captain changes used = 1 (VC change counts toward limit)
- Captain changes remaining = 0
- Database: fantasy_teams.captain_changes_made = 1

#### TC-VC-002: Change both captain and VC (counts as 1)
**Given:**
- Baseline (Match 844): Captain = P1, VC = P2
- fantasy_teams.captain_changes_made = 0
- Current match: 846

**When:** User changes Captain to P3 AND VC to P4

**Then:**
- Captain changes used = 1 (both changes count together)
- Captain changes remaining = 0
- Database: fantasy_teams.captain_changes_made = 1

#### TC-VC-003: Reuse previously changed VC (no penalty)
**Given:**
- Baseline (Match 844): VC = P2
- Match 846: VC = P4 (captain_changes_made = 1)
- Current match: 848

**When:** User sets VC = P4 again in Match 848

**Then:**
- Captain changes used = 1 (unchanged)
- Save succeeds

#### TC-VC-004: Revert VC to baseline (decrement)
**Given:**
- Baseline (Match 844): Captain = P1, VC = P2
- Match 846: Captain = P1, VC = P4 (captain_changes_made = 1)
- Current match: 848

**When:** User changes VC back to P2 (baseline)

**Then:**
- Captain changes used = 0 (decremented)
- Captain changes remaining = 1
- Database: fantasy_teams.captain_changes_made = 0

---

## 3. EDGE CASES & COMPLEX SCENARIOS

### Test Suite: Combined Operations

#### TC-E-001: Multiple transfers + captain change in one save
**Given:**
- Baseline (Match 844): [P1(C), P2(VC), P3, P4, P5, P6, P7, P8, P9, P10, P11]
- Transfers used = 0, captain_changes_made = 0
- Current match: 846

**When:** User saves: [P12(C), P13(VC), P14, P4, P5, P6, P7, P8, P9, P10, P11]
- Replaces P1, P2, P3 (3 transfers)
- Captain changed from P1 to P12
- VC changed from P2 to P13

**Then:**
- Transfers used = 3
- Captain changes used = 1
- Both counters updated correctly

#### TC-E-002: Delete Playing XI (reset counters correctly)
**Given:**
- Baseline (Match 844): [P1(C), P2(VC), P3, ...]
- Match 846: [P12(C), P13(VC), P14, ...] (3 transfers, 1 captain change)
- fantasy_teams.transfers_made_from_baseline = 3
- fantasy_teams.captain_changes_made = 1

**When:** User deletes Playing XI for Match 846

**Then:**
- Baseline recalculated (may stay 844 or become earlier)
- Transfers recalculated from new baseline
- Captain changes recalculated from new baseline
- Database updated with correct counts

#### TC-E-003: Delete intermediate match (affects future calculations)
**Given:**
- Match 844: [P1(C), P2(VC), ...] (baseline)
- Match 846: [P12(C), P13(VC), ...] (captain change made)
- Match 848: [P12(C), P13(VC), ...] (reusing P12, no additional change)

**When:** User deletes Match 846

**Then:**
- Match 848 captain P12 now counts as NEW change (baseline is 844 with P1)
- Captain changes recalculated correctly

#### TC-E-004: Captain and VC swap
**Given:**
- Baseline (Match 844): Captain = P1, VC = P2
- Current match: 846

**When:** User sets Captain = P2, VC = P1 (swap roles)

**Then:**
- Captain changes used = 1
- Both P2 and P1 marked as "changed" captain/VC
- Save succeeds

#### TC-E-005: Query excludes baseline captain from "previous captains"
**Given:**
- Baseline (Match 844): Captain = P1
- Match 846: Captain = P1 (kept same)
- Current match: 848

**When:** System queries "previous captains used"

**Then:**
- Query result = [] (empty, because P1 is baseline, not a change)
- User can change to any captain without "already used" error

---

## 4. DATA INTEGRITY TEST CASES

### Test Suite: Database Consistency

#### TC-D-001: Transaction rollback on error
**Given:**
- Valid Playing XI data
- Database constraint violation (e.g., invalid player_id)

**When:** Save operation fails

**Then:**
- All changes rolled back
- fantasy_teams counters unchanged
- No partial data saved

#### TC-D-002: Concurrent saves (race condition)
**Given:**
- User A opens Match 846
- User B opens Match 846
- Both make changes

**When:** User A saves, then User B saves

**Then:**
- Latest save wins
- Counters calculated from final state
- No counter corruption

#### TC-D-003: Player ID type consistency (VARCHAR vs NUMBER)
**Given:**
- Database stores player_id as VARCHAR
- Frontend sends player_id as NUMBER

**When:** Comparing player IDs for captain/transfer detection

**Then:**
- All comparisons use String() conversion
- No false positives/negatives due to type mismatch

---

## 5. UI/UX TEST CASES

### Test Suite: Real-time Updates

#### TC-U-001: Counter updates immediately after save
**Given:**
- Transfers remaining = 10, Captain changes remaining = 1
- User makes 2 transfers + 1 captain change

**When:** User clicks Save

**Then:**
- UI updates immediately (without page refresh)
- Transfers remaining shows 8
- Captain changes remaining shows 0
- Badge colors update (green → yellow/red)

#### TC-U-002: Form validation before submit
**Given:**
- Captain changes remaining = 0
- User tries to select new captain

**When:** User changes captain dropdown

**Then:**
- Submit button stays disabled
- Error message appears: "Cannot change captain"

#### TC-U-003: Delete confirmation updates counters
**Given:**
- Match 846 has 3 transfers, 1 captain change
- User clicks Delete

**When:** User confirms deletion

**Then:**
- Playing XI deleted
- Counters recalculated
- UI updates with new values

---

## 6. API ENDPOINT TEST CASES

### Test Suite: /api/playing-xi Endpoints

#### TC-A-001: GET /api/playing-xi/:teamId/:matchId
**Request:**
```
GET /api/playing-xi/123/846
```

**Expected Response (200):**
```json
{
  "success": true,
  "data": {
    "squad": [...11 players with is_captain, is_vice_captain flags],
    "transfersUsed": 2,
    "transfersRemaining": 8,
    "captainChangesUsed": 1,
    "captainChangesRemaining": 0,
    "baselineMatchId": 844
  }
}
```

#### TC-A-002: POST /api/playing-xi (Success)
**Request:**
```json
{
  "teamId": 123,
  "matchId": 846,
  "squad": [...11 players],
  "captain": 5,
  "viceCaptain": 7
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Playing XI saved successfully",
  "data": {
    "transfersUsed": 3,
    "transfersRemaining": 7,
    "captainChangesUsed": 1,
    "captainChangesRemaining": 0
  }
}
```

#### TC-A-003: POST /api/playing-xi (Transfer Limit Error)
**Expected Response (400):**
```json
{
  "success": false,
  "error": "You have exceeded your transfer limit (10 transfers max)"
}
```

#### TC-A-004: POST /api/playing-xi (Captain Change Error)
**Expected Response (400):**
```json
{
  "success": false,
  "error": "You have used your one allowed captain/vice-captain change"
}
```

#### TC-A-005: DELETE /api/playing-xi/:teamId/:matchId
**Expected Response (200):**
```json
{
  "success": true,
  "message": "Playing XI deleted successfully"
}
```

#### TC-A-006: GET /api/transfer-stats/:teamId
**Expected Response (200):**
```json
{
  "success": true,
  "data": {
    "transfersUsed": 5,
    "transfersRemaining": 5,
    "transfersLocked": false,
    "captainChangesUsed": 1,
    "captainChangesRemaining": 0,
    "captainChangesLocked": true,
    "baselineMatchId": 844
  }
}
```

---

## 7. TEST IMPLEMENTATION STRUCTURE

### Recommended Test Files:

```
tests/
├── unit/
│   ├── transferCalculation.test.js
│   ├── captainChangeDetection.test.js
│   ├── baselineCalculation.test.js
│   └── playerComparison.test.js
│
├── integration/
│   ├── playingXI.api.test.js
│   ├── transferStats.api.test.js
│   └── deletePlayingXI.api.test.js
│
├── e2e/
│   ├── userJourney.test.js
│   ├── multiMatchFlow.test.js
│   └── deleteAndRecalculate.test.js
│
├── fixtures/
│   ├── sampleTeams.js
│   ├── sampleMatches.js
│   └── samplePlayers.js
│
└── helpers/
    ├── dbSetup.js
    ├── apiClient.js
    └── assertions.js
```

---

## 8. TEST DATA REQUIREMENTS

### Fixtures Needed:

1. **Teams**: At least 3 test teams
2. **Players**: 20+ players with different roles
3. **Matches**: 
   - Match 842 (started, locked)
   - Match 844 (started, locked)
   - Match 846 (not started)
   - Match 848 (not started)
4. **Playing XI Records**: Pre-populated baseline data

---

## 9. TESTING FRAMEWORKS

### Recommended Stack:

```json
{
  "devDependencies": {
    "jest": "^29.7.0",
    "supertest": "^6.3.3",
    "pg-mem": "^2.6.12",
    "@testing-library/react": "^14.0.0",
    "@testing-library/jest-dom": "^6.1.4",
    "msw": "^2.0.0"
  }
}
```

### Test Example Template:

```javascript
// tests/unit/captainChangeDetection.test.js
describe('Captain Change Detection', () => {
  
  beforeEach(async () => {
    // Setup: Create clean test DB state
    await setupTestDatabase();
    await seedBaselineData();
  });

  afterEach(async () => {
    // Cleanup: Reset DB
    await cleanupTestDatabase();
  });

  test('TC-C-003: First captain change', async () => {
    // Arrange
    const teamId = 1;
    const matchId = 846;
    const baselineCaptain = 'P1';
    const newCaptain = 'P3';

    // Act
    const result = await detectCaptainChange(teamId, matchId, newCaptain);

    // Assert
    expect(result.captainChangesUsed).toBe(1);
    expect(result.captainChangesRemaining).toBe(0);
    expect(result.shouldBlock).toBe(false);
  });

  test('TC-C-005: Reuse previously changed captain', async () => {
    // Arrange
    await savePlayingXI({ teamId: 1, matchId: 846, captain: 'P3' });
    
    // Act
    const result = await detectCaptainChange(1, 848, 'P3');

    // Assert
    expect(result.captainChangesUsed).toBe(1); // Unchanged
    expect(result.shouldBlock).toBe(false); // Should allow
  });

  // ... more tests
});
```

---

## 10. SUCCESS CRITERIA

### Definition of Done:

✅ All test cases pass (100% success rate)
✅ Code coverage > 90%
✅ No false positives/negatives in captain detection
✅ Transfer counting accurate in all scenarios
✅ Database transactions properly rolled back on error
✅ UI updates reflect accurate real-time data
✅ Edge cases handled gracefully
✅ Type consistency maintained (VARCHAR vs NUMBER)

---

## NEXT STEPS

1. **Review this specification** - Confirm test cases cover all scenarios
2. **Set up testing framework** - Install Jest, Supertest, pg-mem
3. **Create test fixtures** - Sample data for all tests
4. **Write tests first** (RED phase) - All tests should fail initially
5. **Implement features** (GREEN phase) - Make tests pass
6. **Refactor code** (REFACTOR phase) - Clean up while keeping tests green
7. **Run regression suite** - Ensure nothing breaks

---

**Total Test Cases Defined**: 45+ scenarios
**Coverage Areas**: Transfers (8), Captain Changes (9), Vice-Captain (4), Edge Cases (5), Data Integrity (3), UI/UX (3), API (6), plus integration & E2E tests

