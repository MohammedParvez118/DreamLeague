import pkg from 'pg';
import fs from 'fs';
const { Pool } = pkg;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Fantasy',
  password: 'P@rvezn00r',
  port: 5432,
});

async function applyViewFix() {
  try {
    console.log('\n=== Applying Top Performers View Fix ===\n');

    // Read the SQL file
    const sql = fs.readFileSync('./migrations/fix_top_performers_view.sql', 'utf8');
    
    // Execute the SQL
    await pool.query(sql);
    
    console.log('✅ View updated successfully!\n');
    
    // Test the view
    const result = await pool.query(`
      SELECT 
        player_name,
        cricket_team,
        player_role,
        matches_played,
        total_fantasy_points,
        avg_points_per_match
      FROM tournament_top_performers 
      WHERE league_id = 84 
      ORDER BY total_fantasy_points DESC
      LIMIT 5
    `);
    
    console.log('Top 5 Performers after view update:');
    console.table(result.rows);
    
    pool.end();
  } catch (err) {
    console.error('❌ Error:', err.message);
    pool.end();
  }
}

applyViewFix();
