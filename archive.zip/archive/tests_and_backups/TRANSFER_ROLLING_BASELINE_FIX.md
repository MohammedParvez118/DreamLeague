# Transfer System - Rolling Baseline Fix ✅

## Date: October 25, 2025

## Problem: Locked Matches Should Become New Baseline

### User Scenario (Issue)
```
Match 1: P1-P11 (0 transfers, baseline)
Match 2 (before deadline): P1-P2, P4-P11, P12 (1 transfer: P3→P12)
[Match 2 deadline passes - LOCKED]
Match 3 (before deadline): P1-P3, P4-P11 (reverts P12→P3)

EXPECTED: 1 transfer (new change from locked Match 2)
ACTUAL BUG: 0 transfers (system compared to Match 1, saw P1-P11 baseline)
```

### Why This is Wrong
- **Match 2 became locked** (deadline passed)
- User cannot change Match 2 anymore
- **Match 2 should be the new baseline** for Match 3
- Reverting P12→P3 in Match 3 is a **new transfer**, not undoing Match 2

---

## Solution: Rolling Baseline Logic

### Concept
**Baseline = Most Recent Locked Match**
- Before Match 2 deadline: Baseline = Match 1
- After Match 2 deadline: Baseline = Match 2
- After Match 3 deadline: Baseline = Match 3
- And so on...

### Implementation
```javascript
// Get the most recent LOCKED match (deadline passed) with a saved Playing XI
const baselineMatch = await client.query(
  `SELECT lm.id, lm.match_start
   FROM league_matches lm
   JOIN team_playing_xi tpxi ON tpxi.match_id = lm.id AND tpxi.team_id = $1
   WHERE lm.league_id = $2 
     AND lm.id < $3              -- Before current match
     AND NOW() >= lm.match_start -- Deadline has passed
   ORDER BY lm.match_start DESC
   LIMIT 1`,
  [teamId, leagueId, matchId]
);

// If no locked match found, fall back to Match 1
const baselineMatchId = baselineMatch.rows.length > 0 
  ? baselineMatch.rows[0].id 
  : firstMatch.rows[0].id;
```

---

## How It Works

### Transfer Calculation Logic

**Step 1: Identify Baseline**
- Get most recent locked match with Playing XI
- If none (all future matches), use Match 1

**Step 2: Get Previous Save (if exists)**
- Check if current match already has a saved XI
- This helps calculate **incremental** changes

**Step 3: Calculate Incremental Transfers**
```javascript
// Current changes from baseline
const currentTransfersFromBaseline = baselinePlayerIds
  .filter(id => !newPlayerIds.includes(id)).length;

// Previous changes from baseline (if any)
const previousTransfersFromBaseline = previousPlayerIds
  .filter(id => !baselinePlayerIds.includes(id)).length;

// Incremental change for THIS save
const transfersUsedThisMatch = currentTransfersFromBaseline - previousTransfersFromBaseline;

// Update total
UPDATE fantasy_teams 
SET transfers_made = transfers_made + transfersUsedThisMatch;
```

---

## Example Scenarios

### Scenario 1: Normal Progression
```
Match 1 (Baseline): P1-P11
  Transfers: 0/10
  Locked: ✅

Match 2 (before deadline): P1-P2, P4-P11, P12
  Baseline: Match 1
  Changes from baseline: P3→P12 (1 change)
  Transfers: 1/10 ✅
  Locked: ❌

Match 2 (save again, revert): P1-P11
  Baseline: Match 1
  Changes from baseline: None (0 changes)
  Incremental: 0 - 1 = -1
  Transfers: 0/10 ✅ (reverted before deadline)
  Locked: ❌

[Match 2 deadline passes - LOCKED ✅]

Match 3 (before deadline): P1-P2, P4-P11, P12
  Baseline: Match 2 (P1-P11) ← NEW BASELINE!
  Changes from baseline: P3→P12 (1 change)
  Transfers: 1/10 ✅ (new transfer counted!)
  Locked: ❌
```

### Scenario 2: Multiple Changes After Lock
```
Match 1: P1-P11 (0 transfers) [LOCKED]

Match 2: P1-P2, P4-P11, P12-P13
  Baseline: Match 1
  Changes: P3→P12, P5→P13 (2 transfers)
  Total: 2/10 [LOCKED]

Match 3: P1-P2, P4-P11, P14-P15
  Baseline: Match 2 ← Changed!
  Previous: P12-P13
  Current: P14-P15
  Changes: P12→P14, P13→P15 (2 NEW transfers)
  Total: 4/10 ✅ (2 + 2)
```

### Scenario 3: Revert Before Deadline
```
Match 1: P1-P11 (0 transfers) [LOCKED]

Match 2 Save 1: P1-P2, P4-P11, P12
  Baseline: Match 1
  Changes: P3→P12 (1 transfer)
  Total: 1/10

Match 2 Save 2 (before deadline): P1-P11
  Baseline: Match 1
  Changes: None (0 changes)
  Incremental: 0 - 1 = -1
  Total: 0/10 ✅ (reverted)

[Match 2 deadline passes - LOCKED with P1-P11]

Match 3: P1-P2, P4-P11, P12
  Baseline: Match 2 (P1-P11)
  Changes: P3→P12 (1 NEW transfer)
  Total: 1/10 ✅
```

### Scenario 4: Back and Forth
```
Match 1: P1-P11 [LOCKED]
Match 2: P1-P2, P4-P11, P12 (1 transfer) [LOCKED]
Match 3: P1-P11 (1 NEW transfer: P12→P3, total 2) [LOCKED]
Match 4: P1-P2, P4-P11, P12 (1 NEW transfer: P3→P12, total 3) ✅
```

---

## Key Differences from Previous Logic

### Old Logic (Broken)
- ❌ Always used Match 1 as baseline
- ❌ Absolute NET count from Match 1
- ❌ Reverts after lock = 0 transfers
- ❌ `transfers_made = newTotal` (replaced value)

### New Logic (Fixed)
- ✅ Uses most recent LOCKED match as baseline
- ✅ Incremental count from rolling baseline
- ✅ Reverts after lock = new transfers
- ✅ `transfers_made = transfers_made + incremental` (added value)

---

## Code Changes

### Baseline Selection
```javascript
// ❌ OLD
const baselineXI = await client.query(
  'SELECT player_id FROM team_playing_xi WHERE match_id = $1',
  [firstMatch.rows[0].id]  // Always Match 1
);

// ✅ NEW
const baselineMatch = await client.query(
  `SELECT lm.id FROM league_matches lm
   WHERE lm.id < $1 AND NOW() >= lm.match_start
   ORDER BY lm.match_start DESC LIMIT 1`,
  [matchId]
);
const baselineMatchId = baselineMatch.rows[0]?.id || firstMatch.rows[0].id;
```

### Transfer Calculation
```javascript
// ❌ OLD
const playersChanged = baselinePlayerIds.filter(id => !newPlayerIds.includes(id));
const newTransfersTotal = playersChanged.length;

UPDATE fantasy_teams SET transfers_made = $1  // Replaced
WHERE id = $2

// ✅ NEW
const currentChanges = baselinePlayerIds.filter(id => !newPlayerIds.includes(id)).length;
const previousChanges = baselinePlayerIds.filter(id => !previousPlayerIds.includes(id)).length;
const transfersUsedThisMatch = currentChanges - previousChanges;

UPDATE fantasy_teams SET transfers_made = transfers_made + $1  // Added
WHERE id = $2
```

---

## Benefits

### 1. ✅ Locked Matches Become Immutable
Once a match is locked, any future changes count as NEW transfers

### 2. ✅ Fair Transfer Counting
- Before deadline: Reverts don't cost transfers
- After deadline: Everything costs transfers

### 3. ✅ Progressive Baseline
Each locked match becomes the new starting point

### 4. ✅ Realistic User Experience
- Can't undo past matches
- Changes must be counted from what's locked

---

## Edge Cases Handled

### Case 1: First Match Not Set
```javascript
if (baselineXI.rows.length === 0) {
  return res.status(400).json({
    message: 'Please set up your Playing XI for Match 1 first'
  });
}
```

### Case 2: All Matches in Future (None Locked)
```javascript
const baselineMatchId = baselineMatch.rows.length > 0 
  ? baselineMatch.rows[0].id 
  : firstMatch.rows[0].id;  // Fall back to Match 1
```

### Case 3: First Save for a Match
```javascript
let previousTransfersFromBaseline = 0;
if (previousXI.rows.length > 0) {
  // Calculate what was already counted
  previousTransfersFromBaseline = ...;
}
```

### Case 4: Captain Changes
```javascript
// Check if captain was already changed in previous saves
const previousCaptainChanged = previousXI.rows.length > 0 && ...;

// Only count as new change if not changed before
const isNewCaptainChange = (captainChanged || vcChanged) && !previousCaptainChanged;
```

### Case 5: 🔒 CRITICAL - Retroactive Edit Prevention
```javascript
// Check if there are ANY future matches with saved Playing XI
const futureMatchesWithXI = await client.query(
  `SELECT lm.id FROM league_matches lm
   JOIN team_playing_xi tpxi ON tpxi.match_id = lm.id
   WHERE lm.id > $1`,
  [matchId]
);

if (futureMatchesWithXI.rows.length > 0) {
  return res.status(403).json({
    message: 'Cannot edit this match. Future lineups exist.'
  });
}
```

**Why This is Critical**:
```
❌ WITHOUT THIS CHECK (Loophole):
Match 1: P1-P11 [Saved ✅]
Match 2: P1-P11 [Saved ✅]
Match 3: P1-P11 [Saved ✅]
Go back to Match 2: P3→P12 [Saved ✅] (1 transfer)
Result: Match 3 still has P1-P11 but baseline changed to P3→P12
User gets 1 extra transfer to change P12→P3 in Match 3!

✅ WITH THIS CHECK (Fixed):
Match 1: P1-P11 [Saved ✅]
Match 2: P1-P11 [Saved ✅]
Match 3: P1-P11 [Saved ✅]
Try to edit Match 2: ❌ BLOCKED
Message: "Cannot edit this match. You have already set Playing XI for future matches."
```

---

## Testing Checklist

### Test 1: Basic Lock
- [ ] Match 1: Set XI, lock
- [ ] Match 2: Change 2 players → 2 transfers
- [ ] Lock Match 2
- [ ] Match 3: Revert those 2 → Should be 2 NEW transfers (total 4)

### Test 2: Revert Before Lock
- [ ] Match 1: Set XI, lock
- [ ] Match 2: Change 3 players → 3 transfers
- [ ] Match 2 (before lock): Revert 1 → 2 transfers
- [ ] Lock Match 2
- [ ] Match 3: Revert 1 more → 1 NEW transfer (total 3)

### Test 3: Multiple Locks
- [ ] Match 1: XI set, lock
- [ ] Match 2: Change 1 → 1 transfer, lock
- [ ] Match 3: Change 1 → 1 transfer (total 2), lock
- [ ] Match 4: Change 1 → 1 transfer (total 3)

### Test 4: Captain Changes
- [ ] Match 1: Set captain, lock
- [ ] Match 2: Change captain → 1 C/VC change, lock
- [ ] Match 3: Try to change → Should be blocked

### Test 5: 🔒 Retroactive Edit Prevention (CRITICAL)
- [ ] Match 1: Set P1-P11, lock
- [ ] Match 2: Set P1-P11, lock
- [ ] Match 3: Set P1-P11 (before deadline)
- [ ] Try to edit Match 2: Should be **BLOCKED** ❌
- [ ] Error: "Cannot edit this match. Future lineups exist."
- [ ] Delete Match 3 lineup
- [ ] Try to edit Match 2 again: Should **SUCCEED** ✅ (if before deadline)

---

## Summary

**Old System**: Always compared with Match 1 (static baseline)  
**New System**: Compares with most recent locked match (rolling baseline)

**Result**: 
- ✅ Fair transfer counting after deadlines
- ✅ Cannot undo locked changes without cost
- ✅ Realistic fantasy league behavior
- ✅ Users understand: "Changes from last locked match"

Once a match deadline passes, that lineup is **locked in history**. Any future changes are counted from that point forward, not from the beginning of the league.
