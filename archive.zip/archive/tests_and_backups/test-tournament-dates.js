import { fetchFromApi } from './src/services/apiService.js';

const tournamentId = 10884;
const url = `https://cricbuzz-cricket.p.rapidapi.com/series/v1/${tournamentId}`;

console.log('Fetching tournament details from:', url);

fetchFromApi(url)
  .then((data) => {
    console.log('\n=== Tournament Date Fields ===\n');
    
    // Get dates from first match
    if (data.matchDetails && data.matchDetails.length > 0) {
      const firstMatch = data.matchDetails[0].matchDetailsMap.match[0].matchInfo;
      
      console.log('Series Start Date (timestamp):', firstMatch.seriesStartDt);
      console.log('Series End Date (timestamp):', firstMatch.seriesEndDt);
      
      // Convert timestamps to readable dates
      const startDate = new Date(parseInt(firstMatch.seriesStartDt));
      const endDate = new Date(parseInt(firstMatch.seriesEndDt));
      
      console.log('\nConverted Dates:');
      console.log('Start Date:', startDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));
      console.log('End Date:', endDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));
      
      console.log('\nISO Format:');
      console.log('Start Date:', startDate.toISOString().split('T')[0]);
      console.log('End Date:', endDate.toISOString().split('T')[0]);
    }
    
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error:', error.message);
    process.exit(1);
  });
