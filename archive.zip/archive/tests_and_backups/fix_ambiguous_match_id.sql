-- Fix for ambiguous column reference in apply_replacement_to_future_matches function
-- Run this SQL to update the function in your database

CREATE OR REPLACE FUNCTION apply_replacement_to_future_matches(
  p_team_id INTEGER,
  p_out_player_id VARCHAR(50),
  p_in_player_id VARCHAR(50),
  p_in_player_name TEXT,
  p_in_player_role VARCHAR(50),
  p_in_player_squad VARCHAR(100),
  p_start_match_id INTEGER
)
RETURNS TABLE(
  match_id INTEGER,
  replaced BOOLEAN,
  was_captain BOOLEAN,
  was_vice_captain BOOLEAN
) AS $$
BEGIN
  RETURN QUERY
  WITH future_matches AS (
    SELECT lm.id as match_id
    FROM league_matches lm
    WHERE lm.id >= p_start_match_id
      AND lm.match_start > NOW()
  ),
  replacements AS (
    UPDATE team_playing_xi tpxi
    SET 
      player_id = p_in_player_id,
      player_name = p_in_player_name,
      player_role = p_in_player_role,
      squad_name = p_in_player_squad,
      updated_at = NOW()
    WHERE tpxi.team_id = p_team_id
      AND tpxi.player_id = p_out_player_id
      AND tpxi.match_id IN (SELECT fm.match_id FROM future_matches fm)  -- Fixed: Added alias 'fm'
    RETURNING 
      tpxi.match_id,
      TRUE as replaced,
      tpxi.is_captain as was_captain,
      tpxi.is_vice_captain as was_vice_captain
  )
  SELECT * FROM replacements;
END;
$$ LANGUAGE plpgsql;

-- Verify the function was updated
SELECT 'Function updated successfully!' as status;
