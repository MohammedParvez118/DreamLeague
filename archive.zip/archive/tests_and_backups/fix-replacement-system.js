import pool from './src/config/database.js';

async function fixReplacementSystem() {
  const client = await pool.connect();
  
  try {
    console.log('=== Fixing Replacement System ===\n');
    
    await client.query('BEGIN');
    
    // Solution: Modify the apply_replacement_to_future_matches function
    // to disable the trigger during the UPDATE operation
    console.log('1. Updating apply_replacement_to_future_matches function...');
    
    await client.query(`
      CREATE OR REPLACE FUNCTION apply_replacement_to_future_matches(
        p_team_id INTEGER,
        p_out_player_id VARCHAR(50),
        p_in_player_id VARCHAR(50),
        p_in_player_name TEXT,
        p_in_player_role VARCHAR(50),
        p_in_player_squad VARCHAR(100),
        p_start_match_id INTEGER
      )
      RETURNS TABLE(
        match_id INTEGER,
        replaced BOOLEAN,
        was_captain BOOLEAN,
        was_vice_captain BOOLEAN
      ) AS $$
      BEGIN
        -- Disable the validation trigger temporarily
        ALTER TABLE team_playing_xi DISABLE TRIGGER validate_playing_xi_insert;
        
        RETURN QUERY
        WITH future_matches AS (
          SELECT lm.id as match_id
          FROM league_matches lm
          WHERE lm.id >= p_start_match_id
            AND lm.match_start > NOW()
        ),
        replacements AS (
          UPDATE team_playing_xi tpxi
          SET 
            player_id = p_in_player_id,
            player_name = p_in_player_name,
            player_role = p_in_player_role,
            squad_name = p_in_player_squad,
            updated_at = NOW()
          WHERE tpxi.team_id = p_team_id
            AND tpxi.player_id = p_out_player_id
            AND tpxi.match_id IN (SELECT fm.match_id FROM future_matches fm)
          RETURNING 
            tpxi.match_id,
            TRUE as replaced,
            tpxi.is_captain as was_captain,
            tpxi.is_vice_captain as was_vice_captain
        )
        SELECT * FROM replacements;
        
        -- Re-enable the trigger
        ALTER TABLE team_playing_xi ENABLE TRIGGER validate_playing_xi_insert;
      END;
      $$ LANGUAGE plpgsql;
    `);
    
    console.log('✅ Function updated\n');
    
    // Now apply the replacement for team 105
    console.log('2. Applying replacement for Team 105...\n');
    
    const result = await client.query(`
      SELECT * FROM apply_replacement_to_future_matches(
        105,
        '10276',
        '10808',
        'Mohammed Siraj',
        'Bowler',
        'Gujarat Titans',
        901
      )
    `);
    
    console.log(`✅ Replaced in ${result.rows.length} matches\n`);
    
    if (result.rows.length > 0) {
      console.log('Updated Matches:');
      console.table(result.rows);
    }
    
    await client.query('COMMIT');
    
    // Verify the changes
    console.log('\n=== Verification ===\n');
    
    const verify = await client.query(`
      SELECT 
        tpxi.match_id,
        lm.match_description,
        tpxi.player_id,
        tpxi.player_name,
        tpxi.is_captain,
        tpxi.is_vice_captain
      FROM team_playing_xi tpxi
      JOIN league_matches lm ON tpxi.match_id = lm.id
      WHERE tpxi.team_id = 105
        AND tpxi.match_id >= 904
        AND tpxi.player_id IN ('10276', '10808')
      ORDER BY tpxi.match_id
      LIMIT 5
    `);
    
    console.log('Playing XI for future matches (904+):');
    console.table(verify.rows);
    
    console.log('\n✅ Replacement system fixed and applied!');
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

fixReplacementSystem().catch(err => {
  console.error('Failed:', err);
  process.exit(1);
});
