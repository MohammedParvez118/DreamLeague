/**
 * Fix Fantasy Squads Player IDs
 * 
 * This script updates fantasy_squads table to:
 * 1. Replace player_id (which currently contains player names) with actual player IDs from players table
 * 2. Ensure role is populated from players table
 */

import pool from '../src/config/database.js';

async function fixFantasySquadsPlayerIds() {
  const client = await pool.connect();
  
  try {
    console.log('Starting fantasy_squads player_id fix...\n');
    
    // Get all squads that need fixing
    const selectQuery = `
      SELECT 
        fs.id,
        fs.league_id,
        fs.team_id,
        fs.player_id as old_player_id,
        fs.player_name,
        fs.role as old_role,
        sp.player_id as new_player_id,
        sp.role as new_role
      FROM fantasy_squads fs
      LEFT JOIN squad_players sp ON sp.name = fs.player_id
      WHERE fs.player_id !~ '^\d+$' OR fs.role IS NULL
      ORDER BY fs.league_id, fs.team_id, fs.id
    `;
    
    const result = await client.query(selectQuery);
    
    if (result.rows.length === 0) {
      console.log('✅ No records need fixing. All player_ids are correct!');
      return;
    }
    
    console.log(`Found ${result.rows.length} records to update:\n`);
    
    await client.query('BEGIN');
    
    let successCount = 0;
    let failCount = 0;
    
    for (const row of result.rows) {
      if (row.new_player_id) {
        try {
          // Update player_id and role
          await client.query(
            `UPDATE fantasy_squads 
             SET player_id = $1, role = $2
             WHERE id = $3`,
            [row.new_player_id.toString(), row.new_role, row.id]
          );
          
          console.log(`✅ Updated: "${row.old_player_id}" → ${row.new_player_id} (${row.new_role})`);
          successCount++;
        } catch (err) {
          console.error(`❌ Failed to update ID ${row.id}: ${err.message}`);
          failCount++;
        }
      } else {
        console.log(`⚠️  No match found for: "${row.old_player_id}" (ID: ${row.id})`);
        failCount++;
      }
    }
    
    await client.query('COMMIT');
    
    console.log(`\n${'='.repeat(60)}`);
    console.log(`✅ Successfully updated: ${successCount} records`);
    console.log(`❌ Failed/skipped: ${failCount} records`);
    console.log(`${'='.repeat(60)}\n`);
    
    // Verify the results
    const verifyQuery = `
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN player_id ~ '^\d+$' THEN 1 END) as valid_ids,
        COUNT(CASE WHEN role IS NOT NULL THEN 1 END) as has_role
      FROM fantasy_squads
    `;
    
    const verify = await client.query(verifyQuery);
    console.log('Verification:');
    console.log(`  Total records: ${verify.rows[0].total}`);
    console.log(`  Valid numeric IDs: ${verify.rows[0].valid_ids}`);
    console.log(`  Has role: ${verify.rows[0].has_role}`);
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Error fixing player IDs:', error);
    throw error;
  } finally {
    client.release();
  }
}

// Run the fix
fixFantasySquadsPlayerIds()
  .then(() => {
    console.log('\n✅ Player ID fix completed successfully!');
    process.exit(0);
  })
  .catch((err) => {
    console.error('\n❌ Player ID fix failed:', err);
    process.exit(1);
  });
