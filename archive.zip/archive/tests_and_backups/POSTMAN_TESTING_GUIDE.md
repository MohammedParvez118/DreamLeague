# Postman Testing Guide - Playing XI Sequential System

## 📦 Import Collection

1. Open Postman
2. Click **Import** button
3. Select file: `tests/Fantasy-Playing-XI-Sequential.postman_collection.json`
4. Collection will appear in your sidebar

---

## ⚙️ Configure Variables

Before running tests, update the collection variables:

1. Click on the collection name
2. Go to **Variables** tab
3. Update these values:

| Variable | Default | Description |
|----------|---------|-------------|
| `base_url` | `http://localhost:3000` | Your API URL |
| `team_id` | `1` | Test team ID |
| `league_id` | `1` | Test league ID |
| `match_842` | `842` | First match ID |
| `match_844` | `844` | Second match ID |
| `match_846` | `846` | Third match ID |
| `match_848` | `848` | Fourth match ID |

---

## 🆕 Recent Updates (Latest Changes)

### ✅ Fixed Issues:
1. **League ID Missing** - Fixed `league_id` being null in INSERT statements
2. **DELETE Endpoint Removed** - DELETE is incompatible with sequential locking
3. **Deadline Timer Fixed** - Backend now calculates `secondsUntilStart`
4. **Sequential Blocking UI** - Frontend disables form instead of showing API error

### 🚫 DELETE Removed:
The DELETE endpoint has been **removed from the system** because:
- Sequential locking means each match builds on the previous
- Deleting would break the rolling baseline
- Auto-save mechanism relies on previous match existing

**Old (Removed):** `DELETE /api/league/:leagueId/team/:teamId/match/:matchId/playing-xi`

---

## 🧪 Test Sequence

### **Important: Run tests in order!**

The tests build on each other. Running them out of order will cause failures.

---

## 📋 Test Scenarios

### 1. Setup & Verification
Verify database migration was successful and schema is correct.

#### ✅ Check League Transfer Limit
```
GET /api/leagues/{{league_id}}
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "transfer_limit": 10,
    ...
  }
}
```

#### ✅ Check Team Free Changes Status
```
GET /api/teams/{{team_id}}
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "captain_free_change_used": false,
    "vice_captain_free_change_used": false,
    ...
  }
}
```

#### ✅ Check Match Lock Status
```
GET /api/league/{{league_id}}/match/{{match_842}}/is-locked
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "isLocked": false,
    "matchStart": "2025-12-02T14:30:00.000Z",
    "secondsUntilStart": 3024000,
    "isCompleted": false
  }
}
```

**Note:** `secondsUntilStart` is used for countdown timer in UI (fixed in latest update)

---

### 2. Match 842 - First Match (No Baseline)
```
GET /api/transfer-stats/{{team_id}}
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "transfersUsed": 0,
    "transfersRemaining": 10,
    "transferLimit": 10,
    "captainFreeChangeUsed": false,
    "vcFreeChangeUsed": false,
    "captainChangesRemaining": 1,
    "vcChangesRemaining": 1
  }
}
```

---

### 2. Match 842 - First Match (No Baseline)

#### ✅ Get Playing XI for Match 842 (Empty)
```
GET /api/league/{{league_id}}/team/{{team_id}}/match/{{match_842}}/playing-xi
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "players": [],
    "match": {
      "id": 842,
      "leagueId": 1,
      "startTime": "2025-12-02T14:30:00.000Z",
      "isCompleted": false,
      "isLocked": false
    },
    "canEdit": true,
    "errorMessage": null,
    "transferStats": {
      "transfersUsed": 0,
      "transfersRemaining": 10,
      "transferLimit": 10,
      "captainFreeChangeUsed": false,
      "vcFreeChangeUsed": false
    },
    "previousMatchId": null
  }
}
```

**Key Fields:**
- `canEdit: true` - Form is enabled (no sequential blocking)
- `errorMessage: null` - No blocking message
- `previousMatchId: null` - This is the first match

#### ✅ Save Playing XI for Match 842
```
POST /api/league/{{league_id}}/team/{{team_id}}/match/{{match_842}}/playing-xi
```

**Request Body:**
```json
{
  "players": [
    {"player_id": "1463374", "player_name": "Virat Kohli", "player_role": "Batsman", "squad_name": "India"},
    // ... 10 more players (11 total)
  ],
  "captainId": "1463374",
  "viceCaptainId": "253802"
}
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Playing XI saved successfully",
  "data": {
    "matchId": 842,
    "transfersThisMatch": 0,
    "transfersUsedTotal": 0,
    "transfersRemaining": 10,
    "transferLimit": 10,
    "details": {
      "playerTransfers": 0,
      "captainChangeCost": 0,
      "vcChangeCost": 0,
      "playersAdded": [],
      "playersRemoved": []
    }
  }
}
```

---

### 3. Match 844 - Auto-prefill & Sequential Blocking Test

#### ⚠️ Test Sequential Blocking (Before Match 842 Deadline)
```
GET /api/league/{{league_id}}/team/{{team_id}}/match/{{match_844}}/playing-xi
```

**If Match 842 deadline has NOT passed yet:**
```json
{
  "success": true,
  "data": {
    "players": [],
    "canEdit": false,
    "errorMessage": "Cannot save Playing XI - previous match must be locked first. Wait until 12/2/2025, 2:30:00 PM",
    "transferStats": {
      "transfersUsed": 0,
      "transfersRemaining": 10
    }
  }
}
```

**UI Behavior:**
- 🔒 Yellow warning displayed with deadline
- All form controls disabled
- Save button disabled
- No API error on save attempt

**To proceed:** Either wait for Match 842 deadline OR manually update match_start in database to past time.

#### ✅ Get Playing XI for Match 844 (After Match 842 Locked)
```
GET /api/league/{{league_id}}/team/{{team_id}}/match/{{match_844}}/playing-xi
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "players": [
      {
        "player_id": "1463374",
        "player_name": "Virat Kohli",
        "is_captain": true,
        "is_vice_captain": false
      },
      // ...10 more players (auto-copied from Match 842)
    ],
    "canEdit": true,
    "errorMessage": null,
    "previousMatchId": 842
  }
}
```

**Key Point:** Players were **auto-saved** from Match 842 when you accessed Match 844!

Check database:
```sql
SELECT COUNT(*) FROM team_playing_xi 
WHERE team_id = 1 AND match_id = 844;
-- Should return: 11
```

#### ✅ Save Match 844 - 2 Player Transfers
```
POST /api/league/{{league_id}}/team/{{team_id}}/match/{{match_844}}/playing-xi
```

Changed players:
- `793463` (Kuldeep Yadav) → `398381` (Yuzvendra Chahal)
- `560565` (R Ashwin) → `675259` (Ishan Kishan)

**Request Body:**
```json
{
  "players": [
    {"player_id": "1463374", "player_name": "Virat Kohli", ...},
    {"player_id": "398381", "player_name": "Yuzvendra Chahal", ...},
    {"player_id": "675259", "player_name": "Ishan Kishan", ...},
    // ... 8 more (11 total)
  ],
  "captainId": "1463374",
  "viceCaptainId": "253802"
}
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "transfersThisMatch": 2,
    "transfersUsedTotal": 2,
    "transfersRemaining": 8,
    "details": {
      "playerTransfers": 2,
      "playersAdded": [
        {"id": "398381", "name": "Yuzvendra Chahal"},
        {"id": "675259", "name": "Ishan Kishan"}
      ],
      "playersRemoved": [
        {"id": "793463", "name": "Kuldeep Yadav"},
        {"id": "560565", "name": "Ravichandran Ashwin"}
      ]
    }
  }
}
```

#### ✅ Get Transfer Stats
```
GET /api/league/{{league_id}}/team/{{team_id}}/transfer-stats
```
**Expected:**
```json
{
  "success": true,
  "data": {
    "transfersUsed": 2,
    "transfersRemaining": 8,
    "transferLimit": 10,
    "captainFreeChangeUsed": false,
    "vcFreeChangeUsed": false
  }
}
```

---

### 4. Match 846 - Free Captain Change

#### ✅ Get Playing XI for Match 846
Should auto-prefill from Match **844** (not 842!)

**Expected:** Lineup includes `398381` and `675259` (from M844)

#### ✅ Save Match 846 - Use Free Captain Change
Changed:
- Captain: `1463374` (Virat) → `253802` (Rohit)
- No player changes

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "transfersThisMatch": 0,
    "transfersUsedTotal": 2,
    "transfersRemaining": 8,
    "details": {
      "playerTransfers": 0,
      "captainChangeCost": 0,
      "vcChangeCost": 0,
      "captainFreeChangeUsed": true,
      "playersAdded": [],
      "playersRemoved": []
    }
  }
}
```

**Key Point:** Captain change was **FREE** (first time)

#### ✅ Get Transfer Stats
```json
{
  "transfersUsed": 2,
  "transfersRemaining": 8,
  "captainFreeChangeUsed": true,
  "captainChangesRemaining": 0
}
```

---

### 5. Match 848 - Captain Change Costs Transfer

#### ✅ Save Match 848 - Captain Change Costs 1 Transfer
Changed:
- Captain: `253802` (Rohit) → `625371` (Hardik)
- No player changes

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "transfersThisMatch": 1,
    "transfersUsedTotal": 3,
    "transfersRemaining": 7,
    "details": {
      "playerTransfers": 0,
      "captainChangeCost": 1,
      "vcChangeCost": 0,
      "captainFreeChangeUsed": true
    }
  }
}
```

**Key Point:** This captain change **costs 1 transfer** (free change already used)

---

### 6. Edge Cases & Validation

#### ⚠️ Sequential Access Blocked (FRONTEND HANDLES)
If you try to access Match N+1 before Match N's deadline:

**Backend Response:**
```json
{
  "success": true,
  "data": {
    "players": [],
    "canEdit": false,
    "errorMessage": "Cannot save Playing XI - previous match must be locked first. Wait until 12/2/2025, 2:30:00 PM"
  }
}
```

**Frontend Behavior:**
- 🔒 Yellow warning: "Sequential Locking: Cannot save Playing XI..."
- All player cards disabled (gray)
- Captain/VC buttons hidden
- Save button disabled with tooltip
- No API error thrown

**Note:** The system now handles this gracefully in UI instead of showing error on save!

#### ❌ Try to Edit Locked Match
**Expected Error:**
```json
{
  "success": false,
  "error": "Cannot save Playing XI - match deadline has passed"
}
```

#### ❌ Try to Exceed Transfer Limit
Changing all 11 players when you only have 7 transfers left.

**Expected Error:**
```json
{
  "success": false,
  "error": "Transfer limit exceeded. You have 7 transfers remaining, but this change would use 11 transfers.",
  "details": {
    "transferLimit": 10,
    "transfersUsedBefore": 3,
    "transfersThisMatch": 11,
    "transfersRemaining": 7
  }
}
```

#### ❌ Save Without Captain
**Expected Error:**
```json
{
  "success": false,
  "error": "Captain and Vice-Captain required"
}
```

#### ❌ Save With Fewer Than 11 Players
**Expected Error:**
```json
{
  "success": false,
  "error": "Exactly 11 players required"
}
```

---

### 7. Test Matches With Status

#### ✅ Get All Matches With Playing XI Status
```
GET /api/league/{{league_id}}/team/{{team_id}}/matches-status
```
**Expected Response:**
```json
{
  "success": true,
  "data": {
    "matches": [
      {
        "match_id": 842,
        "match_description": "India vs Australia",
        "match_start": "2025-12-02T14:30:00.000Z",
        "is_locked": true,
        "is_completed": false,
        "has_playing_xi": true
      },
      {
        "match_id": 844,
        "match_description": "India vs England",
        "match_start": "2025-12-05T14:30:00.000Z",
        "is_locked": false,
        "is_completed": false,
        "has_playing_xi": true
      }
      // ... more matches
    ]
  }
}
```

**Key Fields:**
- `is_locked` - Deadline has passed
- `has_playing_xi` - Team has saved lineup for this match
- Used in UI to show 🔒 and ✅ badges

---

### 8. Re-adding Player Test (Rolling Baseline)

#### ✅ Match 850 - Re-add Player from Match 842
Re-adding `793463` (Kuldeep Yadav):
- Was in Match 842 ✅
- Removed in Match 844 ❌
- Now bringing back in Match 850

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "transfersThisMatch": 1,
    "details": {
      "playerTransfers": 1,
      "playersAdded": [
        {"id": "793463", "name": "Kuldeep Yadav"}
      ],
      "playersRemoved": [
        {"id": "398381", "name": "Yuzvendra Chahal"}
      ]
    }
  }
}
```

**Key Point:** Still costs 1 transfer because baseline is Match 848, not Match 842!

---

## 🎯 Success Criteria

All tests should pass with:
- ✅ Correct transfer counting (rolling baseline)
- ✅ Auto-save working (previous lineup auto-copied)
- ✅ Sequential validation (canEdit flag)
- ✅ UI gracefully handles blocked access (no API errors)
- ✅ Free captain/VC changes working
- ✅ Transfer limit enforcement
- ✅ Deadline timer showing correctly (secondsUntilStart)
- ✅ League ID included in all INSERTs
- ✅ DELETE endpoint removed (incompatible with sequential system)

---

## 📊 Expected Final State

After running all tests (Match 842 → 844 → 846 → 848):

| Match | Player Changes | Captain | VC | Transfers This Match | Total Transfers |
|-------|---------------|---------|-----|---------------------|-----------------|
| 842 | Initial lineup | Virat | Rohit | 0 | 0 |
| 844 | +2 players | Virat | Rohit | 2 | 2 |
| 846 | No change | Rohit ⭐ | Virat | 0 (free) | 2 |
| 848 | No change | Hardik ⭐ | Virat | 1 | 3 |

**Transfers Remaining:** 7 / 10

**Database Verification:**
```sql
-- Check all saved lineups
SELECT match_id, COUNT(*) as player_count 
FROM team_playing_xi 
WHERE team_id = 1 
GROUP BY match_id 
ORDER BY match_id;

-- Expected output:
-- match_id | player_count
-- 842      | 11
-- 844      | 11
-- 846      | 11
-- 848      | 11

-- Check free changes used
SELECT captain_free_change_used, vice_captain_free_change_used 
FROM fantasy_teams 
WHERE id = 1;

-- Expected output:
-- captain_free_change_used | vice_captain_free_change_used
-- true                      | false
```

---

## 🐛 Troubleshooting

### Issue: "null value in column league_id violates not-null constraint"
**Fixed!** League ID now included in all INSERT statements.
- Ensure you're using the latest code
- Check `playingXiControllerSimplified.js` line 533 includes `leagueId`

### Issue: "Deadline showing NaNh NaNm"
**Fixed!** Backend now calculates `secondsUntilStart`.
- Check `playingXiControllerAdapter.js` line 125-127
- Verify `/is-locked` endpoint returns `secondsUntilStart`

### Issue: "DELETE endpoint not found"
**Expected!** DELETE has been removed from the system.
- Sequential locking requires previous lineups to exist
- Auto-save mechanism depends on previous match data
- Deleting would break rolling baseline

### Issue: "Form shows API error instead of disabling"
**Fixed!** Frontend now checks `canEdit` flag.
- Verify `PlayingXIForm.jsx` has `canEdit` state
- Check yellow warning appears when `!canEdit`
- Ensure all buttons check `canEdit` condition

### Issue: "Match not found"
- Check `match_id` exists in `league_matches` table
- Verify `league_id` matches in URL parameters

### Issue: "Sequential blocking not working"
- Ensure Match N deadline has passed before accessing Match N+1
- Check `league_matches.match_start` is before current time
- Verify backend returns `canEdit: false` and `errorMessage`

### Issue: "Previous match not saved"
- Auto-save should handle this automatically
- Ensure you accessed the match (triggers auto-save)
- Check `team_playing_xi` table for previous match data

### Issue: "Deadline has passed"
- Check `league_matches.match_start` timestamp
- Ensure test matches are in the future

### Issue: "Transfer limit exceeded"
- Run `GET /api/transfer-stats/{{team_id}}` to check current usage
- May need to reset test data

---

## 🔄 Reset Test Data

If you need to start over:

```sql
-- Delete all Playing XI data for test team
DELETE FROM team_playing_xi WHERE team_id = 1;

-- Reset free changes
UPDATE fantasy_teams 
SET captain_free_change_used = false,
    vice_captain_free_change_used = false
WHERE id = 1;
```

---

## 📝 Notes

1. **Match Deadlines:** Ensure test matches are in the future (not locked)
2. **Sequential Testing:** Tests must run in order (1 → 2 → 3...)
3. **Player IDs:** Update player IDs if using different players
4. **Environment:** Tests assume clean database with migration applied

---

## ✅ Quick Checklist

Before testing:
- [ ] Migration applied (`node migrations/run-transfer-limit-migration.js`)
- [ ] Server running (`nodemon app.js`)
- [ ] Routes updated to use `playingXiControllerAdapter.js`
- [ ] Latest fixes applied:
  - [ ] League ID fix (line 533 in simplified controller)
  - [ ] DELETE removed from routes
  - [ ] secondsUntilStart calculation in adapter
  - [ ] canEdit/sequentialError handling in frontend
- [ ] Collection imported in Postman
- [ ] Variables configured (league_id, team_id, match IDs)
- [ ] Test data cleared (if re-running)

---

## 🆕 What's New in This Version

### Recent Fixes Applied:
1. **League ID Fix** - All INSERT statements now include `league_id` parameter
2. **DELETE Removal** - DELETE endpoint removed (incompatible with sequential system)
3. **Deadline Timer** - Backend calculates `secondsUntilStart` for countdown
4. **Sequential UI** - Frontend disables form instead of throwing errors

### API Endpoints (Updated):
```
GET    /api/league/:leagueId/team/:teamId/match/:matchId/playing-xi
POST   /api/league/:leagueId/team/:teamId/match/:matchId/playing-xi
❌ DELETE (REMOVED)

GET    /api/league/:leagueId/match/:matchId/is-locked
GET    /api/league/:leagueId/team/:teamId/matches-status
GET    /api/league/:leagueId/team/:teamId/transfer-stats
POST   /api/league/:leagueId/team/:teamId/match/:toMatchId/copy-playing-xi (legacy)
```

### Response Format Changes:
- Added: `canEdit` (boolean) - Whether editing is allowed
- Added: `errorMessage` (string|null) - Sequential blocking message
- Added: `secondsUntilStart` (number) - For countdown timer
- Changed: `lineup` → `players` (adapter transformation for backward compatibility)
- Changed: `transfersThisMatch` → `transfersUsed` (adapter transformation)

Happy Testing! 🚀
