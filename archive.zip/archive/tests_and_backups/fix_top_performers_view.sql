-- Fix tournament_top_performers view to calculate fantasy points from player stats
-- Shows all players with stats, regardless of match completion status
-- This view aggregates points from batting, bowling, and fielding stats tables

DROP VIEW IF EXISTS tournament_top_performers;

CREATE OR REPLACE VIEW tournament_top_performers AS
WITH player_match_points AS (
  SELECT 
    lm.league_id,
    lm.match_id,
    tpxi.player_id,
    tpxi.player_name,
    tpxi.squad_name,
    tpxi.player_role,
    tpxi.team_id,
    -- Batting points
    COALESCE(
      (pbs.runs) +
      (pbs.fours * 1) +
      (pbs.sixes * 2) +
      CASE 
        WHEN pbs.runs >= 100 THEN 100
        WHEN pbs.runs >= 50 THEN 50
        ELSE 0
      END +
      CASE 
        WHEN pbs.strike_rate >= 150 THEN 20
        ELSE 0
      END, 0
    ) +
    -- Bowling points
    COALESCE(
      (pbows.wickets * 25) +
      CASE 
        WHEN pbows.wickets >= 5 THEN 100
        WHEN pbows.wickets >= 3 THEN 50
        ELSE 0
      END +
      CASE 
        WHEN pbows.economy < 4 THEN 30
        ELSE 0
      END, 0
    ) +
    -- Fielding points
    COALESCE(
      (pfs.catches * 10) +
      (pfs.stumpings * 10) +
      ((pfs.runouts_direct + pfs.runouts_indirect) * 10), 0
    ) AS fantasy_points
  FROM team_playing_xi tpxi
  JOIN league_matches lm ON tpxi.match_id = lm.id
  LEFT JOIN player_batting_stats pbs ON tpxi.player_id::text = pbs.player_id::text AND lm.match_id = pbs.match_id
  LEFT JOIN player_bowling_stats pbows ON tpxi.player_id::text = pbows.player_id::text AND lm.match_id = pbows.match_id
  LEFT JOIN player_fielding_stats pfs ON tpxi.player_id::text = pfs.player_id::text AND lm.match_id = pfs.match_id
  -- No is_completed filter - show any player with available stats
)
SELECT 
  league_id,
  player_id,
  player_name,
  squad_name AS cricket_team,
  player_role,
  COUNT(DISTINCT match_id) AS matches_played,
  COUNT(DISTINCT team_id) AS picked_by_teams,
  SUM(fantasy_points) AS total_fantasy_points,
  ROUND(AVG(fantasy_points))::INTEGER AS avg_points_per_match
FROM player_match_points
WHERE fantasy_points > 0  -- Only show players who actually have points
GROUP BY league_id, player_id, player_name, squad_name, player_role
ORDER BY total_fantasy_points DESC;

COMMENT ON VIEW tournament_top_performers IS 'Top players ranked by total fantasy points calculated from batting, bowling, and fielding stats - shows all players with available points regardless of match completion status';

-- Query to test the view
SELECT 
  player_name,
  cricket_team,
  player_role,
  matches_played,
  picked_by_teams,
  total_fantasy_points,
  avg_points_per_match
FROM tournament_top_performers 
WHERE league_id = 84 
ORDER BY total_fantasy_points DESC
LIMIT 10;
