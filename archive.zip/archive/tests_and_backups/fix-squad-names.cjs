const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Fantasy',
  password: 'P@rvezn00r',
  port: 5432
});

async function fixSquadNames() {
  console.log('🔧 Fixing NULL squad_name values in fantasy_squads...\n');

  try {
    // Update squad_name by joining with squad_players and squads tables
    const updateQuery = `
      UPDATE fantasy_squads fs
      SET squad_name = sq.squad_type
      FROM squad_players sp
      JOIN squads sq ON sp.squad_id = sq.squad_id
      WHERE fs.player_id::bigint = sp.player_id
        AND fs.squad_name IS NULL
    `;

    const result = await pool.query(updateQuery);
    console.log(`✅ Updated ${result.rowCount} records with squad_name`);

    // Verify the fix
    const verifyQuery = `
      SELECT 
        league_id,
        COUNT(*) as total,
        COUNT(squad_name) as with_squad_name,
        COUNT(*) - COUNT(squad_name) as still_null
      FROM fantasy_squads
      GROUP BY league_id
      ORDER BY league_id
    `;

    const verifyResult = await pool.query(verifyQuery);
    console.log('\n📊 Squad name status by league:');
    console.table(verifyResult.rows);

    // Show sample fixed records
    const sampleQuery = `
      SELECT player_name, squad_name, role
      FROM fantasy_squads
      WHERE league_id = 83
      LIMIT 5
    `;

    const sampleResult = await pool.query(sampleQuery);
    console.log('\n✅ Sample fixed records from league 83:');
    console.table(sampleResult.rows);

  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await pool.end();
  }
}

fixSquadNames();
