# Captain/Vice-Captain Changes - Visual Reference

## Badge Display

### Before Enhancement
```
┌────────────────────────────────────────┐
│ 🏏 Select Playing XI                   │
│                                        │
│  ⏰ Deadline: 2h 30m                  │
│  ┌──────────────┐                     │
│  │ Transfers    │                     │
│  │ Left:        │                     │
│  │   7/10       │                     │
│  └──────────────┘                     │
│                                        │
│  (C/VC changes badge missing!)        │
└────────────────────────────────────────┘
```

### After Enhancement
```
┌────────────────────────────────────────┐
│ 🏏 Select Playing XI                   │
│                                        │
│  ⏰ Deadline: 2h 30m                  │
│  ┌──────────────┐  ┌──────────────┐  │
│  │ Transfers    │  │ C/VC Changes │  │
│  │ Left:        │  │              │  │
│  │   7/10       │  │    1/1       │  │
│  └──────────────┘  └──────────────┘  │
│   Purple (#667eea)  Pink (#f093fb)   │
└────────────────────────────────────────┘
```

---

## Color Palette

### Transfers Badge (Purple)
```
Start: #667eea ████████
End:   #764ba2 ████████

Gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%)
Shadow: 0 2px 8px rgba(102, 126, 234, 0.3)
```

### C/VC Changes Badge (Pink)
```
Start: #f093fb ████████
End:   #f5576c ████████

Gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%)
Shadow: 0 2px 8px rgba(245, 87, 108, 0.3)
```

### Depleted State (Yellow Glow)
```
Color: #ffe066 ████████
Glow: 0 0 10px rgba(255, 224, 102, 0.5)
Animation: Shake (0.5s)
```

---

## State Transitions

### State 1: Match 1 Setup
```
┌─────────────────────────────────────────────┐
│ Playing XI Selection - Match 1              │
├─────────────────────────────────────────────┤
│                                             │
│ ⏰ Deadline: 5h 30m                        │
│                                             │
│ ┌─────────────┐  ┌─────────────┐          │
│ │ Transfers   │  │ C/VC Changes│          │
│ │ Left:       │  │             │          │
│ │  10/10      │  │    1/1      │          │
│ └─────────────┘  └─────────────┘          │
│                                             │
│ ℹ️ Note: You can freely change Captain/   │
│ Vice-Captain for Match 1. After Match 1    │
│ starts, you'll have 1 C/VC change          │
│ available for all remaining matches.       │
├─────────────────────────────────────────────┤
│                                             │
│ [Select players...]                         │
│                                             │
└─────────────────────────────────────────────┘
```

### State 2: Match 2, No Changes Used
```
┌─────────────────────────────────────────────┐
│ Playing XI Selection - Match 2              │
├─────────────────────────────────────────────┤
│                                             │
│ ⏰ Deadline: 2d 5h                         │
│                                             │
│ ┌─────────────┐  ┌─────────────┐          │
│ │ Transfers   │  │ C/VC Changes│          │
│ │ Left:       │  │             │          │
│ │   8/10      │  │    1/1      │ ← Still │
│ └─────────────┘  └─────────────┘   have 1 │
│                                             │
│ (No info alert - user knows the rules)     │
├─────────────────────────────────────────────┤
│                                             │
│ [Select players...]                         │
│                                             │
└─────────────────────────────────────────────┘
```

### State 3: Change Captain (Match 3)
```
┌─────────────────────────────────────────────┐
│ Playing XI Selection - Match 3              │
├─────────────────────────────────────────────┤
│                                             │
│ ⏰ Deadline: 4d 2h                         │
│                                             │
│ ┌─────────────┐  ┌─────────────┐          │
│ │ Transfers   │  │ C/VC Changes│          │
│ │ Left:       │  │             │          │
│ │   8/10      │  │    1/1      │          │
│ └─────────────┘  └─────────────┘          │
├─────────────────────────────────────────────┤
│                                             │
│ Previous Captain: Virat Kohli               │
│ New Captain: Rohit Sharma ✨               │
│                                             │
│ [💾 Save Playing XI]                       │
└─────────────────────────────────────────────┘
                     ↓
              Click Save
                     ↓
┌─────────────────────────────────────────────┐
│ ✅ Playing XI saved successfully            │
│                                             │
│ ┌─────────────┐  ┌─────────────┐          │
│ │ Transfers   │  │ C/VC Changes│          │
│ │ Left:       │  │             │          │
│ │   8/10      │  │ ⚠️  0/1     │ ← USED! │
│ └─────────────┘  └─────────────┘          │
│                    Yellow glow             │
│                    Shake animation         │
└─────────────────────────────────────────────┘
```

### State 4: Try to Change Again (Match 4)
```
┌─────────────────────────────────────────────┐
│ Playing XI Selection - Match 4              │
├─────────────────────────────────────────────┤
│                                             │
│ ⏰ Deadline: 6d 10h                        │
│                                             │
│ ┌─────────────┐  ┌─────────────┐          │
│ │ Transfers   │  │ C/VC Changes│          │
│ │ Left:       │  │             │          │
│ │   6/10      │  │ ⚠️  0/1     │          │
│ └─────────────┘  └─────────────┘          │
│                                             │
│ ℹ️ Captain/Vice-Captain change limit      │
│ reached (1/1 used). You can still transfer │
│ players but cannot change C/VC.            │
├─────────────────────────────────────────────┤
│                                             │
│ Current Captain: Rohit Sharma 🔒          │
│ (C) and (VC) buttons disabled              │
│                                             │
└─────────────────────────────────────────────┘
```

---

## Badge Components Breakdown

### Badge Structure
```
┌──────────────────────┐
│ TRANSFERS LEFT:     │ ← Label (uppercase, small, 80% opacity)
│      7/10            │ ← Value (large, bold, 100% opacity)
└──────────────────────┘
     ↑            ↑
  Padding     Border-radius
  8px 16px    12px
```

### Typography
```
Label:
- Font-size: 11px
- Color: rgba(255, 255, 255, 0.9)
- Font-weight: 600
- Text-transform: uppercase
- Letter-spacing: 0.5px

Value:
- Font-size: 18px
- Font-weight: 700
- Color: #fff (white)
```

### Spacing
```
Container:
- Gap: 16px (between badges)
- Flex-wrap: wrap (responsive)

Badge:
- Padding: 8px 16px
- Min-width: 140px
- Border-radius: 12px
```

---

## Animation Effects

### Depleted State - Shake Animation
```css
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25%      { transform: translateX(-5px); }
  75%      { transform: translateX(5px); }
}

Duration: 0.5s
Timing: ease-in-out
```

### Visual Effect
```
Before: [  0/1  ]
        ↓
Shake:  [ 0/1 ] ← → ← →
        ↓
After:  [  0/1  ] (with yellow glow)
```

---

## Alert Messages

### Info Alert (Match 1 Only)
```
┌──────────────────────────────────────────────┐
│ ℹ️ Note: You can freely change Captain/    │
│ Vice-Captain for Match 1. After Match 1     │
│ starts, you'll have 1 C/VC change           │
│ available for all remaining matches.        │
└──────────────────────────────────────────────┘

Background: #d1ecf1 (light blue)
Border: 1px solid #bee5eb
Color: #0c5460 (dark teal)
```

### Warning Alert (Limit Reached)
```
┌──────────────────────────────────────────────┐
│ ℹ️ Captain/Vice-Captain change limit       │
│ reached (1/1 used). You can still transfer  │
│ players but cannot change C/VC.             │
└──────────────────────────────────────────────┘

Background: #d1ecf1 (light blue)
Border: 1px solid #bee5eb
Color: #0c5460 (dark teal)
```

---

## Responsive Behavior

### Desktop (> 768px)
```
┌────────────────────────────────────┐
│ ┌─────────────┐  ┌─────────────┐ │
│ │ Transfers   │  │ C/VC Changes│ │
│ │ Left:       │  │             │ │
│ │  7/10       │  │    1/1      │ │
│ └─────────────┘  └─────────────┘ │
└────────────────────────────────────┘
   Side by side with 16px gap
```

### Tablet (480px - 768px)
```
┌──────────────────┐
│ ┌──────────────┐ │
│ │ Transfers    │ │
│ │ Left:        │ │
│ │  7/10        │ │
│ └──────────────┘ │
│ ┌──────────────┐ │
│ │ C/VC Changes │ │
│ │              │ │
│ │    1/1       │ │
│ └──────────────┘ │
└──────────────────┘
   Stacked vertically
```

### Mobile (< 480px)
```
┌────────────────┐
│ ┌────────────┐ │
│ │ Transfers  │ │
│ │   7/10     │ │
│ └────────────┘ │
│ ┌────────────┐ │
│ │ C/VC       │ │
│ │   1/1      │ │
│ └────────────┘ │
└────────────────┘
   Compact, stacked
```

---

## Complete Page Layout

```
┌───────────────────────────────────────────────────────┐
│ Fantasy Cricket League                               │
│ [Dashboard] [My Team] [Playing XI] [Standings]       │
├───────────────────────────────────────────────────────┤
│                                                       │
│ 🏏 Select Playing XI                                 │
│                                                       │
│ ⏰ Deadline: 2d 5h  ┌──────────┐  ┌──────────┐     │
│                      │Transfers │  │C/VC Chng │     │
│                      │  7/10    │  │   1/1    │     │
│                      └──────────┘  └──────────┘     │
│                       Purple         Pink            │
│                                                       │
│ ℹ️ Note: You can freely change Captain/Vice-Captain│
│ for Match 1. After Match 1 starts, you'll have      │
│ 1 C/VC change available for all remaining matches.  │
│                                                       │
├───────────────────────────────────────────────────────┤
│                                                       │
│ Select Match: [Match 1 - Jan 15, 2025 ▼]            │
│                                                       │
├───────────────────────────────────────────────────────┤
│                                                       │
│ Wicketkeepers (Select 1-4)                           │
│ ┌──────┐ ┌──────┐ ┌──────┐                         │
│ │ WK 1 │ │ WK 2 │ │ WK 3 │                         │
│ │  ✓   │ │      │ │      │                         │
│ │ (C)  │ │ [C]  │ │ [VC] │                         │
│ └──────┘ └──────┘ └──────┘                         │
│                                                       │
│ Batsmen (Select 2-6)                                 │
│ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐               │
│ │ Bat 1│ │ Bat 2│ │ Bat 3│ │ Bat 4│               │
│ │  ✓   │ │  ✓   │ │  ✓   │ │      │               │
│ │ [C]  │ │ [C]  │ │ [VC] │ │ [C]  │               │
│ └──────┘ └──────┘ └──────┘ └──────┘               │
│                                                       │
│ [More roles...]                                      │
│                                                       │
├───────────────────────────────────────────────────────┤
│                                                       │
│        [💾 Save Playing XI]  [🗑️ Delete XI]        │
│                                                       │
└───────────────────────────────────────────────────────┘
```

---

## Summary

### Visual Hierarchy
1. **Match deadline** (Red, animated) - Most urgent
2. **Transfer stats** (Purple) - Important
3. **C/VC changes** (Pink) - Important
4. **Alerts** (Blue info / Yellow warning) - Contextual
5. **Player selection** - Main content

### Color Meaning
- 🟣 **Purple** = Player transfers (strategy)
- 🌸 **Pink** = Leadership choice (captain)
- 🟡 **Yellow** = Warning (limit reached)
- 🔵 **Blue** = Information (helpful tips)
- 🔴 **Red** = Urgent (deadline, errors)

### User Journey
```
1. See C/VC badge (1/1 available)
2. Read info alert (understand rules)
3. Select players for Match 1
4. Choose Captain freely
5. Match 1 starts
6. Match 2: See C/VC still 1/1
7. Match 3: Change Captain
8. Badge turns yellow (0/1)
9. Match 4+: Cannot change C/VC
10. Alert explains why (limit reached)
```

**Result**: Complete visual clarity on C/VC change availability! 🎨✨
