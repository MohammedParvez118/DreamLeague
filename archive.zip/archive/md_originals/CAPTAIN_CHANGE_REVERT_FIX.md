# Captain Change Revert Logic Fix

## Date: October 25, 2025

---

## 🐛 The Bug

**User Scenario:**
1. Match 6: Change captain from A → B (counter = 1) ✅
2. Match 6 (re-save): Revert captain from B → A (counter still = 1) ❌
3. Match 7: Try to change captain (blocked!) ❌

**Problem:** When reverting captain back to baseline, the counter wasn't decremented.

---

## 💡 The Fix

### Old Logic (Buggy)
```javascript
// Only checked if it's a NEW change (increment)
// Never decremented when reverting

if (isNewCaptainChange) {
  captainChangesMade = 1;  // Only +1, never -1
}
```

### New Logic (Fixed)
```javascript
// Compare previous save vs baseline AND current save vs baseline
const previousHadCaptainChange = String(previousCaptain.player_id) !== String(baselineCaptain.player_id);
const currentHasCaptainChange = String(captainId) !== String(baselineCaptain.player_id);

if (previousHadCaptainChange && !currentHasCaptainChange) {
  // Reverting to baseline - DECREMENT counter
  captainChangesMade = -1;
} else if (!previousHadCaptainChange && currentHasCaptainChange) {
  // New change from baseline - INCREMENT counter
  captainChangesMade = 1;
} else {
  // No change to counter
  captainChangesMade = 0;
}
```

---

## 🎯 How It Works Now

### Scenario 1: Make Captain Change
```
Match 6:
  Baseline Captain: A
  Previous Save: None (first time)
  Current Save: Captain = B
  
  previousHadCaptainChange: N/A (first time)
  currentHasCaptainChange: true (B ≠ A)
  
  Result: captainChangesMade = +1
  Counter: 0 → 1 ✅
```

### Scenario 2: Revert to Baseline
```
Match 6 (re-save):
  Baseline Captain: A
  Previous Save: Captain = B
  Current Save: Captain = A
  
  previousHadCaptainChange: true (B ≠ A)
  currentHasCaptainChange: false (A = A)
  
  Result: captainChangesMade = -1
  Counter: 1 → 0 ✅
```

### Scenario 3: Change Captain Again
```
Match 7:
  Baseline Captain: A
  Previous Save: None (first time for Match 7)
  Current Save: Captain = C
  
  currentHasCaptainChange: true (C ≠ A)
  
  Result: captainChangesMade = +1
  Counter: 0 → 1 ✅
```

### Scenario 4: Change Within Same Match
```
Match 6:
  Baseline Captain: A
  Previous Save: Captain = B (1 change used)
  Current Save: Captain = C (different from previous)
  
  previousHadCaptainChange: true (B ≠ A)
  currentHasCaptainChange: true (C ≠ A)
  
  Result: captainChangesMade = 0 (no change to counter)
  Counter: 1 → 1 ✅
  
  BUT: This is changing B → C while already having used 1 change
  So the save will be BLOCKED because counter is already at limit!
```

---

## ✅ Expected Behavior

### Test Sequence
1. **Match 6: Change A → B**
   - Counter: 0 → 1
   - Result: ✅ Save succeeds

2. **Match 6 (re-save): Revert B → A**
   - Counter: 1 → 0
   - Result: ✅ Save succeeds

3. **Match 7: Change A → C**
   - Counter: 0 → 1
   - Result: ✅ Save succeeds

4. **Match 8: Try to change C → D**
   - Counter: already at 1
   - Result: ❌ Save BLOCKED (already used 1 change)

---

## 🧪 Debug Output

### When Reverting to Baseline
```javascript
🎯 Change Analysis: {
  previousHadCaptainChange: true,
  currentHasCaptainChange: false
}
⬅️  Reverting to baseline - will DECREMENT counter

🔍 Captain Change Result: {
  captainChangesMade: -1,
  currentCaptainChangesUsed: 1,
  willBlock: false  // -1 won't trigger block
}
```

### When Making New Change
```javascript
🎯 Change Analysis: {
  previousHadCaptainChange: false,
  currentHasCaptainChange: true
}
➡️  New change from baseline - will INCREMENT counter

🔍 Captain Change Result: {
  captainChangesMade: 1,
  currentCaptainChangesUsed: 0,
  willBlock: false  // 0 < 1, allowed
}
```

### When Re-saving Same Captain
```javascript
🎯 Change Analysis: {
  previousHadCaptainChange: true,
  currentHasCaptainChange: true
}
⏸️  No change to counter

🔍 Captain Change Result: {
  captainChangesMade: 0,
  currentCaptainChangesUsed: 1,
  willBlock: false  // 0 won't trigger block
}
```

---

## 📝 Summary

**Fixed:**
- ✅ Reverting to baseline now decrements counter
- ✅ Making new change increments counter
- ✅ Re-saving with same captain doesn't change counter
- ✅ Changing between non-baseline captains doesn't change counter but will block if limit reached

**File Modified:**
- `src/controllers/api/playingXiController.js` (lines 405-430, 465-478)

**Status:** ✅ READY TO TEST

---

## 🚀 Test Now!

1. **Match 6: Change captain** (should increment counter to 1)
2. **Match 6: Revert to baseline** (should decrement counter to 0)
3. **Match 7: Change captain** (should increment counter to 1)
4. **Match 8: Try to change** (should be blocked!)

**Share the debug output to confirm it's working!** 🎉
