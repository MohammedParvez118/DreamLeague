# Captain Change Detection - Enhanced Debug Logs

## 🎯 Purpose
This document explains the **enhanced debug logging** added to diagnose the captain change false positive bug.

---

## 📊 Debug Log Structure

When you save a Playing XI, you'll now see **4 detailed log groups**:

### 1️⃣ **Initial Context** (`🔍 Captain Change Debug`)
```javascript
{
  matchId: '846',
  isFirstMatch: false,
  baselineCaptainId: '1463374',      // From most recent locked match
  baselineCaptainIdType: 'string',    // ⚠️ Type from database
  currentCaptainId: 11959,            // From your save request
  currentCaptainIdType: 'number',     // ⚠️ Type from request body
  baselineVCId: '123456',
  currentVCId: 654321,
  hasPreviousSave: true,              // Have you saved this match before?
  captainChangesUsed: 1               // How many C/VC changes you've already used
}
```

**What to look for:**
- ✅ `baselineCaptainIdType === 'string'` and `currentCaptainIdType === 'number'` → Type mismatch confirmed!
- ✅ `hasPreviousSave: true` → You've saved this match before (should compare with previous save)
- ✅ `hasPreviousSave: false` → First time saving (should compare with baseline)

---

### 2️⃣ **Previous Save Comparison** (`📋 Previous Save`)
**Only appears if** `hasPreviousSave: true`

```javascript
{
  previousCaptainId: '1463374',      // Captain from YOUR previous save of this match
  previousCaptainIdType: 'string',   // Type from database
  previousVCId: '123456',
  previousVCIdType: 'string'
}
```

**What to look for:**
- ✅ `previousCaptainId` should match `currentCaptainId` if you didn't change captain
- ⚠️ If types differ, comparison will fail even if IDs are the same!

---

### 3️⃣ **Change Detection** (`🔄 Change from Previous Save`)
**Only appears if** `hasPreviousSave: true`

```javascript
{
  captainChanged: false,              // Did captain change from previous save?
  vcChanged: false,                   // Did VC change from previous save?
  comparison: "'1463374' !== '11959'" // Actual comparison string
}
```

**What to look for:**
- ✅ `captainChanged: false` → You didn't change captain (correct!)
- ❌ `captainChanged: true` → System thinks you changed captain
- 👁️ `comparison` shows the actual string comparison being made
  - If you see `"'1463374' !== '1463374'"` → Should be `false` (same captain)
  - If you see `"'1463374' !== '11959'"` → Should be `true` (different captain)

---

### 4️⃣ **Change Analysis** (`🎯 Change Analysis`)
**Only appears if** `hasPreviousSave: true`

```javascript
{
  previousHadCaptainChange: false,   // Did previous save have C different from baseline?
  previousHadVCChange: false,        // Did previous save have VC different from baseline?
  currentHasCaptainChange: false,    // Does current save have C different from baseline?
  currentHasVCChange: false,         // Does current save have VC different from baseline?
  previousCaptainVsBaseline: "'1463374' vs '1463374'",  // Previous captain vs baseline
  currentCaptainVsBaseline: "'11959' vs '1463374'"      // Current captain vs baseline
}
```

**What to look for:**
- This determines if it's a **NEW** captain change
- ✅ If `previousHadCaptainChange: false` and `currentHasCaptainChange: false` → No change at all
- ✅ If `previousHadCaptainChange: true` and `currentHasCaptainChange: true` → Same change as before (allowed!)
- ❌ If `previousHadCaptainChange: false` and `currentHasCaptainChange: true` → NEW change (uses your allowance)

---

### 5️⃣ **First Time Save Comparison** (`🆕 First Time Save`)
**Only appears if** `hasPreviousSave: false`

```javascript
{
  captainChanged: true,               // Is captain different from baseline?
  vcChanged: false,                   // Is VC different from baseline?
  comparison: "'1463374' !== '11959'" // Actual comparison string
}
```

**What to look for:**
- When saving a match for the first time, system compares directly with baseline
- ✅ `captainChanged: true` → You chose a different captain than baseline (uses your allowance)
- ✅ `captainChanged: false` → Same captain as baseline (doesn't use allowance)

---

### 6️⃣ **Final Decision** (`🚦 Captain Change Decision`)
```javascript
{
  captainChanged: false,              // Overall: did captain change?
  vcChanged: false,                   // Overall: did VC change?
  isNewCaptainChange: false,          // Is this a NEW change that uses your allowance?
  willBlock: false                    // Will save be blocked?
}
```

**What to look for:**
- ✅ `willBlock: false` → Save will succeed!
- ❌ `willBlock: true` → Save will be blocked!
- If `willBlock: true`, check why:
  - Is `isNewCaptainChange: true`? → System thinks you're making a new change
  - Is `captainChangesUsed >= 1`? → You've already used your one change

---

## 🐛 Known Bug: Type Mismatch

### The Problem
```javascript
baselineCaptainId: '1463374'  // STRING from database
currentCaptainId: 11959        // NUMBER from request body

// Comparison FAILS even if same player:
String('1463374') !== String(11959)  // ❌ Evaluates to TRUE (false positive!)
```

### The Fix
All player ID comparisons now use `String()` conversion:
```javascript
// BEFORE (BUGGY):
captainChanged = previousCaptain && previousCaptain.player_id !== captainId;

// AFTER (FIXED):
captainChanged = previousCaptain && String(previousCaptain.player_id) !== String(captainId);
```

### Where String() is Applied
1. **Previous save comparison** (line 369-370)
   - `String(previousCaptain.player_id) !== String(captainId)`
   - `String(previousVC.player_id) !== String(viceCaptainId)`

2. **Baseline comparisons in change analysis** (line 373-374, 380-381)
   - `String(previousCaptain.player_id) !== String(baselineCaptain.player_id)`
   - `String(captainId) !== String(baselineCaptain?.player_id)`

3. **First-time save comparison** (line 390-391)
   - `String(baselineCaptain.player_id) !== String(captainId)`
   - `String(baselineVC.player_id) !== String(viceCaptainId)`

---

## 🧪 Test Scenarios

### Scenario 1: Re-save Same Match (No Change)
**Expected Logs:**
```javascript
🔍 Initial Context:
  - hasPreviousSave: true
  - captainChangesUsed: 1

📋 Previous Save:
  - previousCaptainId: '1463374'

🔄 Change from Previous:
  - captainChanged: false        // ✅ No change detected
  - comparison: "'1463374' !== '1463374'"

🎯 Change Analysis:
  - previousHadCaptainChange: false
  - currentHasCaptainChange: false

🚦 Final Decision:
  - isNewCaptainChange: false    // ✅ Not a new change
  - willBlock: false             // ✅ Save allowed!
```

**Result:** ✅ Save should succeed

---

### Scenario 2: Change Captain (New Change)
**Expected Logs:**
```javascript
🔍 Initial Context:
  - hasPreviousSave: true
  - captainChangesUsed: 0        // No changes used yet

📋 Previous Save:
  - previousCaptainId: '1463374'

🔄 Change from Previous:
  - captainChanged: true         // ✅ Change detected
  - comparison: "'1463374' !== '11959'"

🎯 Change Analysis:
  - previousHadCaptainChange: false  // Previous save matched baseline
  - currentHasCaptainChange: true    // Current save differs from baseline

🚦 Final Decision:
  - isNewCaptainChange: true     // ✅ New change detected
  - willBlock: false             // ✅ Save allowed (0 changes used)
```

**Result:** ✅ Save should succeed, `captain_changes_made` increments to 1

---

### Scenario 3: Try to Change Captain Again (Blocked)
**Expected Logs:**
```javascript
🔍 Initial Context:
  - hasPreviousSave: true
  - captainChangesUsed: 1        // Already used one change

📋 Previous Save:
  - previousCaptainId: '11959'   // The changed captain

🔄 Change from Previous:
  - captainChanged: true         // ✅ Changing from previous save
  - comparison: "'11959' !== '123456'"

🎯 Change Analysis:
  - previousHadCaptainChange: true   // Previous save already had a change
  - currentHasCaptainChange: true    // Current save also has a change

🚦 Final Decision:
  - isNewCaptainChange: false    // ❌ Wait, this should be TRUE if changing to NEW captain!
  - willBlock: false             // ❌ Should be TRUE!
```

**⚠️ WAIT!** There's a **logic bug** here too! If you change from captain A → B → C, the system might not catch it!

Let me check the logic...

---

## 🔧 Logic Issue Discovered

### Current Logic (Potentially Buggy)
```javascript
// It's a NEW change only if:
isNewCaptainChange = (currentHasCaptainChange && !previousHadCaptainChange) || 
                     (currentHasVCChange && !previousHadVCChange);
```

**Problem:**
- If you change from A → B (counts as 1 change)
- Then change from B → C (should count as ANOTHER change)
- But `previousHadCaptainChange: true` and `currentHasCaptainChange: true`
- So `isNewCaptainChange = false` → **BUG!**

### Correct Logic Should Be
```javascript
// It's a NEW change if:
// 1. Previous save matched baseline, current doesn't (A → B)
// 2. Current save differs from previous AND previous differed from baseline (B → C)
isNewCaptainChange = (currentHasCaptainChange && !previousHadCaptainChange) ||  // A → B
                     (currentHasVCChange && !previousHadVCChange) ||             // A → B for VC
                     (captainChanged || vcChanged);                              // B → C (any change from previous)
```

**Wait, that's also wrong!** Let me think...

### Actually Correct Logic
```javascript
// Re-saving same captain/VC as previous save? → NOT a new change
// Changing to a different captain/VC than previous save? → NEW change IF you have changes left

if (captainChanged || vcChanged) {
  // User is making a change from their previous save
  // This counts as a NEW change (uses allowance)
  isNewCaptainChange = true;
} else {
  // User is re-saving same captain/VC as before
  // This does NOT count as a new change
  isNewCaptainChange = false;
}
```

**This is simpler!** If you change from previous save → new change. Period.

The baseline comparison was **over-complicating** it.

---

## 🎯 Correct Captain Change Logic

### Match 1 (First Match)
- **Rule:** Can change captain/VC as many times as you want
- **Reason:** No baseline exists yet, this IS the baseline
- **Implementation:** Skip captain change tracking entirely

### Match 2+ (After First Match)
- **Rule:** Can change captain/VC once TOTAL after Match 1
- **Logic:**
  1. **First time saving this match?**
     - Compare with baseline (most recent locked match)
     - If different → NEW change (uses allowance)
  2. **Re-saving this match?**
     - Compare with YOUR PREVIOUS SAVE of this same match
     - If different → NEW change (uses allowance)
     - If same → NOT a new change (doesn't use allowance)

### Implementation
```javascript
let isNewCaptainChange = false;

if (previousXI.rows.length > 0) {
  // Have saved this match before - compare with previous save
  const previousCaptain = previousXI.rows.find(p => p.is_captain);
  const previousVC = previousXI.rows.find(p => p.is_vice_captain);
  
  // If captain or VC changed from previous save → NEW change
  const captainChanged = previousCaptain && String(previousCaptain.player_id) !== String(captainId);
  const vcChanged = previousVC && String(previousVC.player_id) !== String(viceCaptainId);
  
  isNewCaptainChange = captainChanged || vcChanged;
} else {
  // First time saving this match - compare with baseline
  const captainChanged = baselineCaptain && String(baselineCaptain.player_id) !== String(captainId);
  const vcChanged = baselineVC && String(baselineVC.player_id) !== String(viceCaptainId);
  
  isNewCaptainChange = captainChanged || vcChanged;
}
```

**This is much simpler!** No need for complex "previousHadCaptainChange" logic.

---

## 📝 Summary

### Current Status
✅ String() conversion applied to all comparisons (fixes type mismatch)
✅ Enhanced debug logging added
⚠️ Logic might be over-complicated (needs review)

### Next Steps
1. **Test with current logs** - See what values appear
2. **If still getting false positives** - Simplify the logic as shown above
3. **Remove debug logs** once confirmed working
4. **Document final solution**

### Debug Log Locations
- Line 358: Initial context
- Line 369: Previous save comparison
- Line 374: Change detection from previous
- Line 380: Change analysis
- Line 395: First-time save comparison
- Line 400: Final decision

---

## 🔍 How to Use This Guide

1. **Try to save your Playing XI**
2. **Check backend console** for debug logs
3. **Look for type mismatches** in the log values
4. **Check if `captainChanged: true` when it should be `false`**
5. **Report back with the full log output**

The enhanced logs will show **exactly** where the comparison is failing! 🎯
