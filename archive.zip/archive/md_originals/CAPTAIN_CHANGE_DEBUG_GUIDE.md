# Captain Change Issue - Debug Guide

## Current Status

✅ **Database Reset**: All teams' `captain_changes_made` reset to 0  
✅ **Debug Logging Added**: Backend will now log captain change detection  
✅ **Backend Running**: Server restarted with debug code

---

## What To Do Next

### Step 1: Try to Save Playing XI

Go to your Playing XI page and try to save a match (Match 5 or any match after Match 1).

### Step 2: Check Backend Logs

Look at the backend terminal output. You should see something like:

```
🔍 Captain Change Debug: {
  matchId: 5,
  isFirstMatch: false,
  baselineCaptainId: '13866',
  currentCaptainId: '13866',
  hasPreviousSave: false,
  captainChangesUsed: 0
}
🔍 Captain Change Result: {
  captainChanged: false,
  vcChanged: false,
  isNewCaptainChange: false,
  willBlock: false
}
```

---

## What the Logs Tell Us

### Debug Output 1: Initial State
```javascript
{
  matchId: 5,              // Which match you're saving
  isFirstMatch: false,      // Is this Match 1? (should be false for Match 5)
  baselineCaptainId: '...',// Captain ID from baseline (locked match)
  currentCaptainId: '...',  // Captain ID you're trying to save
  hasPreviousSave: true/false, // Did you save this match before?
  captainChangesUsed: 0     // How many C/VC changes already used
}
```

### Debug Output 2: Decision
```javascript
{
  captainChanged: false,    // Did captain change from previous save?
  vcChanged: false,         // Did VC change from previous save?
  isNewCaptainChange: false,// Is this a NEW change from baseline?
  willBlock: false          // Will the system block this save?
}
```

---

## Expected Scenarios

### Scenario 1: First Save of Match 5 (Same Captain as Baseline)
```
🔍 Captain Change Debug: {
  matchId: 5,
  isFirstMatch: false,
  baselineCaptainId: '13866',  // Player A
  currentCaptainId: '13866',    // Player A (same!)
  hasPreviousSave: false,
  captainChangesUsed: 0
}
🔍 Captain Change Result: {
  captainChanged: false,        // No change
  vcChanged: false,
  isNewCaptainChange: false,    // Not a new change ✅
  willBlock: false              // Won't block ✅
}
✅ Should ALLOW save
```

### Scenario 2: First Save of Match 5 (Different Captain from Baseline)
```
🔍 Captain Change Debug: {
  matchId: 5,
  isFirstMatch: false,
  baselineCaptainId: '13866',  // Player A
  currentCaptainId: '13867',    // Player B (different!)
  hasPreviousSave: false,
  captainChangesUsed: 0
}
🔍 Captain Change Result: {
  captainChanged: true,         // Yes, changed
  vcChanged: false,
  isNewCaptainChange: true,     // NEW change! ⚠️
  willBlock: false              // Won't block (changes still 0)
}
✅ Should ALLOW and increment captain_changes_made to 1
```

### Scenario 3: Re-save Match 5 (Same Captain)
```
🔍 Captain Change Debug: {
  matchId: 5,
  isFirstMatch: false,
  baselineCaptainId: '13866',  // Player A (baseline)
  currentCaptainId: '13867',    // Player B (current)
  hasPreviousSave: true,        // YES, saved before
  captainChangesUsed: 1
}

Previous save had: Player B
Current save has: Player B (same!)

🔍 Captain Change Result: {
  captainChanged: false,        // No change from previous
  vcChanged: false,
  isNewCaptainChange: false,    // Not a new change ✅
  willBlock: false              // Won't block ✅
}
✅ Should ALLOW save
```

### Scenario 4: Try to Change Captain Again (Should Block)
```
🔍 Captain Change Debug: {
  matchId: 6,
  isFirstMatch: false,
  baselineCaptainId: '13867',  // Player B (from Match 5 locked)
  currentCaptainId: '13868',    // Player C (new change!)
  hasPreviousSave: false,
  captainChangesUsed: 1          // Already used 1 change!
}
🔍 Captain Change Result: {
  captainChanged: true,
  vcChanged: false,
  isNewCaptainChange: true,     // NEW change detected
  willBlock: true               // WILL BLOCK ❌
}
❌ Should BLOCK with error
```

---

## Possible Issues to Check

### Issue 1: Baseline Captain is Wrong
If baseline shows a different captain than expected, it means:
- The baseline match (most recent locked match) has a different captain
- This is CORRECT behavior - baseline is from locked match

### Issue 2: hasPreviousSave is false when it should be true
This means:
- Database doesn't have a record for this team + match combination
- Check `team_playing_xi` table for your team_id and match_id

### Issue 3: isNewCaptainChange is true when you didn't change
This means the logic is incorrectly detecting a change. Possible reasons:
- Previous save had different captain
- Baseline has different captain

---

## How to Share Debug Info

When you encounter the error, copy the backend logs showing:
1. The "Captain Change Debug" output
2. The "Captain Change Result" output
3. The error message

Example:
```
🔍 Captain Change Debug: {...}
🔍 Captain Change Result: {...}
❌ Error: You have already used your one captain/vice-captain change after Match 1.
```

---

## Database Check Query

If you want to manually check the database:

```sql
-- Check team's captain changes used
SELECT 
  ft.team_name,
  ft.captain_changes_made,
  fl.league_name
FROM fantasy_teams ft
JOIN fantasy_leagues fl ON ft.league_id = fl.id
WHERE ft.team_name = 'YOUR_TEAM_NAME';

-- Check saved Playing XI for a match
SELECT 
  player_id,
  player_name,
  is_captain,
  is_vice_captain
FROM team_playing_xi
WHERE team_id = YOUR_TEAM_ID 
  AND match_id = YOUR_MATCH_ID;
```

---

## Next Steps

1. ✅ Database reset (done)
2. ✅ Debug logging added (done)
3. ✅ Backend restarted (done)
4. ⏳ **Try to save Playing XI and share the debug logs**
5. ⏳ Analyze logs to find root cause
6. ⏳ Fix logic based on findings
7. ⏳ Remove debug logging

---

## Temporary Workaround

If you need to bypass this for testing, you can temporarily comment out the check:

```javascript
// if (isNewCaptainChange) {
//   if (stats.captain_changes_made >= 1) {
//     await client.query('ROLLBACK');
//     return res.status(400).json({
//       success: false,
//       message: 'You have already used your one captain/vice-captain change after Match 1.'
//     });
//   }
//   captainChangesMade = 1;
// }
```

But this defeats the purpose of the feature, so only use for debugging!
