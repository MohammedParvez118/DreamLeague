# Fix Ambiguous Column Reference in Database Function ✅

## Issue
When approving a replacement, the error occurred:
```
column reference "match_id" is ambiguous
```

## Root Cause
In the `apply_replacement_to_future_matches()` PostgreSQL function, the subquery had an ambiguous column reference:

```sql
-- WRONG (Line 174):
AND tpxi.match_id IN (SELECT match_id FROM future_matches)
```

The `match_id` in the subquery could refer to:
1. The CTE's `match_id` column
2. The outer query's `tpxi.match_id` column

PostgreSQL couldn't determine which one to use, causing the ambiguous column error.

## Fix Applied

### In Migration File: `add_squad_replacements.sql`
```sql
-- BEFORE (WRONG):
AND tpxi.match_id IN (SELECT match_id FROM future_matches)

-- AFTER (CORRECT):
AND tpxi.match_id IN (SELECT fm.match_id FROM future_matches fm)
```

Added table alias `fm` to explicitly qualify the column reference.

## How to Apply the Fix

### Option 1: Run the SQL File (Recommended)
Execute the fix SQL file in your PostgreSQL database:

```sql
-- File: migrations/fix_ambiguous_match_id.sql

-- In pgAdmin or your SQL client:
-- 1. Open the file: migrations/fix_ambiguous_match_id.sql
-- 2. Run it against your fantasyapp database
```

### Option 2: Run via psql (if available)
```bash
psql -U postgres -d fantasyapp -f migrations/fix_ambiguous_match_id.sql
```

### Option 3: Manual Execution
Copy and paste the SQL from `fix_ambiguous_match_id.sql` directly into:
- pgAdmin Query Tool
- DBeaver SQL Editor
- Any PostgreSQL client

## Verification

After running the SQL, verify the function was updated:

```sql
-- Check function definition
SELECT prosrc 
FROM pg_proc 
WHERE proname = 'apply_replacement_to_future_matches';

-- Should contain: "SELECT fm.match_id FROM future_matches fm"
```

## What This Function Does

The `apply_replacement_to_future_matches()` function automatically:

1. **Finds future matches**: Gets all matches for the team that haven't been played yet
2. **Updates Playing XIs**: Replaces the injured player with the replacement in all future lineups
3. **Preserves captain status**: Maintains whether the player was captain/vice-captain
4. **Returns affected matches**: Shows how many Playing XIs were updated

### Function Flow:
```
Input: team_id, out_player_id, in_player_id, ...
  ↓
CTE: future_matches → Get all future match IDs
  ↓
UPDATE: team_playing_xi → Replace player in all future lineups
  ↓
RETURN: match_id, replaced, was_captain, was_vice_captain
```

## Complete Approval Flow Now Fixed

After applying this fix, the full replacement approval process will work:

1. ✅ Update replacement status to 'approved'
2. ✅ Mark injured player in fantasy_squads
3. ✅ Add replacement player to fantasy_squads (with correct schema)
4. ✅ Auto-update all future Playing XIs (function now works)
5. ✅ Return success with affected matches count

## Files Modified

1. **`migrations/add_squad_replacements.sql`** - Fixed the function definition
2. **`migrations/fix_ambiguous_match_id.sql`** - Standalone fix file (NEW)

## Testing Steps

1. **Run the SQL fix** (see options above)
2. **Restart backend** (if needed)
3. **Refresh browser**
4. **Approve a replacement request**
5. **Expected success**:
   ```json
   {
     "success": true,
     "message": "Replacement approved successfully",
     "affectedMatches": 5
   }
   ```

## Summary of All Fixes Applied Today

### Backend Controller Fixes (replacementController.js):
1. ✅ Fixed `userEmail` parameter name (was `adminEmail`)
2. ✅ Fixed action values (`approved`/`rejected` vs `approve`/`reject`)
3. ✅ Removed non-existent `updated_at` column
4. ✅ Fixed column name: `team_name` → `squad_name`
5. ✅ Added required `league_id` column
6. ✅ Removed non-existent `image_url` column
7. ✅ Added required columns: `is_captain`, `is_vice_captain`, `created_at`
8. ✅ Fixed ON CONFLICT: `(team_id, player_id)` → `(league_id, player_id)`

### Frontend Fixes:
9. ✅ Fixed API response parsing: `data.pending` → `data.data.pendingReplacements`
10. ✅ Fixed nested object access for display (team.name, outPlayer.name, etc.)
11. ✅ Added notification badge with pending count

### Database Function Fix:
12. ✅ Fixed ambiguous column reference in `apply_replacement_to_future_matches()`

---

**Status**: ⚠️ **SQL Fix Required - Then Ready to Test**

**Next Step**: Run `migrations/fix_ambiguous_match_id.sql` in your database, then test the approval! 🎉
