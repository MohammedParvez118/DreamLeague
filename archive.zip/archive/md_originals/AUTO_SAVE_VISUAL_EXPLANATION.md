# Auto-Save Mechanism - Visual Explanation

## 🔄 The Auto-Save Flow

### Problem Solved
**Requirement:** "Auto save the auto copied playing XI"

**What it means:** When Match N+1 unlocks (after Match N deadline), the system should automatically copy Match N's lineup into Match N+1's database, so it's already "saved" when user opens it.

---

## 📊 Timeline Visualization

```
═══════════════════════════════════════════════════════════════════════════
                         DAY 1 - MATCH 1
═══════════════════════════════════════════════════════════════════════════

09:00 AM - User Sets Up Match 1
┌────────────────────────────────────────────────────────────┐
│  User Interface                                            │
├────────────────────────────────────────────────────────────┤
│  Match 1: MI vs CSK                                        │
│  Deadline: 3:00 PM                                         │
│                                                             │
│  [ ] Player 1   [ ] Player 2   [ ] Player 3               │
│  [x] Player 4   [x] Player 5   [x] Player 6               │
│  [x] Player 7   [x] Player 8   [x] Player 9               │
│  [x] Player 10  [x] Player 11  [x] Player 12              │
│                                                             │
│  Captain: Player 4     Vice-Captain: Player 5             │
│                                                             │
│  [SAVE LINEUP] ← User clicks                              │
└────────────────────────────────────────────────────────────┘
                          ↓
                    POST /api/playing-xi
                          ↓
┌────────────────────────────────────────────────────────────┐
│  Database: team_playing_xi                                 │
├────────────────────────────────────────────────────────────┤
│  match_id: 1, player_id: 4, is_captain: true              │
│  match_id: 1, player_id: 5, is_vice_captain: true        │
│  match_id: 1, player_id: 6, ...                           │
│  ... (11 rows total for Match 1)                          │
└────────────────────────────────────────────────────────────┘

Result: Match 1 lineup SAVED ✅
        Transfers: 0 (first match)


═══════════════════════════════════════════════════════════════════════════

03:00 PM - Match 1 Deadline Passes (LOCKS 🔒)
                         
System State:
├─ Match 1: LOCKED (deadline passed)
├─ Match 1 Database: Has 11 saved players ✅
└─ Match 2: UNLOCKS (ready for access)

═══════════════════════════════════════════════════════════════════════════
                         DAY 1 - MATCH 2 UNLOCKS
═══════════════════════════════════════════════════════════════════════════

03:01 PM - User Opens Match 2 (First Time)

┌────────────────────────────────────────────────────────────┐
│  User Action: Clicks "Edit Match 2 Playing XI"            │
└────────────────────────────────────────────────────────────┘
                          ↓
                    GET /api/playing-xi?matchId=2
                          ↓
┌────────────────────────────────────────────────────────────┐
│  Backend Controller Logic                                   │
├────────────────────────────────────────────────────────────┤
│  1. Check: Is Match 1 locked? YES ✅                       │
│  2. Fetch Match 1 lineup from database                     │
│     Result: 11 players found ✅                            │
│  3. Check: Does Match 2 have saved lineup?                 │
│     Query: SELECT * FROM team_playing_xi                   │
│            WHERE match_id = 2                              │
│     Result: 0 rows (empty) ❌                              │
│  4. AUTO-SAVE TRIGGERED! 🚀                                │
│     ├─ BEGIN TRANSACTION                                   │
│     ├─ FOR EACH player in Match 1 lineup:                  │
│     │   INSERT INTO team_playing_xi                        │
│     │   (match_id=2, player_id, is_captain, ...)          │
│     └─ COMMIT TRANSACTION                                  │
│  5. Fetch Match 2 lineup (now has 11 rows)                │
│  6. Return with autoPrefilled flag                         │
└────────────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────────────┐
│  Database: team_playing_xi (AFTER AUTO-SAVE)              │
├────────────────────────────────────────────────────────────┤
│  match_id: 1, player_id: 4, is_captain: true              │
│  match_id: 1, player_id: 5, is_vice_captain: true        │
│  ... (Match 1 - 11 rows)                                  │
│                                                             │
│  match_id: 2, player_id: 4, is_captain: true ← AUTO-SAVED│
│  match_id: 2, player_id: 5, is_vice_captain: true        │
│  ... (Match 2 - 11 rows, copied from Match 1)            │
└────────────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────────────┐
│  User Interface (Match 2 Editor)                           │
├────────────────────────────────────────────────────────────┤
│  Match 2: RCB vs KKR                                       │
│  Deadline: Tomorrow 3:00 PM                                │
│                                                             │
│  ✅ Auto-filled from Match 1                               │
│                                                             │
│  [x] Player 4  (C)   ← Already selected                   │
│  [x] Player 5  (VC)  ← Already selected                   │
│  [x] Player 6        ← Already selected                   │
│  [x] Player 7        ← Already selected                   │
│  ... (all 11 from Match 1)                                │
│                                                             │
│  Transfers if you save as-is: 0                           │
│                                                             │
│  [SAVE LINEUP] or make changes                            │
└────────────────────────────────────────────────────────────┘

User sees: Pre-filled lineup (ready to use)
Database: Already has Match 2 saved (auto-copy) ✅
Benefit: No manual copy needed, rolling baseline exists


═══════════════════════════════════════════════════════════════════════════

03:05 PM - User Makes Changes

┌────────────────────────────────────────────────────────────┐
│  User Interface (Match 2 Editor - Modified)                │
├────────────────────────────────────────────────────────────┤
│  Match 2: RCB vs KKR                                       │
│                                                             │
│  [x] Player 4  (C)   ← Kept from Match 1                  │
│  [ ] Player 5  (VC)  ← REMOVED (was VC)                   │
│  [ ] Player 6        ← REMOVED                             │
│  [x] Player 7        ← Kept                                │
│  [x] Player 13       ← ADDED (new)                        │
│  [x] Player 14       ← ADDED (new)                        │
│  ... (11 total, 2 changed)                                │
│                                                             │
│  Captain: Player 4 (no change)                            │
│  Vice-Captain: Player 13 (changed from Player 5)          │
│                                                             │
│  Transfers this match: 2 + 1 (VC change) = 3             │
│                                                             │
│  [SAVE LINEUP] ← User clicks                              │
└────────────────────────────────────────────────────────────┘
                          ↓
                    POST /api/playing-xi
                          ↓
┌────────────────────────────────────────────────────────────┐
│  Backend Transfer Calculation                               │
├────────────────────────────────────────────────────────────┤
│  1. Fetch Match 2 CURRENT (auto-saved lineup)             │
│     Result: 11 players (Match 1 copy)                     │
│                                                             │
│  2. Compare with NEW submission                            │
│     Removed: Player 5, Player 6 (2 players)               │
│     Added: Player 13, Player 14 (2 players)               │
│     Net changes: 2 transfers                               │
│                                                             │
│  3. Check Captain/VC changes                               │
│     Captain: Player 4 → Player 4 (no change) = 0          │
│     VC: Player 5 → Player 13 (change!)                    │
│         Check free VC change? Used = false                 │
│         Use free change = 0 transfers                      │
│         Set free_vc_change_used = true                     │
│                                                             │
│  4. Total: 2 player transfers + 0 VC = 2 transfers        │
│                                                             │
│  5. Update database:                                       │
│     DELETE FROM team_playing_xi WHERE match_id=2          │
│     INSERT new 11 players                                  │
│     UPDATE fantasy_teams SET                               │
│       vice_captain_free_change_used = true                 │
└────────────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────────────┐
│  Response to User                                           │
├────────────────────────────────────────────────────────────┤
│  ✅ Playing XI saved successfully!                         │
│                                                             │
│  Transfers used this match: 2                              │
│  Total transfers used: 2 / 10                              │
│  Transfers remaining: 8                                    │
│                                                             │
│  Details:                                                   │
│  • 2 player changes                                        │
│  • Vice-Captain changed (free change used)                 │
│  • Captain unchanged                                        │
└────────────────────────────────────────────────────────────┘
```

---

## 🔑 Key Points

### 1. Auto-Save Happens on GET (First Access)
```
User opens Match 2 → GET request
  └─ If Match 2 empty: AUTO-COPY Match 1 → Match 2
  └─ Return pre-filled lineup
```

### 2. Baseline Already Exists
```
When user edits:
├─ OLD baseline: Match 2 auto-saved (= Match 1 copy)
└─ NEW lineup: User's edited version
    └─ Compare: Calculate transfers
```

### 3. Zero Transfers if Unchanged
```
Auto-saved lineup: [P4, P5, P6, ..., P11]
User submits: [P4, P5, P6, ..., P11] (same)
Comparison: 0 changes = 0 transfers ✅
```

### 4. Rolling Baseline
```
Match 1 → Match 2 (auto-copy on first GET)
Match 2 → Match 3 (auto-copy on first GET)
Match 3 → Match 4 (auto-copy on first GET)

Each match baseline = previous match only
NOT all compared to Match 1
```

---

## 🎯 Benefits of Auto-Save

### 1. **Seamless UX** ✅
- User opens match, sees pre-filled lineup immediately
- No need for "Copy from previous" button
- Feels automatic and intuitive

### 2. **Consistent Baseline** ✅
- Rolling baseline always exists in database
- Transfer calculation always works
- No edge cases with "no previous lineup"

### 3. **Zero Transfers for Unchanged** ✅
- User can open, review, and save without penalty
- Encourages engagement
- Fair system

### 4. **Sequential Integrity** ✅
- Can't skip matches (requires previous to be locked)
- Can't manipulate future lineups
- Fair play enforced

---

## 🚨 Edge Case Handling

### Case 1: User Never Saved Match 1
```
Match 1 deadline passes with NO saved lineup
User tries to open Match 2

System Response:
❌ "Cannot access Match 2. Match 1 has no saved lineup."

Reason: No lineup to auto-copy from
Solution: User must set up Match 1 (even after deadline if admin allows)
```

### Case 2: User Opens Match 2 Multiple Times
```
First time: AUTO-SAVE happens ✅
Second time: Lineup already exists, just fetch ✅
Third time: Still just fetch ✅

Auto-save only happens once (when match empty)
```

### Case 3: Match 3 After Editing Match 2
```
Match 2 was edited (3 transfers used)
Match 2 locks with EDITED lineup

User opens Match 3:
└─ AUTO-COPY Match 2 EDITED lineup (not original Match 1)
└─ Rolling baseline continues correctly ✅
```

---

## ✅ Requirements Met

- [x] **"Auto save the auto copied playing XI"** ✅
  - System auto-saves on first GET request
  - User sees pre-filled lineup
  - Database has baseline for comparison

- [x] **"Locked lineup becomes base for subsequent matches"** ✅
  - Whatever was saved before deadline = locked lineup
  - Next match auto-copies that locked lineup
  - Rolling baseline maintained

- [x] **"Transfers only counted when user changes auto-prefilled lineup"** ✅
  - Auto-saved lineup = baseline
  - User edits = new lineup
  - Comparison = transfer count

**Perfect alignment with requirements!** 🎉
